package org.westwood.ctrsWeb.model.container;

import java.util.List;

import org.westwood.ctrsWeb.model.DataQueue;
import org.westwood.ctrsWeb.model.json.DataQueueJson;

public class DataQueueContainer {

	private List<DataQueueJson> data;
	
	public List<DataQueueJson> getData() {
		return data;
	}

	public void setData(List<DataQueueJson> data) {
		this.data = data;
	}
	
}
