//package org.westwood.ctrsWeb.filter;
//
//import javax.servlet.*;
//import javax.servlet.http.HttpFilter;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.security.authentication.AuthenticationManager;
////import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
////import org.springframework.security.core.Authentication;
////import org.springframework.security.core.context.SecurityContextHolder;
////import org.springframework.security.core.userdetails.UserDetails;
////import org.springframework.security.core.userdetails.UserDetailsService;
////import org.springframework.security.web.DefaultRedirectStrategy;
////import org.springframework.security.web.RedirectStrategy;
//
//
//
//import java.io.IOException;
////import java.util.HashMap;
////import java.util.Map;
//
//public class SecurityServletFilter extends HttpFilter {
//
//	
//	  
//    private static final long serialVersionUID = 1L;
//
//		
//	@Override
//    protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
//
//		//System.out.println("SecurityServletFilter: doFilter()");
//		
//        String token = extractUsernameAndPasswordFrom(request);  // (1)
//
//        
//        if (notAuthenticated(token)) {  // (2)
//            // either no or wrong username/password
//            // unfortunately the HTTP status code is called "unauthorized", instead of "unauthenticated"
//            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // HTTP 401.
//            return;
//        }
//
//        if (notAuthorized(token, request)) { // (3)
//            // you are logged in, but don't have the proper rights
//            response.setStatus(HttpServletResponse.SC_FORBIDDEN); // HTTP 403
//            return;
//        }
//
//        // allow the HttpRequest to go to Spring's DispatcherServlet
//        // and @RestControllers/@Controllers.
//        chain.doFilter(request, response); // (4)
//    }
//
//	
//    private String extractUsernameAndPasswordFrom(HttpServletRequest request) {
//        // Either try and read in a Basic Auth HTTP Header, which comes in the form of user:password
//        // Or try and find form login request parameters or POST bodies, i.e. "username=me" & "password="myPass"
//        return checkVariousLoginOptions(request);
//    }
//
//
//    private boolean notAuthenticated(String token) {
//        // compare the token with what you have in your database...or in-memory...or in LDAP...
//    	return false;
//    }
//
//    
//    private boolean notAuthorized(String token, HttpServletRequest request) {
//    	// check if currently authenticated user has the permission/role to access this request's /URI
//    	// e.g. /admin needs a ROLE_ADMIN , /callcenter needs ROLE_CALLCENTER, etc.
//    	return false;
//    }
//
//    
//    private String checkVariousLoginOptions(HttpServletRequest request) {
//    	String s = "Test Token";
//    	return s;
//    }
//    
//    
//    
//    
//    
//	@Override
//	public void destroy() {
//		// TODO Auto-generated method stub
//		
//	}
//}