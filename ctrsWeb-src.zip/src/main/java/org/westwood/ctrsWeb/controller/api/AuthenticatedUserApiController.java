package org.westwood.ctrsWeb.controller.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.service.OrgMapService;
import org.westwood.ctrsWeb.service.UserService;

@Controller
@RequestMapping("/authenticated-users/api")
public class AuthenticatedUserApiController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private OrgMapService orgService;
	
	
	
	@RequestMapping(value = "/whoami", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<UserContainer> whoami() {
		UserContainer container = userService.findUserContainerById(1L);
		System.out.println(container.toString());
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/permitted-fys", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<List<Long>> getPermittedFiscalYears() {
		UserContainer container = userService.findUserContainerById(1L);
		
		return ResponseEntity.status(HttpStatus.OK).body(container.getFiscalYears());
	}
	
	
	@RequestMapping(value = "/permitted-functions", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<List<OrgMap>> getPermittedFunctions(@RequestParam("fiscalYear") Long fiscalYear) {
		UserContainer container = userService.findUserContainerById(1L);
		return ResponseEntity.status(HttpStatus.OK).body(container.getFunctions(fiscalYear));
	}
	
	
	@RequestMapping(value = "/permitted-areas", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<List<OrgMap>> getPermittedAreas(@RequestParam("functionId") Long functionId) {
		UserContainer container = userService.findUserContainerById(1L);
		return ResponseEntity.status(HttpStatus.OK).body(container.getAreas(functionId));
	}
	
	
	@RequestMapping(value = "/get-permitted-child-orgs/{parentId}", method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public List<OrgMap> getChildOrgsById(@PathVariable Long parentId) {
		List<OrgMap> orgList = orgService.findAllByParent(parentId);
				
		return orgList;
	}
	
	
	
}
