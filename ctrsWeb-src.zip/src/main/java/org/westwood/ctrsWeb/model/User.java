package org.westwood.ctrsWeb.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "User")
@Table(name = "User")
public class User implements CtrsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID", nullable=false)
	Long id;
	
	@Column(name = "SEID", nullable = false)
	String seid;
	
	@Column(name = "LAST_NAME", nullable = false)
	String lastName;
	
	@Column(name = "FIRST_NAME", nullable = false)
	String firstName;
	
	@Column(name = "EMAIL", nullable = false)
	String email;

//	@OneToMany(mappedBy = "user", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//	private List<PermittedRole> roles = new ArrayList<PermittedRole>();
//	
//	@OneToMany(mappedBy = "user", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
//	private List<PermittedOrgMap> orgMap = new ArrayList<PermittedOrgMap>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSeid() {
		return seid;
	}

	public void setSeid(String seid) {
		this.seid = seid;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//	public List<PermittedRole> getRoles() {
//		return roles;
//	}
//
//	public void setRoles(List<PermittedRole> roles) {
//		this.roles = roles;
//	}
//
//	public void addPermittedRole(PermittedRole pr) {
//		roles.add(pr);
//		pr.setUser(this);
//	}
//	
//	public void removePermittedRole(PermittedRole pr) {
//		roles.remove(pr);
//		pr.setUser(null);
//	}
	
//	public Boolean hasPermittedRole(Long roleId) {
//		
//		for (PermittedRole pr : this.roles) {
//			if (pr.getRole().getId() == roleId) {
//				return true;
//			}
//		}
//		
//		return false;
//	}
//	
//	public List<PermittedOrgMap> getPermittedOrgMap() {
//		return orgMap;
//	}
//
//	public void setPermittedOrgMap(List<PermittedOrgMap> orgMap) {
//		this.orgMap = orgMap;
//	}
//
//	public void addPermittedOrgMap(PermittedOrgMap pom) {
//		orgMap.add(pom);
//		pom.setUser(this);
//	}
//	
//	public void removePermittedOrgMap(PermittedOrgMap pom) {
//		orgMap.remove(pom);
//		pom.setUser(null);
//	}

//	public Boolean hasPermittedOrgMap(Long functionId, Long areaId) {
//		
//		for (PermittedOrgMap p : this.orgMap) {
//			if (p.getFunction().getId().equals(functionId) && p.getArea().getId().equals(areaId)) { 
//				return true;
//			}
//		}
//		
//		return false;
//		
//	}

	@Override
	public String toString() {
		return "User [id=" + id + ", seid=" + seid + ", lastName=" + lastName + ", firstName=" + firstName + ", email="
				+ email + "]";
	}
	
	
	
}
