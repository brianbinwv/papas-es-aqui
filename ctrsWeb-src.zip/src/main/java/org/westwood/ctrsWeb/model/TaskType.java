package org.westwood.ctrsWeb.model;

public enum TaskType {

	INIT_MISSING_RECORDS
	
}
