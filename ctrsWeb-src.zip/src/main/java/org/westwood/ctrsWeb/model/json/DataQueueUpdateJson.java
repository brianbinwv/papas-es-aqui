package org.westwood.ctrsWeb.model.json;


public class DataQueueUpdateJson {

	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	
}
