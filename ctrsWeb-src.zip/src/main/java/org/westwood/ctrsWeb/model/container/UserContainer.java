package org.westwood.ctrsWeb.model.container;

import java.util.ArrayList;
import java.util.List;

import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.PermittedOrgMap;
import org.westwood.ctrsWeb.model.PermittedRole;
import org.westwood.ctrsWeb.model.Role;
import org.westwood.ctrsWeb.model.User;

public class UserContainer {

	
	private User user;
	private List<Role> roles;
	private List<PermittedOrgMap> orgMap;
	
	

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}
	
	public List<PermittedOrgMap> getOrgMap() {
		return orgMap;
	}

	public void setOrgMap(List<PermittedOrgMap> orgMap) {
		this.orgMap = orgMap;
	}

	@Override
	public String toString() {
		return "UserContainer [user=" + user + ", roles=" + roles + ", orgMap=" + orgMap + "]";
	}
	
	
	public List<OrgMap> getFunctions() {
		List<OrgMap> functions = new ArrayList<OrgMap>();
		
		for (PermittedOrgMap f : this.getOrgMap()) {
			functions.add(f.getFunction());
		}
		
		return functions;
	}
	
	
	public List<OrgMap> getFunctions(Long fiscalYear) {
		List<OrgMap> functions = new ArrayList<OrgMap>();
		
		for (PermittedOrgMap f : this.getOrgMap()) {
			if (f.getFunction().getFiscalYear().equals(fiscalYear)) {
				functions.add(f.getFunction());
			}
		}
		
		return functions;
	}

	
	public List<Long> getFiscalYears() {
		List<Long> fys = new ArrayList<Long>();
		
		
		for (OrgMap p : this.getFunctions()) {
			if (!fys.contains(p.getFiscalYear())) {
				fys.add(p.getFiscalYear());
			}
		}
		
		return fys;
		
	}
	
	
	public List<OrgMap> getAreas(Long functionId) {
		List<OrgMap> areas = new ArrayList<OrgMap>();
		
		for (PermittedOrgMap a : this.getOrgMap()) {
			if (a.getArea().getParentId().equals(functionId)) {
				areas.add(a.getArea());
			}
		}
		
		return areas;
	}
	
	
	public Boolean hasAccessToOrgMap(OrgMap function, OrgMap area) {
		List<OrgMap> fList = this.getFunctions();
		
		for (OrgMap f : fList) {
			if (f.getId().equals(function.getId())) {
				List<OrgMap> aList = this.getAreas(f.getId());
				for (OrgMap a : aList) {
					if (a.getId().equals(area.getId())) {
						return true;
					}
				}
			}
		}
		
		return false;
	}
	
	public Boolean isAdmin() {
		for (Role r : this.roles) {
			if (r.getRoleName().equals("SYSTEM_ADMIN")) {
				return true;
			}
		}
		
		return false;
	}
	
	
	public String getFormattedRoleString() {
		String formattedRoles = "";
		
		
		for (Role r : this.getRoles()) {
			
			formattedRoles += ":" + r.getRoleName();
			
		}

		
		formattedRoles += ":";
		
		
		return formattedRoles;
	}
	
}
