package org.westwood.ctrsWeb.model;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "Role")
@Table(name = "Role")
public class Role implements CtrsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID", nullable=false)
	Long id;
	
	@Column(name = "ROLE_NAME", nullable = false)
	String roleName;
	
	@Column(name = "DESCRIPTION", nullable = false)
	String description;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Role [id=" + id + ", roleName=" + roleName + ", description=" + description + "]";
	}
	
}
