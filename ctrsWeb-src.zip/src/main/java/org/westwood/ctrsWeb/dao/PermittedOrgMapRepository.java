package org.westwood.ctrsWeb.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.PermittedOrgMap;
import org.westwood.ctrsWeb.model.PermittedRole;

@Repository
public class PermittedOrgMapRepository implements CtrsCrudRepository {

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public CtrsEntity find(CtrsEntity ent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CtrsEntity findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findByUserId(Long userId) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(PermittedOrgMap.class);

		cr.add(Restrictions.eq("userId", userId));
		
		return (List<CtrsEntity>)cr.list();

	}
		
	
	@Override
	public Long create(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	@Override
	public void update(CtrsEntity ent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(CtrsEntity ent) {
		// TODO Auto-generated method stub
		
	}

}
