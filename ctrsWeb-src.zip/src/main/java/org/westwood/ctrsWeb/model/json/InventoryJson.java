package org.westwood.ctrsWeb.model.json;


public class InventoryJson {

	private long id;
	private long receipts;
	private long xferIn;
	private long xferOut;
	private long disposals;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getReceipts() {
		return receipts;
	}
	public void setReceipts(long receipts) {
		this.receipts = receipts;
	}
	public long getXferIn() {
		return xferIn;
	}
	public void setXferIn(long xferIn) {
		this.xferIn = xferIn;
	}
	public long getXferOut() {
		return xferOut;
	}
	public void setXferOut(long xferOut) {
		this.xferOut = xferOut;
	}
	public long getDisposals() {
		return disposals;
	}
	public void setDisposals(long disposals) {
		this.disposals = disposals;
	}
	
}
