package org.westwood.ctrsWeb.dao;

import java.util.ArrayList;
//import java.util.Collections;
import java.util.List;



import org.hibernate.Criteria;
//import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.OrgMap;
//import org.westwood.ctrsWeb.model.CtrsTimeCode;

@Repository
public class OrgMapRepository implements CtrsCrudRepository {

	//private Session session = null;
	@Autowired
    private SessionFactory sessionFactory;
	
//	public OrgMapRepository(Session session) {
//		this.session = session;
//	}
	
	
	public List<Long> findAllFiscalYears() {
		List<Long> fiscalYears = new ArrayList<Long>();
		fiscalYears.add(2020L);
		fiscalYears.add(2021L);
		
		return fiscalYears;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findFirstLevelOrgsByFY(Long fiscalYear) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(OrgMap.class);
		
		cr.add(Restrictions.eq("fiscalYear", fiscalYear));
		cr.add(Restrictions.eq("parentId", 0L));
		
		
		return (List<CtrsEntity>)cr.list();
	}
	
	
	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(OrgMap.class).add(Restrictions.eq("id", id));
		return (OrgMap)cr.uniqueResult();
	}
	
	public CtrsEntity find(CtrsEntity ent) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(OrgMap.class);
		
		OrgMap org = (OrgMap)ent;
		
		if (org.getOrgCode() != null) {
			if (org.getOrgCode() > 0L) {
				cr.add(Restrictions.eq("orgCode", org.getOrgCode()));
			}
		}
				
		if (org.getOrgName() != null) {
			if (org.getOrgName().length() > 0) {
				cr.add(Restrictions.eq("orgName", org.getOrgName()));
			}
		}
		
		cr.add(Restrictions.eq("fiscalYear", org.getFiscalYear()));
		return (OrgMap)cr.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(OrgMap.class);
		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		return (List<CtrsEntity>)cr.list();
	}

	public Long create(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	public void update(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	public void delete(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().delete(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

//	public void closeSession() {
//		this.session.close();
//	}
	
}
