package org.westwood.ctrsWeb.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "PermittedOrgMap")
@Table(name = "PermittedOrgMap")
public class PermittedOrgMap implements CtrsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID", nullable=false)
	Long id;
	
	
	@Column(name = "user_id", nullable = false)
    private Long userId;
	
	
	@OneToOne
	@JoinColumn(name = "FUNCTION_ID", nullable=false)
	private OrgMap function;
	
	@OneToOne
	@JoinColumn(name = "AREA_ID", nullable=false)
	private OrgMap area;
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public OrgMap getFunction() {
		return function;
	}

	public OrgMap getArea() {
		return area;
	}

	public void setFunction(OrgMap function) {
		this.function = function;
	}

	public void setArea(OrgMap area) {
		this.area = area;
	}

	@Override
	public String toString() {
		return "PermittedOrgMap [id=" + id + ", userId=" + userId + ", function=" + function + ", area=" + area + "]";
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PermittedOrgMap )) return false;
        return id != null && id.equals(((PermittedOrgMap) o).getId());
    }
 
    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}

