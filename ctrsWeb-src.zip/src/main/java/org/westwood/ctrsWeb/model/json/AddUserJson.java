package org.westwood.ctrsWeb.model.json;


import java.util.List;

import org.westwood.ctrsWeb.model.json.RoleJson;
import org.westwood.ctrsWeb.model.json.OrgMapJson;

public class AddUserJson {

	
	private String seid;
	private String lastName;
	private String firstName;
	private String email;
	
	private List<RoleJson> roles;
	
	private List<OrgMapJson> orgMaps;

	public String getSeid() {
		return seid;
	}

	public void setSeid(String seid) {
		this.seid = seid;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<RoleJson> getRoles() {
		return roles;
	}

	public void setRoles(List<RoleJson> roles) {
		this.roles = roles;
	}

	public List<OrgMapJson> getOrgMaps() {
		return orgMaps;
	}

	public void setOrgMaps(List<OrgMapJson> orgMaps) {
		this.orgMaps = orgMaps;
	}

	@Override
	public String toString() {
		return "AddUser__JsonHelper [seid=" + seid + ", lastName=" + lastName + ", firstName=" + firstName + ", email="
				+ email + ", roles=" + roles + ", orgMaps=" + orgMaps + "]";
	}

	
	
	
	
}
