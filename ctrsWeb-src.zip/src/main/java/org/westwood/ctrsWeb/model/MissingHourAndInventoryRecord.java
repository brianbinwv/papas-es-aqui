package org.westwood.ctrsWeb.model;

import java.math.BigInteger;

public class MissingHourAndInventoryRecord {

	private BigInteger functionId;
	private BigInteger functionCode;
	private String functionName;
	private BigInteger areaId;
	private BigInteger areaCode;
	private String areaName;
	private BigInteger territoryId;
	private BigInteger territoryCode;
	private String territoryName;
	private BigInteger groupId;
	private BigInteger groupCode;
	private String groupName;
	private String timeCode;
	
	
	public MissingHourAndInventoryRecord() {
		
	}

	
	public MissingHourAndInventoryRecord(BigInteger functionId, BigInteger functionCode, String functionName, BigInteger areaId,
			BigInteger areaCode, String areaName, BigInteger territoryId, BigInteger territoryCode, String territoryName, BigInteger groupId,
			BigInteger groupCode, String groupName, String timeCode) {
		super();
		this.functionId = functionId;
		this.functionCode = functionCode;
		this.functionName = functionName;
		this.areaId = areaId;
		this.areaCode = areaCode;
		this.areaName = areaName;
		this.territoryId = territoryId;
		this.territoryCode = territoryCode;
		this.territoryName = territoryName;
		this.groupId = groupId;
		this.groupCode = groupCode;
		this.groupName = groupName;
		this.timeCode = timeCode;
	}

	public BigInteger getFunctionId() {
		return functionId;
	}

	public void setFunctionId(BigInteger functionId) {
		this.functionId = functionId;
	}

	public BigInteger getFunctionCode() {
		return functionCode;
	}

	public void setFunctionCode(BigInteger functionCode) {
		this.functionCode = functionCode;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public BigInteger getAreaId() {
		return areaId;
	}

	public void setAreaId(BigInteger areaId) {
		this.areaId = areaId;
	}

	public BigInteger getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(BigInteger areaCode) {
		this.areaCode = areaCode;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public BigInteger getTerritoryId() {
		return territoryId;
	}

	public void setTerritoryId(BigInteger territoryId) {
		this.territoryId = territoryId;
	}

	public BigInteger getTerritoryCode() {
		return territoryCode;
	}

	public void setTerritoryCode(BigInteger territoryCode) {
		this.territoryCode = territoryCode;
	}

	public String getTerritoryName() {
		return territoryName;
	}

	public void setTerritoryName(String territoryName) {
		this.territoryName = territoryName;
	}

	public BigInteger getGroupId() {
		return groupId;
	}

	public void setGroupId(BigInteger groupId) {
		this.groupId = groupId;
	}

	public BigInteger getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(BigInteger groupCode) {
		this.groupCode = groupCode;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getTimeCode() {
		return timeCode;
	}

	public void setTimeCode(String timeCode) {
		this.timeCode = timeCode;
	}
	
	
}
