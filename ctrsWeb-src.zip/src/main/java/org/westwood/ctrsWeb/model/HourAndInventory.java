package org.westwood.ctrsWeb.model;

import java.util.Date;
import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.GenericGenerator;

@Entity(name = "HourAndInventory")
@Table(name = "HOURANDINVENTORY",
uniqueConstraints=@UniqueConstraint(columnNames = {"TIMECODE_ID", "FUNCTION_ID", "AREA_ID", "TERRITORY_ID", "GROUP_ID", "YEAR_AND_MONTH"}))
public class HourAndInventory implements CtrsEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID", nullable=false)
	private Long id;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "TIMECODE_ID", nullable=false)
	private TimeCode timeCode;
		
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "FUNCTION_ID", nullable=false)
	private OrgMap function;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "AREA_ID", nullable=false)
	private OrgMap area;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "TERRITORY_ID", nullable=false)
	private OrgMap territory;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "GROUP_ID", nullable=false)
	private OrgMap group;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "DATAQUEUE_ID", nullable=false)
	private DataQueue dataQueue;
	
	@Column(name = "CLERICAL_HOURS", nullable = false)
	private Long clericalHours;
	
	@Column(name = "MANAGEMENT_HOURS", nullable = false)
	private Long managementHours;
	
	@Column(name = "PROFESSIONAL_HOURS", nullable = false)
	private Long professionalHours;
	
	@Column(name = "PARA_PROFESSIONAL_HOURS", nullable = false)
	private Long paraProfessionalHours;
	
	@Column(name = "OPENING_INVENTORY", nullable = false)
	private Long openingInventory;
	
	@Column(name = "INVENTORY_RECEIPTS", nullable = false)
	private Long inventoryReceipts;
	
	@Column(name = "INVENTORY_TRANSFER_IN", nullable = false)
	private Long inventoryTransferIn;
	
	@Column(name = "INVENTORY_TRANSFER_OUT", nullable = false)
	private Long inventoryTransferOut;
	
	@Column(name = "INVENTORY_DISPOSALS", nullable = false)
	private Long inventoryDisposals;
	
	@Column(name = "YEAR_AND_MONTH", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date yearAndMonth;
	
	//@Generated(GenerationTime.ALWAYS)
	@Column(name = "CALENDAR_MONTH", insertable = false, updatable = false, columnDefinition = "bigint GENERATED ALWAYS AS (MONTH(YEAR_AND_MONTH))")
	private Long month;
	
	//@Generated(GenerationTime.ALWAYS)
	@Column(name = "CALENDAR_YEAR", insertable = false, updatable = false, columnDefinition = "bigint GENERATED ALWAYS AS (YEAR(YEAR_AND_MONTH))")
	private Long year;
	
	@Column(name = "FISCAL_YEAR", nullable = false)
	private Long fiscalYear;
	
	
	public Long getId() {
		return id;
	}
	  
	public void setId(Long id) {
		this.id = id;
	}
		
	public TimeCode getTimeCode() {
		return timeCode;
	}

	public void setTimeCode(TimeCode timeCode) {
		this.timeCode = timeCode;
	}
		
	public OrgMap getFunction() {
		return function;
	}

	public void setFunction(OrgMap function) {
		this.function = function;
	}

	public OrgMap getArea() {
		return area;
	}

	public void setArea(OrgMap area) {
		this.area = area;
	}

	public OrgMap getTerritory() {
		return territory;
	}

	public void setTerritory(OrgMap territory) {
		this.territory = territory;
	}

	public OrgMap getGroup() {
		return group;
	}

	public void setGroup(OrgMap group) {
		this.group = group;
	}

	public DataQueue getDataQueue() {
		return dataQueue;
	}

	public void setDataQueue(DataQueue dataQueue) {
		this.dataQueue = dataQueue;
	}

	public Long getClericalHours() {
		return clericalHours;
	}

	public void setClericalHours(Long clericalHours) {
		this.clericalHours = clericalHours;
	}

	public Long getManagementHours() {
		return managementHours;
	}

	public void setManagementHours(Long managementHours) {
		this.managementHours = managementHours;
	}

	public Long getProfessionalHours() {
		return professionalHours;
	}

	public void setProfessionalHours(Long professionalHours) {
		this.professionalHours = professionalHours;
	}

	public Long getParaProfessionalHours() {
		return paraProfessionalHours;
	}

	public void setParaProfessionalHours(Long paraProfessionalHours) {
		this.paraProfessionalHours = paraProfessionalHours;
	}

	public Long getOpeningInventory() {
		return openingInventory;
	}

	public void setOpeningInventory(Long openingInventory) {
		this.openingInventory = openingInventory;
	}

	public Long getInventoryReceipts() {
		return inventoryReceipts;
	}

	public void setInventoryReceipts(Long inventoryReceipts) {
		this.inventoryReceipts = inventoryReceipts;
	}

	public Long getInventoryTransferIn() {
		return inventoryTransferIn;
	}

	public void setInventoryTransferIn(Long inventoryTransferIn) {
		this.inventoryTransferIn = inventoryTransferIn;
	}

	public Long getInventoryTransferOut() {
		return inventoryTransferOut;
	}

	public void setInventoryTransferOut(Long inventoryTransferOut) {
		this.inventoryTransferOut = inventoryTransferOut;
	}

	public Long getInventoryDisposals() {
		return inventoryDisposals;
	}

	public void setInventoryDisposals(Long inventoryDisposals) {
		this.inventoryDisposals = inventoryDisposals;
	}

	public Long getClosingInventory() {
		Long additions = openingInventory + inventoryReceipts + inventoryTransferIn;
		Long subtractions = inventoryTransferOut;
		Long subTotal = additions - subtractions;
		Long closingInventory = subTotal - inventoryDisposals;
				
		return closingInventory;
	}
	
	public Date getYearAndMonth() {
		return yearAndMonth;
	}

	public void setYearAndMonth(Date yearAndMonth) {
		this.yearAndMonth = yearAndMonth;
	}

	public Long getMonth() {
		return month;
	}

	public void setMonth(Long month) {
		this.month = month;
	}

	public Long getYear() {
		return year;
	}

	public void setYear(Long year) {
		this.year = year;
	}

	public Long getFiscalYear() {
		return fiscalYear;
	}

	public void setFiscalYear(Long fiscalYear) {
		this.fiscalYear = fiscalYear;
	}

	public Boolean isRollup() {
		//return this.timeCode.isLocal();
		return false;
	}
	
	public Boolean canEdit() {
		// if this is a rollup code, user is not permitted to edit
		return !this.isRollup() ? true : false; 
	}
	
	public Boolean canEdit(String roleName) {
		if (this.dataQueue.getRole().getRoleName().equals(roleName))
			return true;
		
		return false;
	}
	
	public Boolean canEdit(List<Role> roles) {
		
		for (Role r : roles) {
			if (this.dataQueue.getRole().getRoleName().equals(r.getRoleName()))
				return true;
		}
				
		return false;
	}
	
	
	@Override
	public String toString() {
		
		StringBuilder sb = new StringBuilder();
		
		sb.append("HourAndInventory\n");
		sb.append("id=" + id + "\n");
		sb.append("timeCode=" + timeCode.toString() + "\n");
		
		if (function != null) sb.append("function=" + function.getOrgCode() + " - " + function.getOrgName() + "\n");
		if (area != null) sb.append("area=" + area.getOrgCode() + " - " +  area.getOrgName() + "\n");
		if (territory != null) sb.append("territory=" + territory.getOrgCode() + " - " +  territory.getOrgName() + "\n");
		if (group != null) sb.append("group=" + group.getOrgCode() + " - " +  group.getOrgName() + "\n");
		
		sb.append("clericalHours=" + clericalHours + "\n");
		sb.append("managementHours=" + managementHours + "\n");
		sb.append("professionalHours=" + professionalHours + "\n");
		sb.append("paraProfessionalHours=" + paraProfessionalHours + "\n");
		
		sb.append("openingInventory=" + openingInventory + "\n");
		sb.append("inventoryReceipts=" + inventoryReceipts + "\n");
		sb.append("inventoryTransferIn=" + inventoryTransferIn + "\n");
		sb.append("inventoryTransferOut=" + inventoryTransferOut + "\n");
		sb.append("inventoryDisposals=" + inventoryDisposals + "\n");
		sb.append("closingInventory=" + this.getClosingInventory() + "\n");
		
		sb.append("month=" + month + "\n");
		sb.append("year=" + year + "\n");
		
		sb.append("isRollup=" + this.isRollup() + "\n");
		sb.append("canEdit=" + this.canEdit() + "\n");
		
		return sb.toString();
	}
}
