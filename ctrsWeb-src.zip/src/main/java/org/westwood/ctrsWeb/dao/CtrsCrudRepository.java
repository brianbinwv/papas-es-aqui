package org.westwood.ctrsWeb.dao;

import java.util.List;

import org.hibernate.criterion.Criterion;
//import org.hibernate.criterion.ProjectionList;
import org.westwood.ctrsWeb.model.*;

public interface CtrsCrudRepository {

	public CtrsEntity find(CtrsEntity ent);
	
	public CtrsEntity findById(Long id);
	
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion);
	
	public Long create(CtrsEntity ent);
	
	public void update(CtrsEntity ent);
	 
	public void delete(CtrsEntity ent);
	
	//public void closeSession();
	
}
