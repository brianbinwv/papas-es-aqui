package org.westwood.ctrsWeb.dao;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.DataQueue;

@Repository
public class DataQueueRepository implements CtrsCrudRepository {

	@Autowired
	private SessionFactory sessionFactory;
	
	
	public CtrsEntity find(CtrsEntity ent) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public CtrsEntity find(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(DataQueue.class);
		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		return (DataQueue)cr.uniqueResult();
	}

	
	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(DataQueue.class).add(Restrictions.eq("id", id));
		return (DataQueue)cr.uniqueResult();
	}


	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(DataQueue.class);

		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		
		return (List<CtrsEntity>)cr.list();
	}


	public Long create(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}


	public void update(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}


	public void delete(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().delete(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	
}
