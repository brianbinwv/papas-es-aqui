package org.westwood.ctrsWeb.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.dao.HourAndInventoryRepository;
import org.westwood.ctrsWeb.dao.OrgMapRepository;
import org.westwood.ctrsWeb.dao.TimeCodeRepository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.TimeCode;



@Service
@Transactional
public class TimeCodeService implements CtrsBusinessService {
	
	@Autowired
	private TimeCodeRepository repo;
	
	@Autowired
	private OrgMapRepository orgRepo;
	

	public TimeCode findById(Long id) {
		return (TimeCode) repo.findById(id);
	}
	
	
	public List<TimeCode> findAllByFunction(Long functionId) {
		
		return findAllByFunction(functionId, false);

	}

	
	public List<TimeCode> findAllByFunction(Long functionId, Boolean local) {
		
		List<TimeCode> codes = new ArrayList<TimeCode>();
		OrgMap function = new OrgMap();
		List<Criterion> q = new ArrayList<Criterion>();
		
		function = (OrgMap) orgRepo.findById(functionId);
				
		q.add(Restrictions.eq("function", function));
		
	
		if (local) {
			q.add(Restrictions.eq("local", 1L));
		}
		else {
			q.add(Restrictions.eq("local", 0L));
		}
		
		
		for (CtrsEntity e : repo.findAll(q)) {
			codes.add((TimeCode) e);
		}
		
		return codes;
	}

	
	public List<TimeCode> findAllByTerritory(Long territoryId) {
		
		List<TimeCode> codes = new ArrayList<TimeCode>();
		OrgMap territory = new OrgMap();
		List<Criterion> q = new ArrayList<Criterion>();
		
		territory = (OrgMap) orgRepo.findById(territoryId);
		q.add(Restrictions.eq("territory", territory));
		q.add(Restrictions.eq("local", 1L));
		
		for (CtrsEntity e : repo.findAll(q)) {
			codes.add((TimeCode) e);
		}
		
		return codes;
	}
	
	
	public Long create(Long functionId, String timeCode, String description) {
		return this.create(functionId, functionId, functionId, timeCode, description, 0L);
	}

	
	public Long create(Long functionId, Long areaId, Long territoryId, 
			String timeCode, String description, Long isRollup) {
		TimeCode tc = new TimeCode();
		OrgMap org = new OrgMap();
		OrgMap org2 = new OrgMap();
		OrgMap org3 = new OrgMap();
		
		org = (OrgMap) orgRepo.findById(functionId);

		
		tc.setFunction(org);
		
		if (functionId.equals(areaId) && functionId.equals(territoryId)) {
			tc.setArea(org);
			tc.setTerritory(org);
			tc.setLocal(0L);
		}
		else {
			org2 = (OrgMap) orgRepo.findById(areaId);
			
			org3 = (OrgMap) orgRepo.findById(territoryId);
			
			tc.setArea(org2);
			tc.setTerritory(org3);
			tc.setLocal(1L);
		}
		
		tc.setTimeCode(timeCode);
		tc.setFiscalYear(org.getFiscalYear());
		tc.setDescription(description);
		tc.setRollup(isRollup);
		repo.create(tc);
		
		return tc.getId() != null ? tc.getId() : -1L;
	}

	
	public void update(Long id, String description) {
		TimeCode tc = (TimeCode)repo.findById(id);
		
		tc.setDescription(description);
		repo.update(tc);
	}

	
}
