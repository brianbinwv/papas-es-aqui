package org.westwood.ctrsWeb.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.dao.HourAndInventoryMetadataRepository;

import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.HourAndInventoryMetadata;
import org.westwood.ctrsWeb.model.Role;



@Service
@Transactional
public class HourAndInventoryMetadataService implements CtrsBusinessService {

	@Autowired
	private HourAndInventoryMetadataRepository repo;
	
	
	public HourAndInventoryMetadata findById(Long id) {
		return (HourAndInventoryMetadata) repo.findById(id);
	}
	
	
	public List<HourAndInventoryMetadata> findByTimeCodeId(Long timeCodeId) {
		List<HourAndInventoryMetadata> m = new ArrayList<HourAndInventoryMetadata>();
		
		List<Criterion> crit = new ArrayList<Criterion>();
		
		crit.add(Restrictions.eq("timeCodeId", timeCodeId));
		
		for (CtrsEntity e : repo.findAll(crit)) {
			m.add((HourAndInventoryMetadata) e);
		}
				
		return m;
	}
	
	
	public Long create(String createdBy, String action, String comment, Date createdDate, Long timeCodeId) {
		HourAndInventoryMetadata m = new HourAndInventoryMetadata();
		
		
		
		m.setCreatedBy(createdBy);
		m.setAction(action);
		m.setComment(comment);
		m.setCreatedDate(createdDate);
		m.setTimecodeId(timeCodeId);
		System.out.println(m.toString());
		
		repo.create(m);
		
		return m.getId() != null ? m.getId() : -1L;
	}
	
	
	public void update() {
		// NOT IMPLEMENTED
		
	}

	
	public void delete(Long id) {
		// NOT IMPLEMENTED
		
	}
}
