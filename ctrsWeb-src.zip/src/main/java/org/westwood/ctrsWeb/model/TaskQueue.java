package org.westwood.ctrsWeb.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;


@Entity(name = "TaskQueue")
@Table(name = "task_queue")
public class TaskQueue implements CtrsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID", nullable=false)
	Long id;
		
	@Column(name = "USER_ID", nullable = false)
	String userId;
	
	@Column(name = "CREATED_DT")
	private Date createdDate;

	@Column(name = "TASK_ID", length = 36, updatable = false, nullable = false)
	@Type(type="uuid-char")
	private UUID taskId;
	
	@Column(name = "STATUS")
	@Convert(converter = TaskStatusAttributeConverter.class)
	private TaskStatus status;
	
	@Column(name = "TASK_TYPE")
	@Convert(converter = TaskTypeAttributeConverter.class)
	private TaskType taskType;
	
	@Column(name = "PARAMETERS", nullable = false)
	private String parameters;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public UUID getTaskId() {
		return taskId;
	}

	public void setTaskId(UUID taskId) {
		this.taskId = taskId;
	}

	public TaskStatus getStatus() {
		return status;
	}

	public void setStatus(TaskStatus status) {
		this.status = status;
	}

	public TaskType getTaskType() {
		return taskType;
	}

	public void setTaskType(TaskType taskType) {
		this.taskType = taskType;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}
	
	
	
	
	
	
	
}
