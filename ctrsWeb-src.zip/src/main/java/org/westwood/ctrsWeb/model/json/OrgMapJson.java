package org.westwood.ctrsWeb.model.json;


public class OrgMapJson {

	private Long functionId;
	private Long areaId;
	public Long getFunctionId() {
		return functionId;
	}
	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}
	public Long getAreaId() {
		return areaId;
	}
	public void setAreaId(Long areaId) {
		this.areaId = areaId;
	}
	@Override
	public String toString() {
		return "OrgMap__JsonHelper [functionId=" + functionId + ", areaId=" + areaId + "]";
	}
	
	
	
}
