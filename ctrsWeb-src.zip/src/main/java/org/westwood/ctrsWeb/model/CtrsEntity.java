package org.westwood.ctrsWeb.model;

public interface CtrsEntity {
	public Long getId();
}
