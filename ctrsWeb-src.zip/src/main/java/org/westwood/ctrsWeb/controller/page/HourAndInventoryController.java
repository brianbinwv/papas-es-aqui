package org.westwood.ctrsWeb.controller.page;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;

//import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.service.UserService;

@Controller
@RequestMapping("/hourandinventory")
public class HourAndInventoryController {

	@Autowired
	private UserService userService;
	
		
	@RequestMapping("")
	public ModelAndView manageData(Authentication authentication) {
		ModelAndView theModel = new ModelAndView("manage-data", "manage-data", "");
		
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		
		theModel.addObject("roles", container.getRoles().toString());
		
		//System.out.println("authentication: " + authentication.getName());
		return theModel;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
