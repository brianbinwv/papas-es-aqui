package org.westwood.ctrsWeb.controller.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.westwood.ctrsWeb.model.DataQueue;
import org.westwood.ctrsWeb.model.SystemicAuditActionType;
import org.westwood.ctrsWeb.model.container.SuperCTRSAnalystDataQueueContainer;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.model.container.VTSDataQueueContainer;
import org.westwood.ctrsWeb.model.container.WASDataQueueContainer;
import org.westwood.ctrsWeb.model.container.WASMGRDataQueueContainer;
import org.westwood.ctrsWeb.model.json.DataQueueJson;
import org.westwood.ctrsWeb.model.json.DataQueueUpdateJson;
import org.westwood.ctrsWeb.service.DataQueueService;
import org.westwood.ctrsWeb.service.SystemicAuditService;
import org.westwood.ctrsWeb.service.UserService;


@Controller
@RequestMapping("/data-queue/api")
public class DataQueueApiController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private DataQueueService dqService;
	
	@Autowired
	private SystemicAuditService auditService;
	
	
	
	@RequestMapping(value = "/get-vts-data-queue", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<VTSDataQueueContainer> getVTSDataQueue(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam("calendarMonth") Long calendarMonth,
			@RequestParam("fiscalYear") Long fiscalYear) {

		VTSDataQueueContainer container = new VTSDataQueueContainer();
		List<DataQueueJson> jsonList = new ArrayList<DataQueueJson>();
		List<DataQueue> dqList = new ArrayList<DataQueue>();
		dqList = dqService.findAll(functionId, areaId, calendarMonth, fiscalYear);
		
		if (dqList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		for (DataQueue dq : dqList) {
			DataQueueJson h = new DataQueueJson();
			h.setId(dq.getId());
			h.setOrgCode(dq.getTerritory().getOrgCode());
			h.setOrgName(dq.getTerritory().getOrgName());
			h.setRoleName(dq.getRole().getRoleName());
			
			jsonList.add(h);
		}
		
		container.setData(jsonList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/get-was-data-queue", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<WASDataQueueContainer> getWASDataQueue(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam("calendarMonth") Long calendarMonth,
			@RequestParam("fiscalYear") Long fiscalYear) {

		WASDataQueueContainer container = new WASDataQueueContainer();
		List<DataQueueJson> jsonList = new ArrayList<DataQueueJson>();
		List<DataQueue> dqList = new ArrayList<DataQueue>();
		dqList = dqService.findAll(functionId, areaId, calendarMonth, fiscalYear);
		
		if (dqList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		for (DataQueue dq : dqList) {
			DataQueueJson h = new DataQueueJson();
			h.setId(dq.getId());
			h.setOrgCode(dq.getTerritory().getOrgCode());
			h.setOrgName(dq.getTerritory().getOrgName());
			h.setRoleName(dq.getRole().getRoleName());
			
			jsonList.add(h);
		}
		
		container.setData(jsonList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/get-wasmgr-data-queue", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<WASMGRDataQueueContainer> getWASMGRDataQueue(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam("calendarMonth") Long calendarMonth,
			@RequestParam("fiscalYear") Long fiscalYear) {

		WASMGRDataQueueContainer container = new WASMGRDataQueueContainer();
		List<DataQueueJson> jsonList = new ArrayList<DataQueueJson>();
		List<DataQueue> dqList = new ArrayList<DataQueue>();
		dqList = dqService.findAll(functionId, areaId, calendarMonth, fiscalYear);
		
		if (dqList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		for (DataQueue dq : dqList) {
			DataQueueJson h = new DataQueueJson();
			h.setId(dq.getId());
			h.setOrgCode(dq.getTerritory().getOrgCode());
			h.setOrgName(dq.getTerritory().getOrgName());
			h.setRoleName(dq.getRole().getRoleName());
			
			jsonList.add(h);
		}
		
		container.setData(jsonList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/get-super-data-queue", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<SuperCTRSAnalystDataQueueContainer> getSuperDataQueue(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam("calendarMonth") Long calendarMonth,
			@RequestParam("fiscalYear") Long fiscalYear) {

		SuperCTRSAnalystDataQueueContainer container = new SuperCTRSAnalystDataQueueContainer();
		List<DataQueueJson> jsonList = new ArrayList<DataQueueJson>();
		List<DataQueue> dqList = new ArrayList<DataQueue>();
		dqList = dqService.findAll(functionId, areaId, calendarMonth, fiscalYear);
		
		if (dqList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		for (DataQueue dq : dqList) {
			DataQueueJson h = new DataQueueJson();
			h.setId(dq.getId());
			h.setOrgCode(dq.getTerritory().getOrgCode());
			h.setOrgName(dq.getTerritory().getOrgName());
			h.setRoleName(dq.getRole().getRoleName());
			
			jsonList.add(h);
		}
		
		container.setData(jsonList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
		
	
	@PostMapping(value = "/update-territory-to-vts")
	@ResponseBody
	public ResponseEntity<String> updateTerritoryStateToVTS(@RequestBody DataQueueUpdateJson dqObj) {
		
				
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		
		
		
		// ****SECURITY CHECK****
		
		
		// ****END SECURITY CHECK****
		
		
				
		try {
			// request the update
			dqService.changeTerritoryStateToVTS(dqObj.getId());

			// audit
			auditService.create(container.getUser().getSeid(), SystemicAuditActionType.DATA_QUEUE, "Change territory to VTS");
			
			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
	
	
	
	@PostMapping(value = "/update-territory-to-was") 
	@ResponseBody
	public ResponseEntity<String> updateTerritoryStateToWAS(@RequestBody DataQueueUpdateJson dqObj) {
		
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		
		
		
		// ****SECURITY CHECK****
		
		
		// ****END SECURITY CHECK****
		
		
				
		try {
			// request the update
			dqService.changeTerritoryStateToWAS(dqObj.getId());

			// audit
			auditService.create(container.getUser().getSeid(), SystemicAuditActionType.DATA_QUEUE, "Change territory to WAS");
						
			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
	
	
	
	@RequestMapping(value = "/update-area-to-was", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<String> updateAreaStateToWASR(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam("calendarMonth") Long calendarMonth,
			@RequestParam("fiscalYear") Long fiscalYear) {
		
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		
		
		
		// ****SECURITY CHECK****
		
		
		// ****END SECURITY CHECK****
		
		
				
		try {
			// request the update
			dqService.changeAreaStateToWAS(functionId, areaId, calendarMonth, fiscalYear);

			// audit
			auditService.create(container.getUser().getSeid(), SystemicAuditActionType.DATA_QUEUE, "Change area to WAS");
						
			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
	
	
	
	@RequestMapping(value = "/update-area-to-wasmgr", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<String> updateAreaStateToWASMGR(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam("calendarMonth") Long calendarMonth,
			@RequestParam("fiscalYear") Long fiscalYear) {
		
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		
		
		
		// ****SECURITY CHECK****
		
		
		// ****END SECURITY CHECK****
		
		
				
		try {
			// request the update
			dqService.changeAreaStateToWASMGR(functionId, areaId, calendarMonth, fiscalYear);

			// audit
			auditService.create(container.getUser().getSeid(), SystemicAuditActionType.DATA_QUEUE, "Change area to WASMGR");
						
			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
	
	
	
	@RequestMapping(value = "/update-area-to-super", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<String> updateAreaStateToSuper(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam("calendarMonth") Long calendarMonth,
			@RequestParam("fiscalYear") Long fiscalYear) {
		
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		
		
		
		// ****SECURITY CHECK****
		
		
		// ****END SECURITY CHECK****
		
		
				
		try {
			// request the update
			dqService.changeAreaStateToSuper(functionId, areaId, calendarMonth, fiscalYear);

			// audit
			auditService.create(container.getUser().getSeid(), SystemicAuditActionType.DATA_QUEUE, "Change area to Super CTRS Analyst");
						
			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
}
