package org.westwood.ctrsWeb.model;

public enum SystemicAuditActionType {
	UPDATE_HOUR_AND_INVENTORY,
	UPDATE_TIME_CODE,
	UPDATE_ORG_MAP,
	DATA_QUEUE,
	REQUEST_REPORT,
	CANCEL_REPORT,
	CREATE_USER,
	UPDATE_USER,
	DELETE_USER
}
