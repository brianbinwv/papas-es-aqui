package org.westwood.ctrsWeb.controller.api;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.westwood.ctrsWeb.model.ReportContent;
import org.westwood.ctrsWeb.model.ReportMetadata;
import org.westwood.ctrsWeb.model.ReportParameters;
import org.westwood.ctrsWeb.model.TaskStatus;
import org.westwood.ctrsWeb.model.container.ReportMetadataContainer;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.service.ReportContentService;
import org.westwood.ctrsWeb.service.ReportMetadataService;
import org.westwood.ctrsWeb.service.UserService;

import com.google.gson.Gson;

@Controller
@RequestMapping("/reports/api")
public class ReportApiController {

	@Autowired
	private UserService userService;
	
	
	@Autowired
	private ReportMetadataService rptMetadataService;
	
	@Autowired
	private ReportContentService rptContentService;
	
	
	
	@RequestMapping(value = "/get-report-list", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<ReportMetadataContainer> getReportList(){
		// TODO: get roles from security context
		UserContainer user = userService.findUserContainerById(1L);
		ReportMetadataContainer c = new ReportMetadataContainer();
		List<ReportMetadata> m = new ArrayList<ReportMetadata>();

		
		// check user type
		if (user.isAdmin()) {
			// return all reports
			
			m = rptMetadataService.findAll();
		}
		else {
			m = rptMetadataService.findAll(user.getUser().getSeid());
		}
		
		

		if (m == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		c.setData(m);
		
		return ResponseEntity.status(HttpStatus.OK).body(c);
	}
	
	
	@RequestMapping(value = "/create-report", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<String> createReport(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam("territoryId") Long territoryId,
			@RequestParam("groupId") Long groupId,
			@RequestParam("beginMonth") Long beginMonth,
			@RequestParam("endMonth") Long endMonth,
			@RequestParam("fiscalYear") Long fiscalYear,
			@RequestParam("reportName") String reportName
			) {
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		
		ReportMetadata m = new ReportMetadata();
		ReportParameters p = new ReportParameters();
		Gson gson = new Gson();
		
		p.setArea(areaId);
		p.setFunction(functionId);
		p.setTerritory(territoryId);
		p.setGroup(groupId);
		p.setBeginMonth(beginMonth);
		p.setEndMonth(endMonth);
		p.setFiscalYear(fiscalYear);
		p.setReportName(reportName);
		
		System.out.println(p.toString());
		
		String json = gson.toJson(p);

		m.setUserId(container.getUser().getSeid());
		m.setCreatedDate(new Date());
		m.setReportId(UUID.randomUUID());
		m.setReportName(p.getReportName());
		m.setParameters(json);
		m.setStatus(TaskStatus.QUEUED);
		m.setCleanup(false);
		
		
		System.out.println(m.toString());
		rptMetadataService.create(m);

		return ResponseEntity.status(HttpStatus.OK).body("Report has been requested");
		
	}
	
	
	@RequestMapping(value = "/cancel-report", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<String> cancelReport(@RequestParam("reportId") Long reportId){
		// TODO: get roles from security context
		UserContainer user = userService.findUserContainerById(1L);
		ReportMetadata m = new ReportMetadata();
		boolean isOwner = false;
		boolean isAdmin = false;
		
		
		m = rptMetadataService.findById(reportId);

		if (m == null) {
			System.out.println("could not locate metadata record for: " + reportId);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		isOwner = m.getUserId().equals(user.getUser().getSeid());
		isAdmin = user.isAdmin();
		
		if (!isOwner || !isAdmin) {
			System.out.println("neither owner nor admin");
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Request may be canceled only by the owner or administrator");
		}

		if (m.getStatus() == TaskStatus.QUEUED) {
			System.out.println("set status to canceled");
			rptMetadataService.cancel(m);
		}

		return ResponseEntity.status(HttpStatus.OK).body("Request has been canceled");
	}
	
	
	@RequestMapping(value = "/get-report", method = RequestMethod.GET)
	public ResponseEntity<byte[]> getReport(@RequestParam("reportId") String reportId) {
	    HttpHeaders headers = new HttpHeaders();
	    ReportMetadata meta = new ReportMetadata();
	    ReportContent r = null;
	    
	    meta = rptMetadataService.findById(reportId);
	    
	    if (meta == null) {
			System.out.println("report metadata not found");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
	    
	    r = new ReportContent();
	    r = rptContentService.findById(reportId);
		
		if (r == null) {
			System.out.println("report content not found");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		//System.out.println("filename: " + meta.getFileName());
		
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	    headers.add("Content-Disposition", "attachment; filename=" + meta.getFileName());
	    headers.setCacheControl(CacheControl.noCache().getHeaderValue());
	    
		//System.out.println("sending report");
	    ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(r.getReportContent(), headers, HttpStatus.OK);
	    return responseEntity;
	}
	
	
}
