package org.westwood.ctrsWeb.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.Role;

@Repository
public class RoleRepository implements CtrsCrudRepository {
	@Autowired
    private SessionFactory sessionFactory;
	
		
	public CtrsEntity find(CtrsEntity ent) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(Role.class);
		
		Role r = (Role)ent;
		
		cr.add(Restrictions.eq("roleName", r.getRoleName()));
				
		return (Role)cr.uniqueResult();
	}

	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(Role.class).add(Restrictions.eq("id", id));
		return (Role)cr.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll() {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(Role.class);
		
		return (List<CtrsEntity>)cr.list();
	}
	
	public Long create(CtrsEntity ent) {
		sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	public void update(CtrsEntity ent) {
		sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		sessionFactory.getCurrentSession().getTransaction().commit();
	}

	public void delete(CtrsEntity ent) {
		sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().delete(ent);
		sessionFactory.getCurrentSession().getTransaction().commit();
	}

	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		return this.findAll();
	}
}
