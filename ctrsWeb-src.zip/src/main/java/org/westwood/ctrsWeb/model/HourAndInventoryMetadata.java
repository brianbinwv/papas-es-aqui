package org.westwood.ctrsWeb.model;


import java.util.Date;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;

@Entity(name = "HourAndInventoryMetadata")
@Table(name = "HOURANDINVENTORYMETADATA")
public class HourAndInventoryMetadata implements CtrsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID")
	private Long id;
		
	@Column(name = "TIMECODE_ID")
	private Long timeCodeId;
	
	@Column(name = "CREATED_BY", nullable = false)
	private String createdBy;
	
	@Column(name = "ACTION", nullable = false)
	private String action;
	
	@Column(name = "COMMENT")
	private String comment;
	
	@Column(name = "CREATED_DATE", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date createdDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getTimecodeId() {
		return timeCodeId;
	}

	public void setTimecodeId(Long timeCodeId) {
		this.timeCodeId = timeCodeId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	
	
	
}
