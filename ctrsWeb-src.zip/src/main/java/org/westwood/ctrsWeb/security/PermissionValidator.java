package org.westwood.ctrsWeb.security;

import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.model.HourAndInventory;

public class PermissionValidator {

	public static Boolean canEdit(UserContainer uc, HourAndInventory r) {
		
		if (!uc.hasAccessToOrgMap(r.getFunction(), r.getArea())) {
			System.out.println("user does not have required org map");
			return false;
		}
		
		if (!r.canEdit(uc.getRoles())) {
			System.out.println("user does not have required role");
			return false;
		}
		
		
		return true;
	}
	
	public static Boolean isAdmin(UserContainer uc) {
		 return uc.isAdmin();
	}
}
