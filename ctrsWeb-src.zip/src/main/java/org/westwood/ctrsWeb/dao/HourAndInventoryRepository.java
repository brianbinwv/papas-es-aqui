package org.westwood.ctrsWeb.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.HourAndInventory;
import org.westwood.ctrsWeb.model.OrgMap;
//import org.westwood.Web.model.HourAndInventoryReportView;

@Repository
public class HourAndInventoryRepository implements CtrsCrudRepository {

	//private Session session = null;
	
	@Autowired
	private SessionFactory sessionFactory;
		
	public CtrsEntity find(CtrsEntity ent) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(HourAndInventory.class);
		
		HourAndInventory inv = (HourAndInventory)ent;
		
		if (inv.getFunction() == null || inv.getArea() == null || inv.getTerritory() == null || inv.getGroup() == null || inv.getTimeCode() == null) {
			return null;
		}
		
		cr.add(Restrictions.eq("function", inv.getFunction()));
		cr.add(Restrictions.eq("area", inv.getArea()));
		cr.add(Restrictions.eq("territory", inv.getTerritory()));
		cr.add(Restrictions.eq("group", inv.getGroup()));
		
		cr.add(Restrictions.eq("timeCode", inv.getTimeCode()));
		
		cr.add(Restrictions.eq("month", inv.getMonth()));
		cr.add(Restrictions.eq("year", inv.getYear()));
		cr.add(Restrictions.eq("fiscalYear", inv.getFiscalYear()));
		
		return (HourAndInventory)cr.uniqueResult();
	}

	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(HourAndInventory.class).add(Restrictions.eq("id", id));
		return (HourAndInventory)cr.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(HourAndInventory.class);

		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		cr.createAlias("timeCode", "a1");
		cr.addOrder(Order.asc("a1.timeCode"));
		
		
		return (List<CtrsEntity>)cr.list();
	}

	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAllGroupByFunction(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(HourAndInventory.class);

		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		cr.createAlias("timeCode", "a1");
		cr.addOrder(Order.asc("a1.timeCode"));
		cr.createAlias("yearAndMomth", "a2");
		cr.addOrder(Order.asc("a2.yearAndMonth"));
		
		ProjectionList projList = Projections.projectionList();
		projList.add(Projections.property("id"), "id");
		projList.add(Projections.property("month"), "month");
		projList.add(Projections.property("year"), "year");
		projList.add(Projections.groupProperty("function"), "function");
		projList.add(Projections.groupProperty("timeCode"), "timeCode");
		projList.add(Projections.sum("clericalHours"), "clericalHours");
		projList.add(Projections.sum("managementHours"), "managementHours");
		projList.add(Projections.sum("paraProfessionalHours"), "paraProfessionalHours");
		projList.add(Projections.sum("professionalHours"), "professionalHours");
		projList.add(Projections.sum("openingInventory"), "openingInventory");
		projList.add(Projections.sum("inventoryReceipts"), "inventoryReceipts");
		projList.add(Projections.sum("inventoryTransferIn"), "inventoryTransferIn");
		projList.add(Projections.sum("inventoryTransferOut"), "inventoryTransferOut");
		projList.add(Projections.sum("inventoryDisposals"), "inventoryDisposals");

		cr.setProjection(projList);
		
		Criteria summary = cr.setResultTransformer(Transformers.aliasToBean(HourAndInventory.class));
	
		
		return (List<CtrsEntity>)summary.list();
	}
	
		
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAllGroupByFunction_Area(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(HourAndInventory.class);

		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		
		cr.createAlias("timeCode", "a1");
		cr.addOrder(Order.asc("a1.timeCode"));

		ProjectionList projList = Projections.projectionList();
		projList.add(Projections.property("id"), "id");
		projList.add(Projections.property("month"), "month");
		projList.add(Projections.property("year"), "year");
		projList.add(Projections.groupProperty("function"), "function");
		projList.add(Projections.groupProperty("area"), "area");
		projList.add(Projections.groupProperty("timeCode"), "timeCode");
		projList.add(Projections.sum("clericalHours"), "clericalHours");
		projList.add(Projections.sum("managementHours"), "managementHours");
		projList.add(Projections.sum("paraProfessionalHours"), "paraProfessionalHours");
		projList.add(Projections.sum("professionalHours"), "professionalHours");
		projList.add(Projections.sum("openingInventory"), "openingInventory");
		projList.add(Projections.sum("inventoryReceipts"), "inventoryReceipts");
		projList.add(Projections.sum("inventoryTransferIn"), "inventoryTransferIn");
		projList.add(Projections.sum("inventoryTransferOut"), "inventoryTransferOut");
		projList.add(Projections.sum("inventoryDisposals"), "inventoryDisposals");

		cr.setProjection(projList);
		
		Criteria summary = cr.setResultTransformer(Transformers.aliasToBean(HourAndInventory.class));
		
		
		return (List<CtrsEntity>)summary.list();
	}
	
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAllGroupByFunction_Area_Territory(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(HourAndInventory.class);

		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		// change order by and group statements to get the desired output 
		
		
		cr.createAlias("timeCode", "tc");
		cr.addOrder(Order.asc("tc.timeCode"));
		
		cr.createAlias("function", "f1");
		cr.addOrder(Order.asc("f1.orgName"));
		
		cr.createAlias("area", "a1");
		cr.addOrder(Order.asc("a1.orgName"));
		
		cr.createAlias("territory", "t1");
		cr.addOrder(Order.asc("t1.orgName"));
		
				
		// no need to alias since column is part of parent table
		cr.addOrder(Order.asc("yearAndMonth"));

		ProjectionList projList = Projections.projectionList();
		projList.add(Projections.property("id"), "id");
		projList.add(Projections.property("month"), "month");
		projList.add(Projections.property("year"), "year");
		
		projList.add(Projections.groupProperty("yearAndMonth"), "yearAndMonth");
		
		projList.add(Projections.groupProperty("function"), "function");
		projList.add(Projections.groupProperty("area"), "area");
		projList.add(Projections.groupProperty("territory"), "territory");
		projList.add(Projections.groupProperty("timeCode"), "timeCode");
		projList.add(Projections.sum("clericalHours"), "clericalHours");
		projList.add(Projections.sum("managementHours"), "managementHours");
		projList.add(Projections.sum("paraProfessionalHours"), "paraProfessionalHours");
		projList.add(Projections.sum("professionalHours"), "professionalHours");
		projList.add(Projections.sum("openingInventory"), "openingInventory");
		projList.add(Projections.sum("inventoryReceipts"), "inventoryReceipts");
		projList.add(Projections.sum("inventoryTransferIn"), "inventoryTransferIn");
		projList.add(Projections.sum("inventoryTransferOut"), "inventoryTransferOut");
		projList.add(Projections.sum("inventoryDisposals"), "inventoryDisposals");

		cr.setProjection(projList);
		
		Criteria summary = cr.setResultTransformer(Transformers.aliasToBean(HourAndInventory.class));
		
		
		return (List<CtrsEntity>)summary.list();
	}
	
	
	public Long create(CtrsEntity ent) {
		sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	public void update(CtrsEntity ent) {
		
		
//		if (sessionFactory.getCurrentSession().getTransaction().isActive()) {
//			System.out.println("hibernate claims a transaction is already active");
//			sessionFactory.getCurrentSession().getTransaction().commit();
//		}
//		
//		//sessionFactory.getCurrentSession().getTransaction().begin();
//		sessionFactory.getCurrentSession().beginTransaction();
//		System.out.println("calling update");
		
		sessionFactory.getCurrentSession().update(ent);
		
		//System.out.println("calling commit");
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		
	}

	public void delete(CtrsEntity ent) {
		sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().delete(ent);
		sessionFactory.getCurrentSession().getTransaction().commit();
	}
}
