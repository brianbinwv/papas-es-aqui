package org.westwood.ctrsWeb.model;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;

@Entity(name = "TimeCode")
@Table(name = "TIME_CODE", 
uniqueConstraints=@UniqueConstraint(columnNames = {"TIME_CODE", "FUNCTION_ID", "AREA_ID", 
		"TERRITORY_ID", "FISCAL_YEAR"}))
public class TimeCode implements CtrsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID")
	private Long id;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "FUNCTION_ID", nullable=false)
	private OrgMap function;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "AREA_ID", nullable=false)
	private OrgMap area;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "TERRITORY_ID", nullable=false)
	private OrgMap territory;
		
	@Column(name = "TIME_CODE", nullable = false)
	private String timeCode;
	
	@Column(name = "DESCRIPTION", nullable = false)
	private String description;

	@Column(name = "FISCAL_YEAR", nullable = false)
	private Long fiscalYear;
	
	@Column(name = "LOCAL", nullable = false)
	private Long local;
	
	@Column(name = "ROLLUP", nullable = false)
	private Long rollup;
	
	@Column(name = "HOURS", nullable = false)
	private Long hours;
	
	@Column(name = "INVENTORY", nullable = false)
	private Long inventory;
	
	
	public Long getId() {
		return id;
	}
	  
	public void setId(Long id) {
		this.id = id;
	}

	public OrgMap getFunction() {
		return function;
	}

	public void setFunction(OrgMap function) {
		this.function = function;
	}
	
	public String getTimeCode() {
		return timeCode;
	}

	public void setTimeCode(String timeCode) {
		this.timeCode = timeCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getFiscalYear() {
		return fiscalYear;
	}

	public void setFiscalYear(Long fiscalYear) {
		this.fiscalYear = fiscalYear;
	}

	public OrgMap getArea() {
		return area;
	}

	public void setArea(OrgMap area) {
		this.area = area;
	}

	public OrgMap getTerritory() {
		return territory;
	}

	public void setTerritory(OrgMap territory) {
		this.territory = territory;
	}

	public Long getLocal() {
		return local;
	}

	public void setLocal(Long local) {
		this.local = local;
	}

	public Long getRollup() {
		return rollup;
	}

	public void setRollup(Long rollup) {
		this.rollup = rollup;
	}
	
	public Long getHours() {
		return hours;
	}

	public void setHours(Long hours) {
		this.hours = hours;
	}

	public Long getInventory() {
		return inventory;
	}

	public void setInventory(Long inventory) {
		this.inventory = inventory;
	}

	public Boolean isLocal() {
		return local == 1L ? true : false;
	}
	
	public Boolean isRollup() {
		return rollup == 1L ? true : false;
	}

	public Boolean hasHours() {
		return hours == 1L ? true : false;
	}
	
	public Boolean hasInventory() {
		return inventory == 1L ? true : false;
	}
	
	
	@Override
	public String toString() {
//		return "TimeCode [id=" + id + ", function= " + function.getOrgName() + " , timeCode=" + timeCode + ", description=" + description 
//				+ ", fiscalYear=" + fiscalYear + "]";
		return timeCode + " - " + description;
		
	}
}
