package org.westwood.ctrsWeb.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.HourAndInventory;
import org.westwood.ctrsWeb.model.lightweight.LW__HourAndInventory;
import org.westwood.ctrsWeb.model.MissingHourAndInventoryRecord;


@Repository
public class LW__HourAndInventoryRepository {
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(LW__HourAndInventory.class).add(Restrictions.eq("id", id));
		return (LW__HourAndInventory)cr.uniqueResult();
	}
	
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> find(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(LW__HourAndInventory.class);
		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		
		cr.addOrder(Order.asc("functionCode"));
		cr.addOrder(Order.asc("areaCode"));
		cr.addOrder(Order.asc("territoryCode"));
		cr.addOrder(Order.asc("groupCode"));
		cr.addOrder(Order.asc("timeCode"));
		
		
		return (List<CtrsEntity>)cr.list();
	}
	
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> find__Summary(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(LW__HourAndInventory.class);

		
		for (Criterion c : queryCriterion) {
			System.out.println("criteria " + c.toString());
			cr.add(c);
		}
		
		// change order by and group statements to get the desired output 
		cr.addOrder(Order.asc("timeCode"));

		
		ProjectionList projList = Projections.projectionList();
		
		projList.add(Projections.groupProperty("functionId"), "functionId");
		projList.add(Projections.groupProperty("functionCode"), "functionCode");
		projList.add(Projections.groupProperty("functionName"), "functionName");
		projList.add(Projections.groupProperty("areaId"), "areaId");
		projList.add(Projections.groupProperty("areaCode"), "areaCode");
		projList.add(Projections.groupProperty("areaName"), "areaName");
		projList.add(Projections.groupProperty("territoryId"), "territoryId");
		projList.add(Projections.groupProperty("territoryCode"), "territoryCode");
		projList.add(Projections.groupProperty("territoryName"), "territoryName");
		projList.add(Projections.groupProperty("timeCode"), "timeCode");
		projList.add(Projections.groupProperty("timeCodeDescription"), "timeCodeDescription");
		projList.add(Projections.sum("clericalHours"), "clericalHours");
		projList.add(Projections.sum("managementHours"), "managementHours");
		projList.add(Projections.sum("paraProfessionalHours"), "paraProfessionalHours");
		projList.add(Projections.sum("professionalHours"), "professionalHours");
		projList.add(Projections.sum("openingInventory"), "openingInventory");
		projList.add(Projections.sum("inventoryReceipts"), "inventoryReceipts");
		projList.add(Projections.sum("inventoryTransferIn"), "inventoryTransferIn");
		projList.add(Projections.sum("inventoryTransferOut"), "inventoryTransferOut");
		projList.add(Projections.sum("inventoryDisposals"), "inventoryDisposals");

		cr.setProjection(projList);
		
		Criteria summary = cr.setResultTransformer(Transformers.aliasToBean(LW__HourAndInventory.class));
		
		
		return (List<CtrsEntity>)summary.list();
	}
	
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAllGroupByFunction_Area_Territory(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(LW__HourAndInventory.class);

		
		for (Criterion c : queryCriterion) {
			System.out.println("criteria " + c.toString());
			cr.add(c);
		}
		
		// change order by and group statements to get the desired output 
		cr.addOrder(Order.asc("timeCode"));

		
		ProjectionList projList = Projections.projectionList();
		
		projList.add(Projections.groupProperty("functionId"), "functionId");
		projList.add(Projections.groupProperty("functionName"), "functionName");
		projList.add(Projections.groupProperty("areaId"), "areaId");
		projList.add(Projections.groupProperty("areaName"), "areaName");
		projList.add(Projections.groupProperty("territoryId"), "territoryId");
		projList.add(Projections.groupProperty("territoryName"), "territoryName");
		projList.add(Projections.groupProperty("timeCode"), "timeCode");
		projList.add(Projections.groupProperty("timeCodeDescription"), "timeCodeDescription");
		projList.add(Projections.sum("clericalHours"), "clericalHours");
		projList.add(Projections.sum("managementHours"), "managementHours");
		projList.add(Projections.sum("paraProfessionalHours"), "paraProfessionalHours");
		projList.add(Projections.sum("professionalHours"), "professionalHours");
		projList.add(Projections.sum("openingInventory"), "openingInventory");
		projList.add(Projections.sum("inventoryReceipts"), "inventoryReceipts");
		projList.add(Projections.sum("inventoryTransferIn"), "inventoryTransferIn");
		projList.add(Projections.sum("inventoryTransferOut"), "inventoryTransferOut");
		projList.add(Projections.sum("inventoryDisposals"), "inventoryDisposals");

		cr.setProjection(projList);
		
		Criteria summary = cr.setResultTransformer(Transformers.aliasToBean(LW__HourAndInventory.class));
		
		
		return (List<CtrsEntity>)summary.list();
	}
	
	
//	@SuppressWarnings({ "rawtypes", "deprecation", "unchecked" })
//	public List<MissingHourAndInventoryRecord> findMissingRecords(Long functionId, Long areaId, Long fiscalYear, long calendarMonth) {
//		List<MissingHourAndInventoryRecord> mrList = new ArrayList<MissingHourAndInventoryRecord>();
//		SQLQuery q = null;
//		String qryStr = 
//				"select"
//				+ "	f.id as functionId, f.ORG_CODE as functionCode, f.NAME as functionName,"
//				+ "    a.id as areaId, a.ORG_CODE as areaCode, a.NAME as areaName,"
//				+ "    t.id as territoryId, t.ORG_CODE as territoryCode, t.NAME as territoryName,"
//				+ "    g.id as groupId, g.ORG_CODE as groupCode, g.NAME as groupName,"
//				+ "    tc.time_code as timeCode"
//				+ "from"
//				+ "	ctrs_time_code tc "
//				+ "left join"
//				+ "	ctrs_org_map f on f.id = " + functionId + " "
//				+ "left join"
//				+ "	ctrs_org_map a on a.id = " + areaId + " "
//				+ "left join"
//				+ "	ctrs_org_map t on t.id in"
//				+ "    ("
//				+ "		select"
//				+ "			distinct o1.id"
//				+ "		from"
//				+ "			ctrs_org_map o1"
//				+ "		left join"
//				+ "			ctrs_org_map o2 on o2.parent_id = o1.id"
//				+ "		where"
//				+ "			o1.FISCAL_YEAR = " + fiscalYear + " and"
//				+ "			o1.PARENT_ID = " + areaId
//				+ "    )"
//				+ "left join"
//				+ "	ctrs_org_map g on g.id in"
//				+ "    ("
//				+ "		select"
//				+ "			o1.id"
//				+ "		from"
//				+ "			ctrs_org_map o1"
//				+ "		left join"
//				+ "			ctrs_org_map o2 on o2.parent_id = o1.id"
//				+ "		where"
//				+ "			o1.FISCAL_YEAR = " + fiscalYear + " and"
//				+ "			o1.PARENT_ID = t.id"
//				+ "    ) "
//				+ "where"
//				+ "	tc.FISCAL_YEAR = " + fiscalYear + " and"
//				+ "    tc.TIME_CODE not in"
//				+ "    ("
//				+ "		select"
//				+ "			v.time_code"
//				+ "		from"
//				+ "			hourandinventory_view v"
//				+ "		where"
//				+ "			v.calendar_month = " + calendarMonth + " and"
//				+ "            v.FISCAL_YEAR = " + fiscalYear + " and"
//				+ "            v.FUNCTION_ID = f.id and"
//				+ "            v.AREA_ID = a.id and"
//				+ "            v.TERRITORY_ID and"
//				+ "            v.group_id = g.id"
//				+ "    ) "
//				+ "group by"
//				+ " f.id, a.id, t.id, g.id, tc.TIME_CODE";
//		
//		q = sessionFactory.getCurrentSession().createSQLQuery(qryStr);
//			
//
//		List<Object[]> rows = q.list();
//		
//		for (Object[] obj : rows) {
//			
//			//System.out.println(obj[0]);
//			Long fId = convertToLong(obj[0]);
//			
//			//System.out.println(obj[1]);
//			Long fCd = convertToLong(obj[1]);
//			
//			//System.out.println(obj[2]);
//			String fName = (String)obj[2];
//			
//			//System.out.println(obj[3]);
//			Long aId = convertToLong(obj[3]);
//			
//			//System.out.println(obj[4]);
//			Long aCd = convertToLong(obj[4]);
//			
//			//System.out.println(obj[5]);
//			String aName = (String)obj[5];
//			
//			//System.out.println(obj[6]);
//			Long tId = convertToLong(obj[6]);
//			
//			//System.out.println(obj[7]);
//			Long tCd = convertToLong(obj[7]);
//			
//			//System.out.println(obj[8]);
//			String tName = (String)obj[8];
//			
//			//System.out.println(obj[9]);
//			Long gId = convertToLong(obj[9]);
//			
//			//System.out.println(obj[10]);
//			Long gCd = convertToLong(obj[10]);
//			
//			//System.out.println(obj[11]);
//			String gName = (String)obj[11];
//			
//			//System.out.println(obj[12]);
//			Long timeCode = convertToLong(obj[12]);
//			
//			
//			mrList.add(
//					new MissingHourAndInventoryRecord (
//						fId,
//						fCd,
//						fName,
//						aId,
//						aCd,
//						aName,
//						tId,
//						tCd,
//						tName,
//						gId,
//						gCd,
//						gName,
//						timeCode
//				    )
//				);
//			
//			
//			
////			mrList.add(
////				new MissingHourAndInventoryRecord (
////					(Long)obj[0],
////					(Long)obj[1],
////					(String)obj[2],
////					(Long)obj[3],
////					(Long)obj[4],
////					(String)obj[5],
////					(Long)obj[6],
////					(Long)obj[7],
////					(String)obj[8],
////					(Long)obj[9],
////					(Long)obj[10],
////					(String)obj[11],
////					(Long)obj[12]
////			    )
////			);
//        }
//		
//		
//		return mrList;
//		
//	}
	
	
	
	
	@SuppressWarnings({ "rawtypes", "deprecation", "unchecked" })
	public List<MissingHourAndInventoryRecord> findMissingRecords_2(Long functionId, Long areaId, Long fiscalYear, long calendarMonth) {
		List<MissingHourAndInventoryRecord> mrList = new ArrayList<MissingHourAndInventoryRecord>();
		Query q = null;
		String qryStr = 
				"select"
				+ "	f.id as functionId, f.ORG_CODE as functionCode, f.NAME as functionName,"
				+ "    a.id as areaId, a.ORG_CODE as areaCode, a.NAME as areaName,"
				+ "    t.id as territoryId, t.ORG_CODE as territoryCode, t.NAME as territoryName,"
				+ "    g.id as groupId, g.ORG_CODE as groupCode, g.NAME as groupName,"
				+ "    tc.time_code as timeCode "
				+ "from"
				+ "	time_code tc "
				+ "left join"
				+ "	org_map f on f.id = " + functionId + " "
				+ "left join"
				+ "	org_map a on a.id = " + areaId + " "
				+ "left join"
				+ "	org_map t on t.id in"
				+ "    ("
				+ "		select"
				+ "			distinct o1.id"
				+ "		from"
				+ "			org_map o1"
				+ "		left join"
				+ "			org_map o2 on o2.parent_id = o1.id"
				+ "		where"
				+ "			o1.FISCAL_YEAR = " + fiscalYear + " and"
				+ "			o1.PARENT_ID = " + areaId
				+ "    )"
				+ "left join"
				+ "	org_map g on g.id in"
				+ "    ("
				+ "		select"
				+ "			o1.id"
				+ "		from"
				+ "			org_map o1"
				+ "		left join"
				+ "			org_map o2 on o2.parent_id = o1.id"
				+ "		where"
				+ "			o1.FISCAL_YEAR = " + fiscalYear + " and"
				+ "			o1.PARENT_ID = t.id"
				+ "    ) "
				+ "where"
				+ "	tc.FISCAL_YEAR = " + fiscalYear + " and"
				+ "    tc.TIME_CODE not in"
				+ "    ("
				+ "		select"
				+ "			v.time_code"
				+ "		from"
				+ "			hourandinventory_view v"
				+ "		where"
				+ "			v.calendar_month = " + calendarMonth + " and"
				+ "            v.FISCAL_YEAR = " + fiscalYear + " and"
				+ "            v.FUNCTION_ID = f.id and"
				+ "            v.AREA_ID = a.id and"
				+ "            v.TERRITORY_ID and"
				+ "            v.group_id = g.id"
				+ "    ) "
				+ "group by"
				+ " tc.TIME_CODE, f.id, a.id, t.id, g.id";
		
//		Query query = session.createQuery("select m.name as employeeName, m.department.name as departmentName" 
//				  + " from com.baeldung.hibernate.entities.DeptEmployee m");
//				query.setResultTransformer(Transformers.aliasToBean(Result.class));
//				List<Result> results = query.list();
				
		q = sessionFactory.getCurrentSession().createSQLQuery(qryStr);
		q.setResultTransformer(Transformers.aliasToBean(MissingHourAndInventoryRecord.class));

		
		mrList = q.list();
		
		
		
		return mrList;
		
	}
	
	
	
	private static Long convertToLong(Object o){
        String stringToConvert = String.valueOf(o);
        Long convertedLong = Long.parseLong(stringToConvert);
        return convertedLong;

    }
	
	
}
