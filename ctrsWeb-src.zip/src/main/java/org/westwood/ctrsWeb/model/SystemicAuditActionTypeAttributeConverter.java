package org.westwood.ctrsWeb.model;

import javax.persistence.AttributeConverter;

public class SystemicAuditActionTypeAttributeConverter implements AttributeConverter<SystemicAuditActionType, Integer> {

	@Override
    public Integer convertToDatabaseColumn(SystemicAuditActionType attribute) {
        if (attribute == null)
            return null;
 
        
        switch (attribute) {
        case UPDATE_HOUR_AND_INVENTORY:
        	return 0;
        	
        case UPDATE_TIME_CODE:
        	return 1;
        	
        case UPDATE_ORG_MAP:
        	return 2;
        	
        case DATA_QUEUE:
        	return 3;
        	
        case REQUEST_REPORT:
        	return 4;
        	
        case CANCEL_REPORT:
        	return 5;
        	
        case CREATE_USER:
        	return 6;
        	
        case UPDATE_USER:
        	return 7;
        	
        case DELETE_USER:
        	return 8;
 
        default:
            throw new IllegalArgumentException(attribute + " not supported.");
        }
    }
 
    @Override
    public SystemicAuditActionType convertToEntityAttribute(Integer dbData) {
        if (dbData == null)
            return null;
 
        switch (dbData) {
        case 0:
        	return SystemicAuditActionType.UPDATE_HOUR_AND_INVENTORY;
        	
        case 1:
        	return SystemicAuditActionType.UPDATE_TIME_CODE;
        	
        case 2:
        	return SystemicAuditActionType.UPDATE_ORG_MAP;
        	
        case 3:
        	return SystemicAuditActionType.DATA_QUEUE;
        	
        case 4:
        	return SystemicAuditActionType.REQUEST_REPORT;
        	
        case 5:
        	return SystemicAuditActionType.CANCEL_REPORT;
        	
        case 6:
        	return SystemicAuditActionType.CREATE_USER;
        	
        case 7:
        	return SystemicAuditActionType.UPDATE_USER;
        	
        case 8:
        	return SystemicAuditActionType.DELETE_USER;
 
        default:
            throw new IllegalArgumentException(dbData + " not supported.");
        }
    }
    
    
}
