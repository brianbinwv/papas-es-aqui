package org.westwood.ctrsWeb.model;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;


@Converter
public class TaskTypeAttributeConverter implements AttributeConverter<TaskType, Integer> {
 
    @Override
    public Integer convertToDatabaseColumn(TaskType attribute) {
        if (attribute == null)
            return null;
 
        switch (attribute) {
        case INIT_MISSING_RECORDS:
            return 0;
 
        default:
            throw new IllegalArgumentException(attribute + " not supported.");
        }
    }
 
    @Override
    public TaskType convertToEntityAttribute(Integer dbData) {
        if (dbData == null)
            return null;
 
        switch (dbData) {
        case 0:
            return TaskType.INIT_MISSING_RECORDS;
 
        default:
            throw new IllegalArgumentException(dbData + " not supported.");
        }
    }
 
}