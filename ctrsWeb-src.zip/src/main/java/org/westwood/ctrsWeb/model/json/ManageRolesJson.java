package org.westwood.ctrsWeb.model.json;

import java.util.List;

public class ManageRolesJson {

	private Long userId;

	private List<RoleJson> roles;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public List<RoleJson> getRoles() {
		return roles;
	}

	public void setRoles(List<RoleJson> roles) {
		this.roles = roles;
	}
	
	
}
