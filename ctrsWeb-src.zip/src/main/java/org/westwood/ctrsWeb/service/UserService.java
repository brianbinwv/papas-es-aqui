package org.westwood.ctrsWeb.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.PermittedOrgMap;
import org.westwood.ctrsWeb.model.PermittedRole;
import org.westwood.ctrsWeb.model.Role;
import org.westwood.ctrsWeb.model.User;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.dao.OrgMapRepository;
import org.westwood.ctrsWeb.dao.PermittedOrgMapRepository;
import org.westwood.ctrsWeb.dao.PermittedRoleRepository;
import org.westwood.ctrsWeb.dao.RoleRepository;
import org.westwood.ctrsWeb.dao.UserRepository;



@Service
@Transactional
public class UserService implements CtrsBusinessService {

	@Autowired
	private UserRepository repo;
	
	@Autowired
	private PermittedRoleRepository pRoleRepo;
	
	@Autowired
	private PermittedOrgMapRepository pOrgRepo;
	
	@Autowired
	private OrgMapRepository orgRepo;
	
	@Autowired
	private RoleRepository roleRepo;
	
	
	
	
	
	public User findById(Long id) {
		return (User)repo.findById(id);
	}
	
	
	public UserContainer findUserContainerById(Long id) {
		UserContainer uc = new UserContainer();
		List<Role> roles = new ArrayList<Role>();
		List<PermittedOrgMap> orgMap = new ArrayList<PermittedOrgMap>();
		
		User u = this.findById(id);
		List<CtrsEntity> pList = pRoleRepo.findByUserId(id);
		List<CtrsEntity> oList = pOrgRepo.findByUserId(id);
		
		for (CtrsEntity r : pList) {
			roles.add(((PermittedRole)r).getRole());
		}
		
		for (CtrsEntity o : oList) {
			orgMap.add((PermittedOrgMap)o);
		}
		
		uc.setUser(u);
		uc.setRoles(roles);
		uc.setOrgMap(orgMap);
		
		return uc;
	}
	
	
	public UserContainer findUserContainerBySeid(String seid) {
		UserContainer uc = new UserContainer();
		List<Role> roles = new ArrayList<Role>();
		List<PermittedOrgMap> orgMap = new ArrayList<PermittedOrgMap>();
		
		User u = this.findUserBySeid(seid);
		List<CtrsEntity> pList = pRoleRepo.findByUserId(u.getId());
		List<CtrsEntity> oList = pOrgRepo.findByUserId(u.getId());
		
		for (CtrsEntity r : pList) {
			roles.add(((PermittedRole)r).getRole());
		}
		
		for (CtrsEntity o : oList) {
			orgMap.add((PermittedOrgMap)o);
		}
		
		uc.setUser(u);
		uc.setRoles(roles);
		uc.setOrgMap(orgMap);
		
		return uc;
	}
	
	
	public User findUserBySeid(String seid) {
		return (User)repo.findBySeid(seid);
	}
	
	
	public List<User> findAll() {
		List<User> users = new ArrayList<User>();
		// empty list
		List<Criterion> crit = new ArrayList<Criterion>();
				
		for (CtrsEntity e : repo.findAll(crit)) {
			users.add((User) e);
		}
				
		return users;
	}
	
	
//	public Long create(String seid, String lastName, String firstName, String email, List<Role> roles) {
//		User user = new User();
//		user.setSeid(seid);
//		user.setLastName(lastName);
//		user.setFirstName(firstName);
//		user.setEmail(email);
//		
//		for (Role r : roles) {
//			PermittedRole pr = new PermittedRole();
//			pr.setRole(r);
//			pr.setUser(user);
//			user.addPermittedRole(pr);
//		}
//
//		repo.create(user);
//		
//		return user.getId() != null ? user.getId() : -1L;
//	}
	
	
	public Long create(String seid, String lastName, String firstName, String email) {
		User user = new User();
		user.setSeid(seid);
		user.setLastName(lastName);
		user.setFirstName(firstName);
		user.setEmail(email);
		
		repo.create(user);
		
		return user.getId() != null ? user.getId() : -1L;
	}
	
	
	public Long createOrgMap(Long userId, Long functionId, Long areaId) {
		PermittedOrgMap p = new PermittedOrgMap();
		OrgMap f = new OrgMap();
		OrgMap a = new OrgMap();
		
		f = (OrgMap)orgRepo.findById(functionId);
		a = (OrgMap)orgRepo.findById(areaId);
		
		
		p.setUserId(userId);
		p.setFunction(f);
		p.setArea(a);
		
		pOrgRepo.create(p);
		
		return p.getId() != null ? p.getId() : -1L;
	}
	
	
	public Long addRole(Long userId, Long roleId) {
		PermittedRole p = new PermittedRole();
		Role r = new Role();
		
		r = (Role)roleRepo.findById(roleId);
		
		
		p.setUserId(userId);
		p.setRole(r);
		
		pRoleRepo.create(p);
		
		return p.getId() != null ? p.getId() : -1L;
	}
	
	
	public void removeRole(Long userId, Long roleId) {
		List<CtrsEntity> permittedRoles = new ArrayList<CtrsEntity>();
		
		permittedRoles = pRoleRepo.findByUserId(userId);
		
		for (CtrsEntity e : permittedRoles) {
			if (((PermittedRole)e).getRole().getId() == roleId ) {
				pRoleRepo.delete(e);
			}
		}
	}
	
	
	public void update(User u) {
		repo.update(u);
	}

	
	public void delete(Long id) {
//		OrgMap org = this.findById(id);
//		repo.delete(org);
	}
	
	
}

