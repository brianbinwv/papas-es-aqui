package org.westwood.ctrsWeb.service;

public interface CtrsBusinessService {

	
//	public void dispose();
	
}
