package org.westwood.ctrsWeb.model.container;

import java.util.List;

import org.westwood.ctrsWeb.model.json.DataQueueJson;


public class WASMGRDataQueueContainer extends DataQueueContainer {

	private Boolean canSendAreaToSuper = true;
	private Boolean canReturnAreaToWAS = true;
	
	
	public Boolean getCanSendAreaToSuper() {
		return canSendAreaToSuper;
	}

	public Boolean getCanReturnAreaToWAS() {
		return canReturnAreaToWAS;
	}
	

	@Override
	public void setData(List<DataQueueJson> data) {

		super.setData(data);
		
		for (DataQueueJson d : data) {
			if (!d.getRoleName().equals("WAS_MGR")) {
				canSendAreaToSuper = false;
				canReturnAreaToWAS = false;
			}
		}
	}
	
}
