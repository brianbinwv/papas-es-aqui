package org.westwood.ctrsWeb.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class CtrsSecurityInitializer extends AbstractSecurityWebApplicationInitializer {

	// CODE IS NOT REQUIRED
	
	
}