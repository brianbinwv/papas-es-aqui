package org.westwood.ctrsWeb.security.config;

import javax.servlet.Filter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.westwood.ctrsWeb.security.filters.CtrsRequestHeaderAuthenticationProcessingFilter;
import org.westwood.ctrsWeb.security.providers.CtrsAuthenticationProvider;
import org.westwood.ctrsWeb.security.services.CtrsUserDetailsService;

 
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    
//	@Autowired
//    private DataSource dataSource;
	
	
	@Autowired
	private CtrsAuthenticationProvider ctrsAuthenticationProvider;
	
//	private CtrsAuthenticationProvider customAuthenticationProvider = new CtrsAuthenticationProvider();
	
	
    @Bean
    public UserDetailsService userDetailsService() {
        return new CtrsUserDetailsService();
    }
    
    

    @Bean
    public CtrsAuthenticationProvider authenticationProvider() {
    	
    	if (ctrsAuthenticationProvider == null) {
    		ctrsAuthenticationProvider = new CtrsAuthenticationProvider();
    	}
    	
    	if (ctrsAuthenticationProvider.userDetailsServiceIsNull()) {
    		ctrsAuthenticationProvider.setUserDetailsService(userDetailsService());
    	}
    	
    	return ctrsAuthenticationProvider;
    }
 
 
    @Override
    protected void configure(HttpSecurity http) throws Exception {
    	
    	
    	http
    		.httpBasic().disable()
    		.csrf().disable()
    		.formLogin().disable()
    		.logout().disable()
    		.authenticationProvider(authenticationProvider())
    		.addFilterBefore(getFilter(), AnonymousAuthenticationFilter.class).authorizeRequests()
    		.antMatchers("/admin/**").hasAuthority("SYSTEM_ADMIN")
    		.anyRequest().permitAll();
    		
    	http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.ALWAYS);
    	
    }

    
    private RequestMatcher getRequestMatchers() {
    	return new OrRequestMatcher(new AntPathRequestMatcher("/**"));
    }
    
    
    private Filter getFilter() throws Exception {
    	return new CtrsRequestHeaderAuthenticationProcessingFilter(getRequestMatchers(), authenticationManager());
    }
    
    
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    	auth.authenticationProvider(authenticationProvider());
    }
    
    
    

    
     
}