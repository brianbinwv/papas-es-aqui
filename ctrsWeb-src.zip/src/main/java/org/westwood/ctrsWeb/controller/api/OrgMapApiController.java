package org.westwood.ctrsWeb.controller.api;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.container.OrgMapContainer;
import org.westwood.ctrsWeb.model.json.OrgJson;
import org.westwood.ctrsWeb.model.json.TimeCodeJson;
import org.westwood.ctrsWeb.service.OrgMapService;
import org.westwood.ctrsWeb.service.UserService;

import com.google.gson.Gson;


@Controller
@RequestMapping("/orgs/api")
public class OrgMapApiController {

	
	@Autowired
	private OrgMapService orgService;


	
	
	@RequestMapping(value = "/get-available-fys", method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public List<Long> getAvailableFys() {
		List<Long> fyList = orgService.findAllFiscalYears();
		
		return fyList;
	}
	
	
	@RequestMapping(value = "/get-formatted-child-orgs/{id}", method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public OrgMapContainer getFormattedChildOrgsById(@PathVariable Long id) {
		OrgMapContainer container = new OrgMapContainer();
		//OrgMap org = orgService.findById(id);
		
		List<OrgMap> orgList = orgService.findAllByParent(id);
		container.setData(orgList);
		
		return container;
	}
	
	
	
	@RequestMapping(value = "/get-child-orgs/{parentId}", method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public List<OrgMap> getChildOrgsById(@PathVariable Long parentId) {
		List<OrgMap> orgList = orgService.findAllByParent(parentId);
				
		return orgList;
	}
	
	
	@RequestMapping(value = "/get-first-level-orgs-by-fy/{fiscalYear}", method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public List<OrgMap> getFirstLevelOrgsByFY(@PathVariable Long fiscalYear) {
		List<OrgMap> orgList = new ArrayList<OrgMap>();
		
		System.out.println("fiscal year: " + fiscalYear);
		orgList = orgService.findFirstLevelOrgsByFY(fiscalYear);
		
		
		return orgList;
	}
	
	
	@PostMapping("/update-org")
	@ResponseBody
	public ResponseEntity<String> updateOrg(@RequestBody OrgJson orgObj) {
		
		
		// TODO: get roles from security context
		//UserContainer container = userService.findUserContainerById(1L);
		
		
		
		// ****SECURITY CHECK****
		
		
		
		// ****END SECURITY CHECK****
		
				
		
		try {
			// request the update
			orgService.update(orgObj.getId(), orgObj.getOrgName());
			

			//System.out.println(h.toString());

			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
	
	
	
}

