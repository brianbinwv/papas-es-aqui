package org.westwood.ctrsWeb.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.PermittedRole;
import org.westwood.ctrsWeb.model.Role;

@Repository
public class PermittedRoleRepository implements CtrsCrudRepository{
	@Autowired
    private SessionFactory sessionFactory;
	
	
	public CtrsEntity find(CtrsEntity ent) {
		//@SuppressWarnings("deprecation")
		//Criteria cr = sessionFactory.getCurrentSession().createCriteria(User.class);
		
		//return (User)cr.uniqueResult();
		return null;
	}

	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(PermittedRole.class).add(Restrictions.eq("id", id));
		return (PermittedRole)cr.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findByUserId(Long userId) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(PermittedRole.class);

		cr.add(Restrictions.eq("userId", userId));
		
		return (List<CtrsEntity>)cr.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findByUserIdAndRole(Long userId, Role role) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(PermittedRole.class);

		cr.add(Restrictions.eq("userId", userId));
		cr.add(Restrictions.eq("role", role));
		
		return (List<CtrsEntity>)cr.list();

	}
		
	//@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
//		@SuppressWarnings("deprecation")
//		Criteria cr = sessionFactory.getCurrentSession().createCriteria(CtrsHourAndInventory.class);
//
//		
//		for (Criterion c : queryCriterion) {
//			cr.add(c);
//		}
//		
//		cr.createAlias("timeCode", "a1");
//		cr.addOrder(Order.asc("a1.timeCode"));
//		
//		
//		return (List<CtrsEntity>)cr.list();
		
		return null;
	}
	
	public Long create(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	public void update(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().update(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	public void delete(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().delete(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	public void closeSession() {
		this.sessionFactory.getCurrentSession().close();
	}
	
}
