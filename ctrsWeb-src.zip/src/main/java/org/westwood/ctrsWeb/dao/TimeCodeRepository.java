package org.westwood.ctrsWeb.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.TimeCode;

@Repository
public class TimeCodeRepository implements CtrsCrudRepository {

	//private Session session = null;
	@Autowired
    private SessionFactory sessionFactory;
	
	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(TimeCode.class).add(Restrictions.eq("id", id));
		return (TimeCode)cr.uniqueResult();
	}
	
	public CtrsEntity find(CtrsEntity ent) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(TimeCode.class);
		
		TimeCode tc = (TimeCode)ent;
		
		cr.add(Restrictions.eq("function", tc.getFunction()));
		cr.add(Restrictions.eq("area", tc.getArea()));
		cr.add(Restrictions.eq("territory", tc.getTerritory()));
		cr.add(Restrictions.eq("timeCode", tc.getTimeCode()));
		cr.add(Restrictions.eq("fiscalYear", tc.getFiscalYear()));
		return (TimeCode)cr.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(TimeCode.class);
		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		return (List<CtrsEntity>)cr.list();
	}

	public Long create(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	public void update(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	public void delete(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().delete(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	

	
	
}
