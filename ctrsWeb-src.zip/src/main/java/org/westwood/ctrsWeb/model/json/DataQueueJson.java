package org.westwood.ctrsWeb.model.json;


public class DataQueueJson {

	private Long id;
	private Long orgCode;
	private String orgName;
	private String roleName;
	private Boolean canSendToWAS = false;
	private Boolean canReturnToVTS = false;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(Long orgCode) {
		this.orgCode = orgCode;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
		
		if (this.roleName.equals("VTS")) {
			canSendToWAS = true;
		}
		
		if (this.roleName.equals("WAS")) {
			canReturnToVTS = true;
		}
	}
	public Boolean getCanSendToWAS() {
		return canSendToWAS;
	}
	public Boolean getCanReturnToVTS() {
		return canReturnToVTS;
	}
}
