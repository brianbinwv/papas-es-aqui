package org.westwood.ctrsWeb.model.container;

import java.util.List;

import org.westwood.ctrsWeb.model.json.DataQueueJson;

public class SuperCTRSAnalystDataQueueContainer extends DataQueueContainer {

	private Boolean canReturnAreaToWASMGR = true;
	
	
	public Boolean getCanReturnAreaToWASMGR() {
		return canReturnAreaToWASMGR;
	}
	

	@Override
	public void setData(List<DataQueueJson> data) {

		super.setData(data);
		
		for (DataQueueJson d : data) {
			if (!d.getRoleName().equals("SUPER_CTRS_ANALYST")) {
				canReturnAreaToWASMGR = false;
			}
		}
	}
	
}
