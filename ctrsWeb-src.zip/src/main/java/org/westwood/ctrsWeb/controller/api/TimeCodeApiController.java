package org.westwood.ctrsWeb.controller.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.model.HourAndInventory;
import org.westwood.ctrsWeb.model.TimeCode;
import org.westwood.ctrsWeb.model.DataQueue;
import org.westwood.ctrsWeb.model.json.DataQueueJson;
import org.westwood.ctrsWeb.model.json.InventoryJson;
import org.westwood.ctrsWeb.model.lightweight.LW__HourAndInventory;
import org.westwood.ctrsWeb.model.container.LW__HourAndInventoryContainer;
import org.westwood.ctrsWeb.model.container.TimeCodeContainer;
import org.westwood.ctrsWeb.model.json.TimeCodeJson;
import org.westwood.ctrsWeb.model.container.VTSDataQueueContainer;
import org.westwood.ctrsWeb.security.PermissionValidator;
import org.westwood.ctrsWeb.service.HourAndInventoryService;
import org.westwood.ctrsWeb.service.OrgMapService;
import org.westwood.ctrsWeb.service.TimeCodeService;
import org.westwood.ctrsWeb.service.DataQueueService;
import org.westwood.ctrsWeb.service.HourAndInventoryMetadataService;
import org.westwood.ctrsWeb.service.LW__HourAndInventoryService;
import org.westwood.ctrsWeb.service.UserService;

@Controller
@RequestMapping("/timecode/api")
public class TimeCodeApiController {
	
	
	@Autowired
	private TimeCodeService timeCodeService;
	
	
	
	@RequestMapping(value = "/get-time-codes", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<TimeCodeContainer> getTimeCodes(
			@RequestParam("functionId") Long functionId,
			@RequestParam("type") Long type) {

		TimeCodeContainer container = new TimeCodeContainer();
		List<TimeCode> tcList = new ArrayList<TimeCode>();

		
		if (type == 0L) {
			tcList = timeCodeService.findAllByFunction(functionId);
		}
		else {
			tcList = timeCodeService.findAllByFunction(functionId, true);
		}
		
		
		if (tcList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		container.setData(tcList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);

	}
	
	
	@PostMapping("/update-timecode")
	@ResponseBody
	public ResponseEntity<String> updateInventory(@RequestBody TimeCodeJson tcObj) {
		
		
		// TODO: get roles from security context
		//UserContainer container = userService.findUserContainerById(1L);
		
		
		
		
		
		// ****SECURITY CHECK****
		
		
		
		// ****END SECURITY CHECK****
		
				
		
		try {
			// request the update
			timeCodeService.update(tcObj.getId(), tcObj.getDescription());


			//System.out.println(h.toString());

			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
	
}
