package org.westwood.ctrsWeb.controller.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.westwood.ctrsWeb.model.Role;
import org.westwood.ctrsWeb.model.User;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.model.json.AddUserJson;
import org.westwood.ctrsWeb.model.json.ManageRolesJson;
import org.westwood.ctrsWeb.model.json.OrgMapJson;
import org.westwood.ctrsWeb.model.json.RoleJson;
import org.westwood.ctrsWeb.model.json.UserJson;
import org.westwood.ctrsWeb.service.RoleService;
import org.westwood.ctrsWeb.service.UserService;

@Controller
@RequestMapping("/admin/api")
public class AdminApiController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private RoleService roleService;
	
	
	
	@RequestMapping(value = "/validate-seid", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<Boolean> validateSeid(@RequestParam("seid") String seid) {
		User u = new User();
		
		u = userService.findUserBySeid(seid);
		
		if (u == null) {
			System.out.println("seid not found");
			return ResponseEntity.status(HttpStatus.OK).body(true);
		}
		
		if (u.getSeid().length() > 0) {
			System.out.println(u.toString());
			System.out.println("return false");
			return ResponseEntity.status(HttpStatus.OK).body(false);
		}
		
		System.out.println("SEID does not exist, return true");
		return ResponseEntity.status(HttpStatus.OK).body(true);
	}
	
	
	@RequestMapping(value = "/get-all-users", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<UserJson> getAllUsers() {
		UserJson h = new UserJson();
		List<User> uList = new ArrayList<User>();
		
		uList = userService.findAll();
		
		h.setData(uList);
		return ResponseEntity.status(HttpStatus.OK).body(h);
	}
	
	
	@RequestMapping(value = "/get-all-roles", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<List<Role>> getAllRoles() {
		List<Role> roles = new ArrayList<Role>();
		
		roles = roleService.findAll();
		
		
		return ResponseEntity.status(HttpStatus.OK).body(roles);
	}
	
	
	@RequestMapping(value = "/get-roles-not-a-member", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<List<Role>> getRolesNotAMember(@RequestParam("id") Long userId) {
		UserContainer container = userService.findUserContainerById(userId);
		List<Role> roles = new ArrayList<Role>();
		List<Role> availableRoles = new ArrayList<Role>();
		
		roles = roleService.findAll();
		
		
		for (Role r : roles) {
			
			boolean isMatch = false;
			for (Role currentRole : container.getRoles()) {
				if (r.getId() == currentRole.getId()) {
					isMatch = true;
				}
			}

			if (!isMatch) {
				System.out.println("role match not found...add to list");
				availableRoles.add(r);
			}
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(availableRoles);
	}
	
	
	@RequestMapping(value = "/who-are-u", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<UserContainer> whoAreYou(@RequestParam("id") Long userId) {
		UserContainer container = userService.findUserContainerById(userId);
		System.out.println(container.toString());
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	
	@PostMapping("/add-user")
	@ResponseBody
	public ResponseEntity<String> addUser(@RequestBody AddUserJson userObj) {
		Long userId = 0L;
		
		// TODO: get roles from security context
		//UserContainer container = userService.findUserContainerById(1L);
		
		
		// ****SECURITY CHECK****
//			if (!PermissionValidator.canEdit(container, h)) {
//				return ResponseEntity.status(HttpStatus.FORBIDDEN).body("insufficient privilege");
//			}
		// ****END SECURITY CHECK****
		
				
		try {
			
			System.out.println(userObj.toString());

			System.out.println("before create user");
			userId =  userService.create(userObj.getSeid(), userObj.getLastName(), userObj.getFirstName(), userObj.getEmail());
			System.out.println("after create user");
			
			
			for (OrgMapJson o : userObj.getOrgMaps()) {
				System.out.println("before create org map");
				userService.createOrgMap(userId, o.getFunctionId(), o.getAreaId());
				System.out.println("after create org map");
			}

			for (RoleJson r : userObj.getRoles()) {
				System.out.println("before create role");
				userService.addRole(userId, r.getId());
				System.out.println("after create role");
			}
			
						
			return ResponseEntity.status(HttpStatus.OK).body("ok");
		
		}
		catch (Exception e) {
			System.out.println(e.getMessage().toString() + "\n" + e.getStackTrace().toString());
			return ResponseEntity.status(HttpStatus.CONFLICT).body("failed");
		}
	}
	
	
	
	@PostMapping("/add-roles")
	@ResponseBody
	public ResponseEntity<String> addRoles(@RequestBody ManageRolesJson mgrObj) {
		Long userId = mgrObj.getUserId();
	
		
		
		// TODO: get roles from security context
		//UserContainer container = userService.findUserContainerById(1L);
		
		
		// ****SECURITY CHECK****

		
		
		// ****END SECURITY CHECK****
		
		
		
		try {
		
			for (RoleJson r : mgrObj.getRoles()) {
				
				userService.addRole(userId, r.getId());
				
			}
						
			return ResponseEntity.status(HttpStatus.OK).body("ok");
		
		}
		catch (Exception e) {
			System.out.println(e.getMessage().toString() + "\n" + e.getStackTrace().toString());
			return ResponseEntity.status(HttpStatus.CONFLICT).body("failed");
		}
	}
	
	
	@PostMapping("/remove-roles")
	@ResponseBody
	public ResponseEntity<String> removeRoles(@RequestBody ManageRolesJson mgrObj) {
		Long userId = mgrObj.getUserId();
	
		
		// TODO: get roles from security context
		//UserContainer container = userService.findUserContainerById(1L);
		
		
		// ****SECURITY CHECK****

		
		
		// ****END SECURITY CHECK****
		
		
		
		try {
		
			for (RoleJson r : mgrObj.getRoles()) {
				
				userService.removeRole(userId, r.getId());
				
			}
						
			return ResponseEntity.status(HttpStatus.OK).body("ok");
		
		}
		catch (Exception e) {
			System.out.println(e.getMessage().toString() + "\n" + e.getStackTrace().toString());
			return ResponseEntity.status(HttpStatus.CONFLICT).body("failed");
		}
	}
	
	
	
	
	
	
//		@RequestMapping(value = "/api/get-missing-records", 
//				method = RequestMethod.GET, produces="application/json")
//		@ResponseBody
//		public ResponseEntity<MissingHourAndInventoryContainer> getMissingRecords(
//				@RequestParam("functionId") Long functionId,
//				@RequestParam("areaId") Long areaId,
//				@RequestParam("calendarMonth") Long calendarMonth,
//				@RequestParam("fiscalYear") Long fiscalYear) {
//			MissingHourAndInventoryContainer c = new MissingHourAndInventoryContainer();
//			List<MissingHourAndInventoryRecord> mrList = new ArrayList<MissingHourAndInventoryRecord>();
//			mrList = lwService.findMissingRecords_2(functionId, areaId, fiscalYear, calendarMonth);
//			
//			if (mrList == null) {
//				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//			}
//			
//			c.setData(mrList);
//			return ResponseEntity.status(HttpStatus.OK).body(c);
//		}
//	
//	
//		@RequestMapping(value = "/api/create-missing-records", 
//				method = RequestMethod.GET, produces="application/json")
//		@ResponseBody
//		public ResponseEntity<MissingHourAndInventoryContainer> schedule_task__createMissingRecords(
//				@RequestParam("functionId") Long functionId,
//				@RequestParam("areaId") Long areaId,
//				@RequestParam("calendarMonth") Long calendarMonth,
//				@RequestParam("fiscalYear") Long fiscalYear) {
//			MissingHourAndInventoryContainer c = new MissingHourAndInventoryContainer();
//			List<MissingHourAndInventoryRecord> mrList = new ArrayList<MissingHourAndInventoryRecord>();
//			mrList = lwService.findMissingRecords_2(functionId, areaId, fiscalYear, calendarMonth);
//			
//			if (mrList == null) {
//				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//			}
//			
//			c.setData(mrList);
//			return ResponseEntity.status(HttpStatus.OK).body(c);
//		}
	
	
	
	
	
	
}
