package org.westwood.ctrsWeb.dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.SystemicAudit;


@Repository
public class SystemicAuditRepository implements CtrsCrudRepository {

	@Autowired
    private SessionFactory sessionFactory;
	
	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(SystemicAudit.class).add(Restrictions.eq("id", id));
		return (SystemicAudit)cr.uniqueResult();
	}
	
	public CtrsEntity find(CtrsEntity ent) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(SystemicAudit.class);
		
		SystemicAudit s = (SystemicAudit)ent;
		
		cr.add(Restrictions.eq("userId", s.getUserId()));
		cr.add(Restrictions.eq("createdDate", s.getCreatedDate()));
		cr.add(Restrictions.eq("actionType", s.getActionType()));
		return (SystemicAudit)cr.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(SystemicAudit.class);
		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		return (List<CtrsEntity>)cr.list();
	}

	public Long create(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	@Override
	public void update(CtrsEntity ent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(CtrsEntity ent) {
		// TODO Auto-generated method stub
		
	}

	
	
	
}
