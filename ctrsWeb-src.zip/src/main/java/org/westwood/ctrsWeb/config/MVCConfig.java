package org.westwood.ctrsWeb.config;

import java.util.Properties;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
//import org.hibernate.cfg.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
//import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.AbstractDataSource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;



@EnableWebMvc
@Configuration
@PropertySource("classpath:database.properties")
@PropertySource("classpath:activemq.properties")
@EnableTransactionManagement
@ComponentScan(basePackages = { "org.westwood.ctrsWeb" })
public class MVCConfig implements WebMvcConfigurer {

	
	@Autowired
    private Environment environment;
	
	
	// looks like this would be used if there were no controller classes
//   @Override
//   public void addViewControllers(ViewControllerRegistry registry) {
//      registry.addViewController("/").setViewName("index");
//   }

   @Bean
   public ViewResolver viewResolver() {
      InternalResourceViewResolver bean = new InternalResourceViewResolver();

      bean.setViewClass(JstlView.class);
      bean.setPrefix("/WEB-INF/views/");
      bean.setSuffix(".jsp");

      return bean;
   }
   
   
// <!-- Step 1: Define Database DataSource / connection pool -->
// <bean id="dataSource" class="org.springframework.jdbc.datasource.DriverManagerDataSource">
//     <property name="driverClassName" value="com.mysql.jdbc.Driver" />
//     <property name="url" value="jdbc:mysql://localhost:3306/ctrs" />
//     <property name="username" value="root" />
//     <property name="password" value="HL4@(mpA)25!" />
// </bean>
   
//   <!-- Step 2: Setup Hibernate session factory -->
//   <bean id="sessionFactory" class="org.springframework.orm.hibernate5.LocalSessionFactoryBean">
//       <property name="dataSource" ref="dataSource" />
//       <property name="packagesToScan" value="org.westwood.ctrsWeb.model" />
//       <property name="hibernateProperties">
//           <props>
//               <prop key="hibernate.dialect">org.hibernate.dialect.MySQLDialect</prop>
//               <prop key="hibernate.show_sql">true</prop>
//               <prop key="hibernate.hbm2ddl.auto">none</prop>
//				<prop key="hibernate.format_sql">true</prop>
//           </props>
//       </property>
//   </bean>
   
   
   @Bean
   public LocalSessionFactoryBean sessionFactory() {
       LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
       sessionFactory.setDataSource(dataSource());
       sessionFactory.setPackagesToScan(new String[] {
           "org.westwood.ctrsWeb.model"
       });
       
       sessionFactory.setHibernateProperties(hibernateProperties());
       return sessionFactory;
   }
      
   @Bean
   public AbstractDataSource dataSource() {
       DriverManagerDataSource dataSource = new DriverManagerDataSource();
       dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.driverClassName"));
       dataSource.setUrl(environment.getRequiredProperty("jdbc.url"));
       dataSource.setUsername(environment.getRequiredProperty("jdbc.username"));
       dataSource.setPassword(environment.getRequiredProperty("jdbc.password"));
       return dataSource;
   }
   
   
   private Properties hibernateProperties() {
       Properties properties = new Properties();
       properties.put("hibernate.dialect", environment.getRequiredProperty("hibernate.dialect"));
       properties.put("hibernate.show_sql", environment.getRequiredProperty("hibernate.show_sql"));
       properties.put("hibernate.format_sql", environment.getRequiredProperty("hibernate.format_sql"));
       properties.put("hibernate.hbm2ddl.auto", environment.getRequiredProperty("hibernate.hbm2ddl.auto"));
       return properties;
   }
   


   
// <!-- Step 3: Setup Hibernate transaction manager -->
// <bean id="transactionManager"
//         class="org.springframework.orm.hibernate5.HibernateTransactionManager">
//     <property name="sessionFactory" ref="sessionFactory"/>
// </bean>   

// <!-- Step 4: Enable configuration of transactional behavior based on annotations -->
// <tx:annotation-driven transaction-manager="transactionManager" />
// 

   
   @Bean
   public HibernateTransactionManager getTransactionManager() {
       HibernateTransactionManager transactionManager = new HibernateTransactionManager();
       transactionManager.setSessionFactory(sessionFactory().getObject());
       return transactionManager;
   }
   

// <!-- Add support for reading web resources: css, images, js, etc ... -->
// <mvc:resources location="/resources/" mapping="/resources/**"></mvc:resources>   
   
   @Override
   public void addResourceHandlers(ResourceHandlerRegistry registry) {
       registry
           .addResourceHandler("/resources/**")
           .addResourceLocations("/resources/");
   }
   
   
   
   
//   <!-- A connection to ActiveMQ --> 
//	<bean id="jmsConnectionFactory" class="org.apache.activemq.ActiveMQConnectionFactory"> 
//		<property name="brokerURL">
//			<value>tcp://localhost:61616</value>
//		</property>
//   </bean>

   @Bean
   public ActiveMQConnectionFactory jmsConnectionFactory() {
	   
	   ActiveMQConnectionFactory connFactory = new ActiveMQConnectionFactory();
	   
	   connFactory.setBrokerURL(environment.getRequiredProperty("activemq.brokerUrl"));
	   
	   return connFactory;
   }
   
   
//	<!-- A cached connection to wrap the ActiveMQ connection --> 
//	<bean id="cachedConnectionFactory" class="org.springframework.jms.connection.CachingConnectionFactory">
//		<property name="targetConnectionFactory" ref="jmsConnectionFactory" />
//		<property name="sessionCacheSize">
//			<value>10</value>
//		</property>
//	</bean>

   
   @Bean
   public CachingConnectionFactory cachedConnectionFactory() {
	   CachingConnectionFactory f = new CachingConnectionFactory();
	   f.setTargetConnectionFactory(jmsConnectionFactory());
	   f.setSessionCacheSize(Integer.valueOf(environment.getRequiredProperty("activemq.SessionCacheSize")));
	   
	   return f;
   }
   
   
//	<!-- A destination in ActiveMQ --> 
//	<bean id="destination" class="org.apache.activemq.command.ActiveMQQueue">
//		<constructor-arg value="FOO.TEST" />
//	</bean>

   @Bean
   public ActiveMQQueue destination() {
	   ActiveMQQueue a = new ActiveMQQueue();
	   
	   a.setPhysicalName(environment.getRequiredProperty("activemq.PhysicalDestinationName"));
	   
	   return a;
   }
   
   
//	<!-- A JmsTemplate instance that uses the cached connection and destination --> 
//	<bean id="producerTemplate" class="org.springframework.jms.core.JmsTemplate">
//		<property name="connectionFactory" ref="cachedConnectionFactory"/>
//		<property name="defaultDestination" ref="destination"/>
//	</bean> 
   
   
   @Bean
   public JmsTemplate producerTemplate() {
	   JmsTemplate j = new JmsTemplate();
	   
	   j.setConnectionFactory(cachedConnectionFactory());
	   j.setDefaultDestination(destination());
	   
	   return j;
	   
   }
   
   
   
}



