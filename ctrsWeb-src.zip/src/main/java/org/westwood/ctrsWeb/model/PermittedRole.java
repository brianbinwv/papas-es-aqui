package org.westwood.ctrsWeb.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "PermittedRole")
@Table(name = "PermittedRole")
public class PermittedRole implements CtrsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID", nullable=false)
	Long id;
	
//	@ManyToOne(fetch = FetchType.LAZY)
//    private User user;
	
	@Column(name = "user_id", nullable = false)
	private Long userId;
	
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@OneToOne
	@JoinColumn(name = "ROLE_ID", nullable=false)
	private Role role;
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
//	public User getUser() {
//		return user;
//	}
//
//	public void setUser(User user) {
//		this.user = user;
//	}
	
	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

//	@Override
//	public String toString() {
//		return "PermittedRole [id=" + id + ", role=" + role + "]";
//	}

	
	
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PermittedRole )) return false;
        return id != null && id.equals(((PermittedRole) o).getId());
    }
 
    @Override
	public String toString() {
		return "PermittedRole [id=" + id + ", userId=" + userId + ", role=" + role + "]";
	}

	@Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
