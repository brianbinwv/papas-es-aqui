package org.westwood.ctrsWeb.model;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
//import org.westwood.ctrsWeb.model.CtrsEntity;

@Entity(name = "OrgMap")
@Table(name = "ORG_MAP", 
uniqueConstraints=@UniqueConstraint(columnNames = {"PARENT_ID", "ORG_CODE", "FISCAL_YEAR"}))
public class OrgMap implements CtrsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "PARENT_ID", nullable = false)
	private Long parentId;
	
	@Column(name = "ORG_CODE", nullable=false)
	private Long orgCode;
	
	@Column(name = "FISCAL_YEAR", nullable = false)
	private Long fiscalYear;
	
	@Column(name = "NAME", nullable = false)
	private String orgName;
	
	@Column(name = "STATUS", nullable = false)
	private Long status;
	
		
	public Long getId() {
		return id;
	}
	  
	public void setId(Long id) {
		this.id = id;
	}

	public Long getParentId() {
		return parentId;
	}

	public Long getOrgCode() {
		return orgCode;
	}

	public String getOrgName() {
		return orgName;
	}

	public Long getStatus() {
		return status;
	}

	public Long getFiscalYear() {
		return fiscalYear;
	}

	public void setParentId(Long code) {
		this.parentId = code;
	}

	public void setOrgCode(Long code) {
		this.orgCode = code;
	}

	public void setOrgName(String name) {
		this.orgName = name;
	}

	public void setFiscalYear(Long fiscalYear) {
		this.fiscalYear = fiscalYear;
	}
	
	public void setStatus(Long status) {
		this.status = status;
	}
	
	public Boolean isActive() {
		return (status == 1) ? true : false;
	}

	public Boolean isParentOf(OrgMap obj) {
		if (this.id == obj.getParentId())
			return true;
		
		return false;
	}
	
	public Boolean isChildOf(OrgMap obj) {
		if (this.parentId == obj.getId())
			return true;
		
		return false;
	}
	
	@Override
	public String toString() {
//		return "CtrsOrg [id=" + id + ", parentId=" + parentId + ", orgCode=" + orgCode + ", fiscalYear="
//				+ fiscalYear + ", orgName=" + orgName + ", active=" + isActive() + "]";
		return orgCode + " - " + orgName;
	}
	
	
	
}
