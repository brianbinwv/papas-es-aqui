package org.westwood.ctrsWeb.model.json;


public class ROCountJson {

	private long id;
	private long roCount;
	private long tpInventory;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getRoCount() {
		return roCount;
	}
	public void setRoCount(long roCount) {
		this.roCount = roCount;
	}
	public long getTpInventory() {
		return tpInventory;
	}
	public void setTpInventory(long tpInventory) {
		this.tpInventory = tpInventory;
	}
		
	
	
}