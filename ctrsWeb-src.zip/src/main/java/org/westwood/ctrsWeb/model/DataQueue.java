package org.westwood.ctrsWeb.model;



import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "DataQueue")
@Table(name = "DATA_QUEUE", uniqueConstraints=@UniqueConstraint(columnNames = {"FUNCTION_ID", "AREA_ID", 
		"TERRITORY_ID", "CALENDAR_MONTH", "FISCAL_YEAR"})) 
public class DataQueue implements CtrsEntity {
	
	// id
	// function
	// area
	// territory
	// month
	// fiscal year
	// current role
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID")
	private Long id;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "FUNCTION_ID", nullable=false)
	private OrgMap function;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "AREA_ID", nullable=false)
	private OrgMap area;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "TERRITORY_ID", nullable=false)
	private OrgMap territory;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ROLE_ID", nullable=false)
	private Role role;

	@Column(name = "CALENDAR_MONTH", nullable = false)
	private Long calendarMonth;
	
	@Column(name = "FISCAL_YEAR", nullable = false)
	private Long fiscalYear;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public OrgMap getFunction() {
		return function;
	}

	public void setFunction(OrgMap function) {
		this.function = function;
	}

	public OrgMap getArea() {
		return area;
	}

	public void setArea(OrgMap area) {
		this.area = area;
	}

	public OrgMap getTerritory() {
		return territory;
	}

	public void setTerritory(OrgMap territory) {
		this.territory = territory;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Long getCalendarMonth() {
		return calendarMonth;
	}

	public void setCalendarMonth(Long calendarMonth) {
		this.calendarMonth = calendarMonth;
	}

	public Long getFiscalYear() {
		return fiscalYear;
	}

	public void setFiscalYear(Long fiscalYear) {
		this.fiscalYear = fiscalYear;
	}

	@Override
	public String toString() {
		return "DataQueue [id=" + id + ", function=" + function + ", area=" + area + ", territory=" + territory
				+ ", role=" + role + ", calendarMonth=" + calendarMonth + ", fiscalYear=" + fiscalYear + "]\n";
	}
	
	
}

