package org.westwood.ctrsWeb.model.json;



public class TaskQueueJson {

	private Long functionId;
	
	private Long areaId;
	
	private Long calendarMonth;
	
	private Long fiscalYear;

	public Long getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}

	public Long getAreaId() {
		return areaId;
	}

	public void setAreaId(Long areaId) {
		this.areaId = areaId;
	}

	public Long getCalendarMonth() {
		return calendarMonth;
	}

	public void setCalendarMonth(Long calendarMonth) {
		this.calendarMonth = calendarMonth;
	}

	public Long getFiscalYear() {
		return fiscalYear;
	}

	public void setFiscalYear(Long fiscalYear) {
		this.fiscalYear = fiscalYear;
	}
	
	
	
	
}
