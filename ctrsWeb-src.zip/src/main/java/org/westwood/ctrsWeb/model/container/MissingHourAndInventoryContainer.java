package org.westwood.ctrsWeb.model.container;

import java.util.ArrayList;
import java.util.List;

import org.westwood.ctrsWeb.model.MissingHourAndInventoryRecord;

public class MissingHourAndInventoryContainer {
	private List<MissingHourAndInventoryRecord> data = new ArrayList<MissingHourAndInventoryRecord>();

	public List<MissingHourAndInventoryRecord> getData() {
		return data;
	}

	public void setData(List<MissingHourAndInventoryRecord> data) {
		this.data = data;
	}
	
}
