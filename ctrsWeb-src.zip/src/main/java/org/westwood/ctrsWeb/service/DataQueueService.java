package org.westwood.ctrsWeb.service;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.dao.OrgMapRepository;
import org.westwood.ctrsWeb.dao.DataQueueRepository;
import org.westwood.ctrsWeb.dao.RoleRepository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.DataQueue;
import org.westwood.ctrsWeb.model.Role;



@Service
@Transactional
public class DataQueueService implements CtrsBusinessService {

	@Autowired
	private OrgMapRepository orgRepo;
	
	@Autowired
	private DataQueueRepository dqRepo;
	
	@Autowired
	private RoleRepository roleRepo;
	
	
	
	public DataQueue findById(Long id) {
		return (DataQueue) dqRepo.findById(id);
	}

	
	public List<DataQueue> findAll(Long functionId, Long calendarMonth, Long fiscalYear) {
		
		List<DataQueue> hList = new ArrayList<DataQueue>();
		OrgMap function = new OrgMap();
		
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		if (functionId != -1) {
			function = (OrgMap) orgRepo.findById(functionId);
			q.add(Restrictions.eq("function", function));
		}
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		
		
		for (CtrsEntity e : dqRepo.findAll(q)) {
			hList.add((DataQueue) e);
		}
				
		return hList;
	}
	
		
	public List<DataQueue> findAll(Long functionId, Long areaId, Long calendarMonth, Long fiscalYear) {
		
		List<DataQueue> hList = new ArrayList<DataQueue>();
		OrgMap function = new OrgMap();
		OrgMap area = null;
		
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		if (functionId != -1) {
			function = (OrgMap) orgRepo.findById(functionId);
			q.add(Restrictions.eq("function", function));
		}
		
		if (areaId != -1L) {
			area = (OrgMap) orgRepo.findById(areaId);
			q.add(Restrictions.eq("area", area));
		}
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		
		List<CtrsEntity> entList = dqRepo.findAll(q); 
		
		for (CtrsEntity e : entList) {
			hList.add((DataQueue) e);
		}
				
		return hList;
	}
	
	
	public DataQueue findOne(Long functionId, Long areaId, Long territoryId, 
			Long calendarMonth, Long fiscalYear) {
		
		OrgMap function = new OrgMap();
		OrgMap area = null;
		OrgMap territory = null;
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		
		if (functionId != -1) {
			function = (OrgMap) orgRepo.findById(functionId);
			q.add(Restrictions.eq("function", function));
		}
		
		if (areaId != -1L) {
			area = (OrgMap) orgRepo.findById(areaId);
			q.add(Restrictions.eq("area", area));
		}
		
		if (territoryId != -1L) {
			territory = (OrgMap) orgRepo.findById(territoryId);
			q.add(Restrictions.eq("territory", territory));
		}
		
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		
		
		return (DataQueue)dqRepo.find(q); 
	}

	
	public Role findRequiredRole(Long functionId, Long areaId, Long territoryId, 
			Long calendarMonth, Long fiscalYear) {
		
		
		DataQueue q = this.findOne(functionId, areaId, territoryId, calendarMonth, fiscalYear);
		
		return q.getRole();
	}
	
	
	public Long create(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long fiscalYear) {
		
		DataQueue dq = new DataQueue();
		
		OrgMap function = new OrgMap();
		function = (OrgMap) orgRepo.findById(functionId);
		
		OrgMap area = new OrgMap();
		area = (OrgMap) orgRepo.findById(areaId);
		
		OrgMap territory = new OrgMap();
		territory = (OrgMap) orgRepo.findById(territoryId);
		
		Role role = new Role();
		role.setRoleName("VTS");
		role = (Role) roleRepo.find(role);
		
		
		dq.setFunction(function);
		dq.setArea(area);
		dq.setTerritory(territory);
		dq.setRole(role);
		dq.setCalendarMonth(calendarMonth);
		dq.setFiscalYear(fiscalYear);
		
		
		if (dq.getFunction() == null || dq.getArea() == null || 
				dq.getTerritory() == null || dq.getRole() == null) {
			return -1L;
		}
		
		
		dqRepo.create(dq);
		
		return dq.getId() != null ? dq.getId() : -1L;
	}
	
	
	
	public void changeTerritoryStateToVTS(Long id) {
		DataQueue dq = new DataQueue();
		
		
		dq = this.findById(id);
		
		Role role = new Role();
		role.setRoleName("VTS");
		role = (Role) roleRepo.find(role);
		
		
		dq.setRole(role);
		dqRepo.update(dq);
		
	}
	
	
	public void changeTerritoryStateToWAS(Long id) {
		DataQueue dq = new DataQueue();
		
		
		dq = this.findById(id);
		
		Role role = new Role();
		role.setRoleName("WAS");
		role = (Role) roleRepo.find(role);
		
		
		//System.out.println("role: " + role);
		
		
		dq.setRole(role);
		dqRepo.update(dq);
		
	}
	
	
	public void changeAreaStateToWASMGR(Long functionId, Long areaId, Long calendarMonth, Long fiscalYear) {
		List<DataQueue> dqList = new ArrayList<DataQueue>();
		
		
		dqList = this.findAll(functionId, areaId, calendarMonth, fiscalYear);
		
		Role role = new Role();
		role.setRoleName("WAS_MGR");
		role = (Role) roleRepo.find(role);
		
		
		for (DataQueue q : dqList) {
			q.setRole(role);
			dqRepo.update(q);
		}
	}
	
	
	public void changeAreaStateToWAS(Long functionId, Long areaId, Long calendarMonth, Long fiscalYear) {
		List<DataQueue> dqList = new ArrayList<DataQueue>();
		
		
		dqList = this.findAll(functionId, areaId, calendarMonth, fiscalYear);
		
		Role role = new Role();
		role.setRoleName("WAS");
		role = (Role) roleRepo.find(role);
		
		
		for (DataQueue q : dqList) {
			q.setRole(role);
			dqRepo.update(q);
		}
	}
	
	
	public void changeAreaStateToSuper(Long functionId, Long areaId, Long calendarMonth, Long fiscalYear) {
		List<DataQueue> dqList = new ArrayList<DataQueue>();
		
		
		dqList = this.findAll(functionId, areaId, calendarMonth, fiscalYear);
		
		Role role = new Role();
		role.setRoleName("SUPER_CTRS_ANALYST");
		role = (Role) roleRepo.find(role);
		
		
		for (DataQueue q : dqList) {
			q.setRole(role);
			dqRepo.update(q);
		}
	}
	
	
	
	
	
	
	

}
