package org.westwood.ctrsWeb.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.HourAndInventory;
import org.westwood.ctrsWeb.model.HourAndInventoryMetadata;
import org.westwood.ctrsWeb.model.Role;

@Repository
public class HourAndInventoryMetadataRepository implements CtrsCrudRepository {

	@Autowired
    private SessionFactory sessionFactory;
	
		
	public CtrsEntity find(CtrsEntity ent) {
		//@SuppressWarnings("deprecation")
		//Criteria cr = session.createCriteria(User.class);
		
		//return (User)cr.uniqueResult();
		return null;
	}

	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(HourAndInventoryMetadata.class).add(Restrictions.eq("id", id));
		return (Role)cr.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll() {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(HourAndInventoryMetadata.class);
		
		return (List<CtrsEntity>)cr.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(HourAndInventoryMetadata.class);

		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		cr.addOrder(Order.asc("createdDate"));
		
		
		return (List<CtrsEntity>)cr.list();
	}
	
	public Long create(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	public void update(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	public void delete(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().delete(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	
	
}
