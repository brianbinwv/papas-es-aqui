package org.westwood.ctrsWeb.model;

public class QueueMissingRecordsTaskParameters {

	
	
	
}
