package org.westwood.ctrsWeb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.dao.TaskQueueRepository;
import org.westwood.ctrsWeb.dao.TaskQueueRepository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.TaskQueue;
import org.westwood.ctrsWeb.model.TaskStatus;

@Service
@Transactional
public class TaskQueueService implements CtrsBusinessService {

	@Autowired
	private TaskQueueRepository taskRepo;
	
	
	public TaskQueue findById(Long id) {
		//TaskQueue m = new TaskQueue();
		
		return (TaskQueue)taskRepo.findById(id);
	}
	
	public TaskQueue findById(String reportId) {
		//TaskQueue m = new TaskQueue();
		UUID reportUUID = UUID.fromString(reportId);
		
		return (TaskQueue)taskRepo.findByTaskId(reportUUID);
	}
	
	
	public List<TaskQueue> findAll() {
		
		List<TaskQueue> mList = new ArrayList<TaskQueue>();
		
		for (CtrsEntity e : taskRepo.findAll()) {
			mList.add((TaskQueue) e);
		}
				
		return mList;
	}


	public List<TaskQueue> findAll(String userId) {
		
		List<TaskQueue> mList = new ArrayList<TaskQueue>();
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("userId", userId));
		
		for (CtrsEntity e : taskRepo.findAll(q)) {
			mList.add((TaskQueue) e);
		}
				
		return mList;
	}
	
	public Long create(TaskQueue m) {
		taskRepo.create(m);
		
		return m.getId() != null ? m.getId() : -1L;
	}
	
	public void cancel(TaskQueue m) {
		m.setStatus(TaskStatus.CANCELED);
		taskRepo.update(m);
	}
	
	
	
//	public void update(Long id, Long clericalHours, Long mgmtHours, 
//			Long professionalHours, Long paraProfessionalHours, Long inventoryReceipts,
//			Long inventoryTransferIn, Long inventoryTransferOut, Long InventoryDisposals) {
//		
//		CtrsHourAndInventory h = (CtrsHourAndInventory) invRepo.findById(id);
//		
//		h.setClericalHours(clericalHours);
//		h.setManagementHours(mgmtHours);
//		h.setProfessionalHours(professionalHours);
//		h.setParaProfessionalHours(paraProfessionalHours);
//		h.setInventoryReceipts(inventoryReceipts);
//		h.setInventoryTransferIn(inventoryTransferIn);
//		h.setInventoryTransferOut(inventoryTransferOut);
//		h.setInventoryDisposals(InventoryDisposals);
//		
//		invRepo.update(h);
//	}
	
	
}
