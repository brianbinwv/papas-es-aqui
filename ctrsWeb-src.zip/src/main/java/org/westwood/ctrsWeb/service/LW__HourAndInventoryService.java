package org.westwood.ctrsWeb.service;

import java.util.ArrayList;
//import java.util.Date;
import java.util.List;

//import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.HourAndInventory;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.lightweight.LW__HourAndInventory;
import org.westwood.ctrsWeb.model.MissingHourAndInventoryRecord;
import org.westwood.ctrsWeb.dao.HourAndInventoryRepository;
import org.westwood.ctrsWeb.dao.OrgMapRepository;
import org.westwood.ctrsWeb.dao.LW__HourAndInventoryRepository;


//import org.westwood.ctrsWeb.repository.CtrsCrudRepository;
//import org.westwood.ctrsWeb.repository.CtrsRepositoryInjector;
//import org.westwood.ctrsWeb.repository.ReportViewRepository;
//import org.westwood.ctrsWeb.repository.RepositoryInjector;
//import org.westwood.ctrsWeb.repository.RepositoryType;

@Service
@Transactional
public class LW__HourAndInventoryService implements CtrsBusinessService {
	
	@Autowired
	private LW__HourAndInventoryRepository invRepo;
	
//	@Autowired
//	private OrgMapRepository orgRepo;
	
	
	public LW__HourAndInventory find(Long id) {
		return (LW__HourAndInventory)invRepo.findById(id);
	}
	
	public List<LW__HourAndInventory> find(Long functionId, Long areaId, Long territoryId,
			Long groupId, Long calendarMonth, Long fiscalYear) {
		
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		q.add(Restrictions.eq("areaId", areaId));
		q.add(Restrictions.eq("territoryId", territoryId));
		q.add(Restrictions.eq("groupId", groupId));
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
				
		
		for (CtrsEntity e : invRepo.find(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}
	
	public List<LW__HourAndInventory> findHours(Long functionId, Long areaId, Long territoryId,
			Long groupId, Long calendarMonth, Long fiscalYear) {
		
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		
		if (areaId != -1L)
			q.add(Restrictions.eq("areaId", areaId));
		
		if (territoryId != -1L)
			q.add(Restrictions.eq("territoryId", territoryId));
		
		if (groupId != -1L)
			q.add(Restrictions.eq("groupId", groupId));
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		q.add(Restrictions.eq("hours", 1L));
						
		
		for (CtrsEntity e : invRepo.find(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<LW__HourAndInventory> findHours__Summary(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long fiscalYear) {
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		
				
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		q.add(Restrictions.eq("areaId", areaId));
		
		if (territoryId != -1L) {
			q.add(Restrictions.eq("territoryId", territoryId));
		}
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		q.add(Restrictions.eq("hours", 1L));
				
		
		for (CtrsEntity e : ((LW__HourAndInventoryRepository)invRepo).find__Summary(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<LW__HourAndInventory> findInventory(Long functionId, Long areaId, Long territoryId,
			Long groupId, Long calendarMonth, Long fiscalYear) {
		
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		
		if (areaId != -1L)
			q.add(Restrictions.eq("areaId", areaId));
		
		if (territoryId != -1L)
			q.add(Restrictions.eq("territoryId", territoryId));
		
		if (groupId != -1L)
			q.add(Restrictions.eq("groupId", groupId));
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		q.add(Restrictions.eq("inventory", 1L));
						
		
		for (CtrsEntity e : invRepo.find(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<LW__HourAndInventory> findInventory__Summary(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long fiscalYear) {
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		
				
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		q.add(Restrictions.eq("areaId", areaId));
		
		if (territoryId != -1L) {
			q.add(Restrictions.eq("territoryId", territoryId));
		}
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		q.add(Restrictions.eq("inventory", 1L));
				
		
		for (CtrsEntity e : ((LW__HourAndInventoryRepository)invRepo).find__Summary(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<LW__HourAndInventory> findROCounts(Long functionId, Long areaId, Long territoryId,
			Long groupId, Long calendarMonth, Long fiscalYear) {
		
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		
		if (areaId != -1L)
			q.add(Restrictions.eq("areaId", areaId));
		
		if (territoryId != -1L)
			q.add(Restrictions.eq("territoryId", territoryId));
		
		if (groupId != -1L)
			q.add(Restrictions.eq("groupId", groupId));
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));

		q.add(Restrictions.like("timeCode", "099%"));
						
		
		for (CtrsEntity e : invRepo.find(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<LW__HourAndInventory> findROCounts__Summary(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long fiscalYear) {
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		
				
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		q.add(Restrictions.eq("areaId", areaId));
		
		if (territoryId != -1L) {
			q.add(Restrictions.eq("territoryId", territoryId));
		}
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
				
		q.add(Restrictions.like("timeCode", "099%"));
		
		
		for (CtrsEntity e : ((LW__HourAndInventoryRepository)invRepo).find__Summary(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<LW__HourAndInventory> findOtherActions(Long functionId, Long areaId, Long territoryId,
			Long groupId, Long calendarMonth, Long fiscalYear) {
		
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		
		if (areaId != -1L)
			q.add(Restrictions.eq("areaId", areaId));
		
		if (territoryId != -1L)
			q.add(Restrictions.eq("territoryId", territoryId));
		
		if (groupId != -1L)
			q.add(Restrictions.eq("groupId", groupId));
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));

		q.add(Restrictions.like("timeCode", "90%"));
						
		
		for (CtrsEntity e : invRepo.find(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<LW__HourAndInventory> findOtherActions__Summary(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long fiscalYear) {
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		
				
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		q.add(Restrictions.eq("areaId", areaId));
		
		if (territoryId != -1L) {
			q.add(Restrictions.eq("territoryId", territoryId));
		}
		
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
				
		q.add(Restrictions.like("timeCode", "90%"));
		
		
		for (CtrsEntity e : ((LW__HourAndInventoryRepository)invRepo).find__Summary(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<LW__HourAndInventory> findAllGroupByFunction_Area_Territory(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long fiscalYear, boolean bHours, boolean bInventory) {
		List<LW__HourAndInventory> hList = new ArrayList<LW__HourAndInventory>();
		
		
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("functionId", functionId));
		q.add(Restrictions.eq("areaId", areaId));
		//q.add(Restrictions.eq("territoryId", territoryId));
		q.add(Restrictions.eq("calendarMonth", calendarMonth));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		
		if (bHours) {
			q.add(Restrictions.eq("hours", 1L));
		}
		
		if (bInventory) {
			q.add(Restrictions.eq("inventory", 1L));
		}
		
		
		for (CtrsEntity e : ((LW__HourAndInventoryRepository)invRepo).findAllGroupByFunction_Area_Territory(q)) {
			hList.add((LW__HourAndInventory) e);
		}
				
		return hList;
	}

	
//	public List<MissingHourAndInventoryRecord> findMissingRecords(Long functionId, Long areaId, Long fiscalYear, Long calendarMonth) {
//		
//		return invRepo.findMissingRecords(functionId, areaId, fiscalYear, calendarMonth);
//	}
	
	public List<MissingHourAndInventoryRecord> findMissingRecords_2(Long functionId, Long areaId, Long fiscalYear, Long calendarMonth) {
		
		return invRepo.findMissingRecords_2(functionId, areaId, fiscalYear, calendarMonth);
	}

}

