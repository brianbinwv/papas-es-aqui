package org.westwood.ctrsWeb.model;

import java.util.UUID;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

//import org.hibernate.annotations.GenericGenerator;

@Entity(name = "ReportContent")
@Table(name = "report_content")
public class ReportContent implements CtrsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID", nullable=false)
	private Long id;
	
	
	@Column(name = "REPORT_ID", length = 36, updatable = false, nullable = false)
	@Type(type="uuid-char")
	private UUID reportId;
	
	@Lob
	@Column(name = "content", columnDefinition="BLOB")
	private byte[] reportContent;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public UUID getReportId() {
		return reportId;
	}

	public void setReportId(UUID reportId) {
		this.reportId = reportId;
	}

	public byte[] getReportContent() {
		return reportContent;
	}


	public void setReportContent(byte[] reportContent) {
		this.reportContent = reportContent;
	}
	
	
//	InputStream inputStream = this.getClass()
//			  .getClassLoader()
//			  .getResourceAsStream("profile.png");
//
//			if(inputStream == null) {
//			    fail("Unable to get resources");
//			}
//			
//			user.setPhoto(IOUtils.toByteArray(inputStream));
	
	
}
