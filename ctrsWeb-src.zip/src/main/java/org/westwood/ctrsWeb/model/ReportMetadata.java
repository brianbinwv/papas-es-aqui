package org.westwood.ctrsWeb.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity(name = "ReportMetadata")
@Table(name = "report_metadata")
public class ReportMetadata implements CtrsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID", nullable=false)
	Long id;
		
	@Column(name = "USER_ID", nullable = false)
	String userId;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(name = "CREATED_DT")
	private Date createdDate;
	
	@Column(name = "REPORT_ID", length = 36, updatable = false, nullable = false)
	@Type(type="uuid-char")
	private UUID reportId;
    
	@Column(name = "FILENAME", nullable = false)
	private String fileName;
	
	@Column(name = "NAME", nullable = false)
	private String reportName;
	
	@Column(name = "STATUS")
	@Convert(converter = TaskStatusAttributeConverter.class)
	private TaskStatus status;
	
	@Column(name = "CLEANUP_FLAG")
	private Boolean cleanup;
	
	@Column(name = "PARAMETERS", nullable = false)
	private String parameters;
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public UUID getReportId() {
		return reportId;
	}

	public void setReportId(UUID reportId) {
		this.reportId = reportId;
	}

	
	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	public TaskStatus getStatus() {
		return status;
	}

	public void setStatus(TaskStatus status) {
		this.status = status;
	}

	public Boolean getCleanup() {
		return cleanup;
	}

	public void setCleanup(Boolean cleanup) {
		this.cleanup = cleanup;
	}

	@Override
	public String toString() {
		return "ReportMetadata [id=" + id + ", userId=" + userId + ", createdDate=" + createdDate + ", reportId="
				+ reportId + ", fileName=" + fileName + ", reportName=" + reportName + ", status=" + status + ", cleanup="
				+ cleanup + ", parameters=" + parameters + "]";
	}

	
	
}


