package org.westwood.ctrsWeb.model;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class TaskStatusAttributeConverter implements AttributeConverter<TaskStatus, Integer> {
 
    @Override
    public Integer convertToDatabaseColumn(TaskStatus attribute) {
        if (attribute == null)
            return null;
 
        switch (attribute) {
        case QUEUED:
            return 0;
 
        case PROCESSING:
            return 1;
 
        case COMPLETE:
            return 2;
 
        case ERROR:
            return 3;
 
        case CANCELED:
            return 4;
 
        default:
            throw new IllegalArgumentException(attribute + " not supported.");
        }
    }
 
    @Override
    public TaskStatus convertToEntityAttribute(Integer dbData) {
        if (dbData == null)
            return null;
 
        switch (dbData) {
        case 0:
            return TaskStatus.QUEUED;
 
        case 1:
            return TaskStatus.PROCESSING;
 
        case 2:
            return TaskStatus.COMPLETE;
 
        case 3:
            return TaskStatus.ERROR;
 
        case 4:
            return TaskStatus.CANCELED;
 
        default:
            throw new IllegalArgumentException(dbData + " not supported.");
        }
    }
 
}