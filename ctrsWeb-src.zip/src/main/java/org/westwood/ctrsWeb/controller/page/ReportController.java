package org.westwood.ctrsWeb.controller.page;


import org.springframework.security.core.Authentication;


//import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.westwood.ctrsWeb.security.model.CtrsUserDetails;


@Controller
@RequestMapping("/reports")
public class ReportController {

		
	@RequestMapping("")
	public ModelAndView getReportsView(Authentication authentication) {
		ModelAndView theModel = new ModelAndView("reports", "reports", "");
		CtrsUserDetails u = (CtrsUserDetails) authentication.getDetails();
		
		if (u.isAdmin()) {
			theModel.addObject("isAdmin", true);
		}
		
		
		return theModel;
	}
	
	
	
	
}
