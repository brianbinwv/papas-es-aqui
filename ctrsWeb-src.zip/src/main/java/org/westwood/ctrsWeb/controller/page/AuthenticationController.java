package org.westwood.ctrsWeb.controller.page;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.westwood.ctrsWeb.model.User;
import org.westwood.ctrsWeb.service.UserService;

@Controller
@RequestMapping("/auth")
public class AuthenticationController {

//	@Autowired
//	private UserService userService;
	
//	@RequestMapping("/login")
//	public String login(HttpSession session) {
//		String s = "";
//		
//		User u = userService.findById(1L);
//		
//		System.out.println(u.toString());
//		s = u.getEmail(); // + "<br>" + u.getRoles().toString() + "<br>" + u.getPermittedOrgMap().toString() + "<br>";
//			
//			
//		return s;
//		
//	}
}
