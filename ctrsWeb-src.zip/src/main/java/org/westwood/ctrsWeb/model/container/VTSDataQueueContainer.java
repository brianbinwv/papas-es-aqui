package org.westwood.ctrsWeb.model.container;



public class VTSDataQueueContainer extends DataQueueContainer {

	
	
}
