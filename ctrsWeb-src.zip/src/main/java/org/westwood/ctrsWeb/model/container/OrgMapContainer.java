package org.westwood.ctrsWeb.model.container;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.westwood.ctrsWeb.model.OrgMap;

public class OrgMapContainer {

//	// "id":2,"parentId":1,"orgCode":1,"fiscalYear":2020,"orgName":"NORTH ATLANTIC","status":1
	//private String[] headers = {"Org Code", "Org Name", "Fiscal Year", "Status" };
	private List<OrgMap> data = new ArrayList<OrgMap>();
//	//private String[] orgMap = {"2","1","1","2020","NORTH ATLANTIC","1"};
//	
//	private String[][] orgMap = new String[1][1];
//	
//	@SuppressWarnings("unused")
//	private Date lastUpdated = new Date();
////    
////		
//	public String[] getHeaders() {
//		return this.headers;
//	}
//	
//	public String[][] getOrgMap() {
//		return this.orgMap;
//	}
//	
//	public void setOrgMap(CtrsOrgMap c) {
//		String[] data = {c.getId().toString(), c.getParentId().toString(), c.getOrgCode().toString(),
//				c.getFiscalYear().toString(), c.getOrgName(), c.getStatus().toString()};
//		
//		this.orgMap[0] = data;
//	}

	public List<OrgMap> getData() {
		return data;
	}

	public void setData(List<OrgMap> data) {
		this.data = data;
	}
	

	
	
}
