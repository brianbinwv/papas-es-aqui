package org.westwood.ctrsWeb.controller.page;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.service.UserService;


@Controller
@RequestMapping("/data-queue")
public class DataQueueController {

	@Autowired
	private UserService userService;
	
	
	@RequestMapping("")
	public ModelAndView dataQueue(Authentication authentication) {
		ModelAndView theModel = new ModelAndView("data-queue", "data-queue", "");
		
		
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
				
		System.out.println("roles " + container.getFormattedRoleString());
		theModel.addObject("roles", container.getFormattedRoleString());
		
		//String roles = "VTS:WAS:WAS_MGR:SUPER_CTRS_ANALYST";
		
		//theModel.addObject("roles", roles);
		

		return theModel;
	}
}
