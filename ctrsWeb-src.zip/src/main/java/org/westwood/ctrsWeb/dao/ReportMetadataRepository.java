package org.westwood.ctrsWeb.dao;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
//import org.westwood.ctrsWeb.model.HourAndInventoryReportView;
import org.westwood.ctrsWeb.model.HourAndInventoryMetadata;
import org.westwood.ctrsWeb.model.ReportContent;
import org.westwood.ctrsWeb.model.ReportMetadata;
import org.westwood.ctrsWeb.model.Role;
 
@Repository
public class ReportMetadataRepository implements CtrsCrudRepository {

	@Autowired
    private SessionFactory sessionFactory;
	
	
	public CtrsEntity find(CtrsEntity ent) {
		return null;
	}
	
	@Override
	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(ReportMetadata.class).add(Restrictions.eq("id", id));
				
		return (ReportMetadata)cr.uniqueResult();
	}
	
	public CtrsEntity findById(UUID id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(ReportMetadata.class).add(Restrictions.eq("reportId", id));
				
		return (ReportMetadata)cr.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findByUserId(String userId) {
		
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(ReportMetadata.class).add(Restrictions.eq("userId", userId));
				
		return (List<CtrsEntity>)cr.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll() {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(ReportMetadata.class);
		
		return (List<CtrsEntity>)cr.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(ReportMetadata.class);

		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		cr.addOrder(Order.asc("createdDate"));
		
		
		return (List<CtrsEntity>)cr.list();
	}
	
	public Long create(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	public void update(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().update(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	public void delete(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().delete(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	
	
	
}
