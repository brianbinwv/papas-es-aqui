package org.westwood.ctrsWeb.service;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.dao.ReportContentRepository;

import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.ReportContent;


@Service
@Transactional
public class ReportContentService implements CtrsBusinessService {

	@Autowired
	private ReportContentRepository contentRepo;
	
	
	public ReportContent findById(String reportId) {
		ReportContent r = new ReportContent();
		UUID reportUUID = UUID.fromString(reportId);
		
		return (ReportContent) contentRepo.findById(reportUUID);
	}
	
	
//	public ReportContent find(String reportId) {
//		ReportContent m = new ReportContent();
//		
//		
//		UUID reportUUID = UUID.fromString(reportId);
//		
//		m.setReportId(reportUUID);
//		
//		return (ReportContent)contentRepo.find(m);
//	}
		
	
	public List<ReportContent> findAll() {
		
		List<ReportContent> mList = new ArrayList<ReportContent>();
		
		
		for (CtrsEntity e : contentRepo.findAll()) {
			mList.add((ReportContent) e);
		}
				
		return mList;
	}
	
	
	
	
//	public Long create(Long functionId, Long areaId, Long territoryId,
//			Long groupId, String timeCode, Long calendarMonth, Long calendarYear, Long fiscalYear, Long local) {
//		
//		CtrsHourAndInventory inv = new CtrsHourAndInventory();
//		
//		CtrsOrgMap function = new CtrsOrgMap();
//		function = (CtrsOrgMap) orgRepo.findById(functionId);
//		
//		CtrsOrgMap area = new CtrsOrgMap();
//		area = (CtrsOrgMap) orgRepo.findById(areaId);
//		
//		CtrsOrgMap territory = new CtrsOrgMap();
//		territory = (CtrsOrgMap) orgRepo.findById(territoryId);
//		
//		
//		CtrsOrgMap group = new CtrsOrgMap();
//		group = (CtrsOrgMap) orgRepo.findById(groupId);
//		
//		System.out.println("searching for data queue record");
//		
//		DataQueue dq = new DataQueue();
//		dq.setFunction(function);
//		dq.setArea(area);
//		dq.setTerritory(territory);
//		dq.setCalendarMonth(calendarMonth);
//		dq.setCalendarYear(calendarYear);
//		dq = (DataQueue) dqRepo.find(dq);
//				
//		inv.setDataQueue(dq);
//		
//		
//		inv.setFunction(function);
//		inv.setArea(area);
//		inv.setTerritory(territory);
//		inv.setGroup(group);
//		
//		CtrsTimeCode tc = new CtrsTimeCode();
//		tc.setFunction(function);
//		
//		if (local == 0L) {
//			tc.setArea(function);
//			tc.setTerritory(function);
//			tc.setTimeCode(timeCode);
//			tc.setFiscalYear(fiscalYear);
//			tc = (CtrsTimeCode)timeCodeRepo.find(tc);
//		}
//		else {
//			// local time code
//			tc.setArea(area);
//			tc.setTerritory(territory);
//			tc.setTimeCode(timeCode);
//			tc.setFiscalYear(fiscalYear);
//			tc = (CtrsTimeCode)timeCodeRepo.find(tc);
//		}
//		
//		
//		inv.setTimeCode(tc);
//		
//		inv.setClericalHours(0L);
//		inv.setManagementHours(0L);
//		inv.setParaProfessionalHours(0L);
//		inv.setProfessionalHours(0L);
//		inv.setOpeningInventory(0L);
//		inv.setInventoryReceipts(0L);
//		inv.setInventoryTransferIn(0L);
//		inv.setInventoryTransferOut(0L);
//		inv.setInventoryDisposals(0L);
//		
//		
//		
//		
//		try {
//			inv.setYearAndMonth(
//					new SimpleDateFormat("yyyy-MM-dd").parse(calendarYear.toString() + 
//							"-" + calendarMonth.toString() + "-01")
//			);
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		//inv.setMonth(calendarMonth);
//		//inv.setYear(calendarYear);
//		inv.setFiscalYear(fiscalYear);
//		
//		
//		if (inv.getFunction() == null || inv.getArea() == null || 
//				inv.getTerritory() == null || inv.getGroup() == null || 
//				inv.getTimeCode() == null) {
//			return -1L;
//		}
//		
//		
//		invRepo.create(inv);
//		
//		return inv.getId() != null ? inv.getId() : -1L;
//	}
	
	
	
//	public void update(Long id, Long clericalHours, Long mgmtHours, 
//			Long professionalHours, Long paraProfessionalHours, Long inventoryReceipts,
//			Long inventoryTransferIn, Long inventoryTransferOut, Long InventoryDisposals) {
//		
//		CtrsHourAndInventory h = (CtrsHourAndInventory) invRepo.findById(id);
//		
//		h.setClericalHours(clericalHours);
//		h.setManagementHours(mgmtHours);
//		h.setProfessionalHours(professionalHours);
//		h.setParaProfessionalHours(paraProfessionalHours);
//		h.setInventoryReceipts(inventoryReceipts);
//		h.setInventoryTransferIn(inventoryTransferIn);
//		h.setInventoryTransferOut(inventoryTransferOut);
//		h.setInventoryDisposals(InventoryDisposals);
//		
//		invRepo.update(h);
//	}
	
	
	
}

