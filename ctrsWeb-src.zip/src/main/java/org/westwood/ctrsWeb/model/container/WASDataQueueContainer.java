package org.westwood.ctrsWeb.model.container;

import java.util.List;

import org.westwood.ctrsWeb.model.json.DataQueueJson;

public class WASDataQueueContainer extends DataQueueContainer {

	private Boolean canSendAreaToWASMGR = true;
	
	
	public Boolean getCanSendAreaToWASMGR() {
		return canSendAreaToWASMGR;
	}


	@Override
	public void setData(List<DataQueueJson> data) {

		super.setData(data);
		
		for (DataQueueJson d : data) {
			if (!d.getRoleName().equals("WAS")) {
				System.out.println("WASDataQueueContainer: role " + d.getRoleName());
				canSendAreaToWASMGR = false;
			}
		}
	}
}
