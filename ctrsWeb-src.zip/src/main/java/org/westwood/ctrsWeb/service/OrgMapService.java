package org.westwood.ctrsWeb.service;

import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.HashSet;
import java.util.List;
//import java.util.Map;
//import java.util.Set;
//import java.util.TreeMap;

//import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
//import org.westwood.ctrsWeb.dao.CtrsHourAndInventoryRepository;
import org.westwood.ctrsWeb.dao.OrgMapRepository;
//import org.westwood.ctrsWeb.dao.CtrsTimeCodeRepository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.OrgMap;
//import org.westwood.ctrsWeb.model.TerritoryAndGroupMap;
//import org.westwood.ctrsWeb.dao.CtrsCrudRepository;


@Service
@Transactional
public class OrgMapService implements CtrsBusinessService {

	@Autowired
	private OrgMapRepository repo;
	
		
//	public OrgMapService(Session session) {
//		injector = new CtrsRepositoryInjector();
//		this.session = session;
//		repo = injector.getRepository(RepositoryType.ORG_MAP, session);
//	}
	
	public List<Long> findAllFiscalYears() {
		return repo.findAllFiscalYears();
	}
	
	public OrgMap find(OrgMap c) {
		return (OrgMap) repo.find(c);
	}
	
	
	public OrgMap findById(Long id) {
		return (OrgMap) repo.findById(id);
	}
	
	
	public Long create(Long orgCode, String orgName, Long fiscalYear) {
		return this.create(0L, orgCode, orgName, fiscalYear);
	}

	
	public List<OrgMap> findAllByParent(Long parentId) {
		List<OrgMap> nodes = new ArrayList<OrgMap>();
		List<Criterion> q = new ArrayList<Criterion>();
		OrgMap parent = new OrgMap();
		
		//parent = (OrgMap)repo.findById(parentId);
		
		parent = this.findById(parentId);
		
		q.add(Restrictions.eq("parentId", parent.getId()));
		
		for (CtrsEntity e : repo.findAll(q)) {
			nodes.add((OrgMap) e);
		}
		
		return nodes;
	}

	
	public List<OrgMap> findFirstLevelOrgsByFY(Long fiscalYear) {
		List<OrgMap> firstLevelOrgs = new ArrayList<OrgMap>();
		
		for (CtrsEntity e : repo.findFirstLevelOrgsByFY(fiscalYear)) {
			firstLevelOrgs.add((OrgMap) e);
		}
		
		return firstLevelOrgs;
	}
	
	
//	public TreeMap<Long, Map<OrgMap, List<OrgMap>>> getSibling__And__Child__Orgs(Long parentId) {
//		TreeMap<Long, Map<OrgMap, List<OrgMap>>> orgMap = new TreeMap<Long, Map<OrgMap, List<OrgMap>>>();
//				
//		// get territory codes
//		
//		List<OrgMap> siblingList = this.findAllByParent(parentId); 
//		
//		// loop over territories
//		for (OrgMap s : siblingList) {
//			Map<OrgMap, List<OrgMap>> sibMap = new HashMap<OrgMap, List<OrgMap>>();
//			
//			// get groups
//			List<OrgMap> childList = this.findAllByParent(s.getId());
//			// declare list to hold groups
//			List<OrgMap> children = new ArrayList<OrgMap>();
//			
//			children.addAll(childList);
//			
//			
//			// put territory object and list of groups in the map
//			sibMap.put(s, children);
//			// put the territory code and territory / group map into orgMap
//			orgMap.put(s.getOrgCode(), sibMap);
//		}
//		
//		
//		return orgMap;
//		
//	}
	
	
//	public TreeMap<Long, TerritoryAndGroupMap> findTerritories__And__Groups(Long parentId) {
//		TreeMap<Long, TerritoryAndGroupMap> orgMap = new TreeMap<Long, TerritoryAndGroupMap>();
//		
//		List<OrgMap> territories = this.findAllByParent(parentId);
//		
//		for (OrgMap t : territories) {
//			// get groups
//			List<OrgMap> groups = this.findAllByParent(t.getId());
//			TerritoryAndGroupMap tgMap = new TerritoryAndGroupMap(t, groups);
//			orgMap.put(t.getOrgCode(), tgMap);
//		}
//		
//		return orgMap;
//	}
	
	
	
	public Long create(Long parentId, Long orgCode, String orgName, Long fiscalYear) {
		OrgMap org = new OrgMap();
		
		org.setParentId(parentId);
		org.setOrgCode(orgCode);
		org.setFiscalYear(fiscalYear);
		org.setOrgName(orgName);
		org.setStatus(1L);
		repo.create(org);
		
		return org.getId() != null ? org.getId() : -1L;
	}
	
	
	public void update(Long id, String newOrgName) {
		OrgMap org = this.findById(id);
		org.setOrgName(newOrgName);
		repo.update(org);
	}

	
	public void delete(Long id) {
		OrgMap org = this.findById(id);
		repo.delete(org);
	}
	
}
