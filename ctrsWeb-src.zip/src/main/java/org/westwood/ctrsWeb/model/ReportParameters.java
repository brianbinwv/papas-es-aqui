package org.westwood.ctrsWeb.model;

public class ReportParameters {
	private Long function = 0L;
	
	private Long area = 0L;
	
	private Long territory = 0L;
	
	private Long group = 0L;
	
	private Long fiscalYear = 0L;
	
	private Long beginMonth = 0L;
	
	private Long endMonth = 0L;
	
	private String reportName = "";

	
	public Long getFunction() {
		return function;
	}

	public void setFunction(Long function) {
		this.function = function;
	}

	public Long getArea() {
		return area;
	}

	public void setArea(Long area) {
		this.area = area;
	}

	public Long getTerritory() {
		return territory;
	}

	public void setTerritory(Long territory) {
		this.territory = territory;
	}

	public Long getGroup() {
		return group;
	}

	public void setGroup(Long group) {
		this.group = group;
	}

	public Long getFiscalYear() {
		return fiscalYear;
	}

	public void setFiscalYear(Long fiscalYear) {
		this.fiscalYear = fiscalYear;
	}

	public Long getBeginMonth() {
		return beginMonth;
	}

	public void setBeginMonth(Long beginMonth) {
		this.beginMonth = beginMonth;
	}

	public Long getEndMonth() {
		return endMonth;
	}

	public void setEndMonth(Long endMonth) {
		this.endMonth = endMonth;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	
	
	
	
}
