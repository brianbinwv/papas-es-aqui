package org.westwood.ctrsWeb.model.json;


public class HoursJson {

	private long id;
	private long clericalHours;
	private long professionalHours;
	private long managementHours;
	private long paraProfessionalHours;
	private String comments;
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getClericalHours() {
		return clericalHours;
	}
	public void setClericalHours(long clericalHours) {
		this.clericalHours = clericalHours;
	}
	public long getProfessionalHours() {
		return professionalHours;
	}
	public void setProfessionalHours(long professionalHours) {
		this.professionalHours = professionalHours;
	}
	public long getManagementHours() {
		return managementHours;
	}
	public void setManagementHours(long managementHours) {
		this.managementHours = managementHours;
	}
	public long getParaProfessionalHours() {
		return paraProfessionalHours;
	}
	public void setParaProfessionalHours(long paraProfessionalHours) {
		this.paraProfessionalHours = paraProfessionalHours;
	}
	
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public Boolean isValid() {
		
		System.out.println("comments length: " + comments.length());
		
		if (comments.length() == 0)
			return false;
		
		return true;
	}
	@Override
	public String toString() {
		return "Hours__JsonHelper [id=" + id + ", clericalHours=" + clericalHours + ", professionalHours="
				+ professionalHours + ", managementHours=" + managementHours + ", paraProfessionalHours="
				+ paraProfessionalHours + ", comments=" + comments + "]";
	}
	
	
}
