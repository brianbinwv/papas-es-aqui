package org.westwood.ctrsWeb.model.lightweight;


import java.util.Date;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;
//import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Subselect;
import org.westwood.ctrsWeb.model.CtrsEntity;

@Entity(name = "HourAndInventory_View")
@Immutable
@Subselect("select * from hourandinventory_view")
public class LW__HourAndInventory implements CtrsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID", updatable = false, nullable = false)
	private Long id = 0L;
	
	@Column(name = "FUNCTION_ID")
	private Long functionId = 0L;
	
	@Column(name = "FUNCTION_CODE")
	private Long functionCode = 0L;
	
	@Column(name = "FUNCTION_NAME")
	private String functionName;
	
	@Column(name = "AREA_ID")
	private Long areaId = 0L;
	
	@Column(name = "AREA_CODE")
	private Long areaCode = 0L;
	
	@Column(name = "AREA_NAME")
	private String areaName;
	
	@Column(name = "TERRITORY_ID")
	private Long territoryId = 0L;
	
	@Column(name = "TERRITORY_CODE")
	private Long territoryCode = 0L;
	
	@Column(name = "TERRITORY_NAME")
	private String territoryName;
	
	@Column(name = "GROUP_ID")
	private Long groupId = 0L;
	
	@Column(name = "GROUP_CODE")
	private Long groupCode = 0L;
	
	@Column(name = "GROUP_NAME")
	private String groupName;
	
	@Column(name = "TIME_CODE")
	private String timeCode;
	
	@Column(name = "TIMECODE_DESCRIPTION")
	private String timeCodeDescription;
	
	@Column(name = "LOCAL_CODE")
	private Long local = 0L;
	
	@Column(name = "ROLLUP_CODE")
	private Long rollup = 0L;
	
	@Column(name = "HAS_HOURS")
	private Long hours = 0L;
	
	@Column(name = "HAS_INVENTORY")
	private Long inventory = 0L;
	
	@Column(name = "CLERICAL_HOURS")
	private Long clericalHours = 0L;
		
	@Column(name = "MANAGEMENT_HOURS")
	private Long managementHours = 0L;
	
	@Column(name = "PROFESSIONAL_HOURS")
	private Long professionalHours = 0L;
	
	@Column(name = "PARA_PROFESSIONAL_HOURS")
	private Long paraProfessionalHours = 0L;
	
	@Column(name = "OPENING_INVENTORY")
	private Long openingInventory = 0L;
	
	@Column(name = "INVENTORY_RECEIPTS")
	private Long inventoryReceipts = 0L;
	
	@Column(name = "INVENTORY_TRANSFER_IN")
	private Long inventoryTransferIn = 0L;
	
	@Column(name = "INVENTORY_TRANSFER_OUT")
	private Long inventoryTransferOut = 0L;
	
	@Column(name = "INVENTORY_DISPOSALS")
	private Long inventoryDisposals = 0L;
	
	@Column(name = "YEAR_AND_MONTH")
	private Date yearAndMonth;
	
	@Column(name = "CALENDAR_MONTH")
	private Long calendarMonth = 0L;
	
	@Column(name = "CALENDAR_YEAR")
	private Long calendarYear = 0L;
	
	@Column(name = "FISCAL_YEAR")
	private Long fiscalYear = 0L;

	@Column(name = "REQUIRED_ROLE")
	private String requiredRole;
	
	public Long getId() {
		return id;
	}

	public Long getFunctionCode() {
		return functionCode;
	}

	public void setFunctionCode(Long functionCode) {
		this.functionCode = functionCode;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public Long getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(Long areaCode) {
		this.areaCode = areaCode;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public Long getTerritoryCode() {
		return territoryCode;
	}

	public void setTerritoryCode(Long territoryCode) {
		this.territoryCode = territoryCode;
	}

	public String getTerritoryName() {
		return territoryName;
	}

	public void setTerritoryName(String territoryName) {
		this.territoryName = territoryName;
	}

	public Long getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(Long groupCode) {
		this.groupCode = groupCode;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getTimeCode() {
		return timeCode;
	}

	public void setTimeCode(String timeCode) {
		this.timeCode = timeCode;
	}

	public String getTimeCodeDescription() {
		return timeCodeDescription;
	}

	public void setTimeCodeDescription(String timeCodeDescription) {
		this.timeCodeDescription = timeCodeDescription;
	}

	public Long getLocal() {
		return local;
	}

	public void setLocal(Long local) {
		this.local = local;
	}

	public Long getRollup() {
		return rollup;
	}

	public void setRollup(Long rollup) {
		this.rollup = rollup;
	}
	
	public Long getHours() {
		return hours;
	}

	public void setHours(Long hours) {
		this.hours = hours;
	}

	public Long getInventory() {
		return inventory;
	}

	public void setInventory(Long inventory) {
		this.inventory = inventory;
	}

	public Boolean hasHours() {
		return hours == 1L ? true : false;
	}
	
	public Boolean hasInventory() {
		return inventory == 1L ? true : false;
	}
		
	public Long getClericalHours() {
		return clericalHours;
	}

	public void setClericalHours(Long clericalHours) {
		this.clericalHours = clericalHours;
	}

	public Long getManagementHours() {
		return managementHours;
	}

	public void setManagementHours(Long managementHours) {
		this.managementHours = managementHours;
	}

	public Long getProfessionalHours() {
		return professionalHours;
	}

	public void setProfessionalHours(Long professionalHours) {
		this.professionalHours = professionalHours;
	}

	public Long getParaProfessionalHours() {
		return paraProfessionalHours;
	}

	public void setParaProfessionalHours(Long paraProfessionalHours) {
		this.paraProfessionalHours = paraProfessionalHours;
	}

	public Long getOpeningInventory() {
		return openingInventory;
	}

	public void setOpeningInventory(Long openingInventory) {
		this.openingInventory = openingInventory;
	}

	public Long getInventoryReceipts() {
		return inventoryReceipts;
	}

	public void setInventoryReceipts(Long inventoryReceipts) {
		this.inventoryReceipts = inventoryReceipts;
	}

	public Long getInventoryTransferIn() {
		return inventoryTransferIn;
	}

	public void setInventoryTransferIn(Long inventoryTransferIn) {
		this.inventoryTransferIn = inventoryTransferIn;
	}

	public Long getInventoryTransferOut() {
		return inventoryTransferOut;
	}

	public void setInventoryTransferOut(Long inventoryTransferOut) {
		this.inventoryTransferOut = inventoryTransferOut;
	}

	public Long getInventoryDisposals() {
		return inventoryDisposals;
	}

	public void setInventoryDisposals(Long inventoryDisposals) {
		this.inventoryDisposals = inventoryDisposals;
	}

	public Date getYearAndMonth() {
		return yearAndMonth;
	}

	public void setYearAndMonth(Date yearAndMonth) {
		this.yearAndMonth = yearAndMonth;
	}

	public Long getCalendarMonth() {
		return calendarMonth;
	}

	public void setCalendarMonth(Long calendarMonth) {
		this.calendarMonth = calendarMonth;
	}

	public Long getCalendarYear() {
		return calendarYear;
	}

	public void setCalendarYear(Long calendarYear) {
		this.calendarYear = calendarYear;
	}

	public Long getFiscalYear() {
		return fiscalYear;
	}

	public void setFiscalYear(Long fiscalYear) {
		this.fiscalYear = fiscalYear;
	}
	
	public Long getTotalProfessionalHours() {
		return this.managementHours + this.professionalHours;
	}
	
	public Long getTotalNonProfessionalHours() {
		return this.getClericalHours() + this.getParaProfessionalHours();
	}

	
	public Long getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}

	public Long getAreaId() {
		return areaId;
	}

	public void setAreaId(Long areaId) {
		this.areaId = areaId;
	}

	public Long getTerritoryId() {
		return territoryId;
	}

	public void setTerritoryId(Long territoryId) {
		this.territoryId = territoryId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getRequiredRole() {
		return requiredRole;
	}

	public void setRequiredRole(String requiredRole) {
		this.requiredRole = requiredRole;
	}

	public Boolean hasRequiredRole(String role) {
		
		if (this.requiredRole.equals(role)) 
			return true;
		
		return false;
		
	}
	
	
	@Override
	public String toString() {
		return "HourAndInventoryReportView [id=" + id + ", functionCode=" + functionCode + ", functionName="
				+ functionName + ", areaCode=" + areaCode + ", areaName=" + areaName + ", territoryCode="
				+ territoryCode + ", territoryName=" + territoryName + ", groupCode=" + groupCode + ", groupName="
				+ groupName + ", timeCode=" + timeCode + ", timeCodeDescription=" + timeCodeDescription + ", local="
				+ local + ", rollup=" + rollup + ", clericalHours=" + clericalHours + ", managementHours="
				+ managementHours + ", professionalHours=" + professionalHours + ", paraProfessionalHours="
				+ paraProfessionalHours + ", openingInventory=" + openingInventory + ", inventoryReceipts="
				+ inventoryReceipts + ", inventoryTransferIn=" + inventoryTransferIn + ", inventoryTransferOut="
				+ inventoryTransferOut + ", inventoryDisposals=" + inventoryDisposals + ", yearAndMonth=" + yearAndMonth
				+ ", calendarMonth=" + calendarMonth + ", calendarYear=" + calendarYear + ", fiscalYear=" + fiscalYear
				+ ", getTotalProfessionalHours()=" + getTotalProfessionalHours() + ", getTotalNonProfessionalHours()="
				+ getTotalNonProfessionalHours() + "requiredRole=" + requiredRole + "]";
	}

	
	
	
}

