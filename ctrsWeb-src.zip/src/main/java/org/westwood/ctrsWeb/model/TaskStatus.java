package org.westwood.ctrsWeb.model;

public enum TaskStatus {

	/*
	QUEUED
	PROCESSING
	COMPLETE
	ERROR
	CANCELED
	report_metadata
	*/
	
	QUEUED,
	PROCESSING,
	COMPLETE,
	ERROR,
	CANCELED
	
}
