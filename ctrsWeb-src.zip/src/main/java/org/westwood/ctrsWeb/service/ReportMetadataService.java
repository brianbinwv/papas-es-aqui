package org.westwood.ctrsWeb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.dao.ReportMetadataRepository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.ReportMetadata;
import org.westwood.ctrsWeb.model.TaskStatus;

@Service
@Transactional
public class ReportMetadataService implements CtrsBusinessService {

	@Autowired
	private ReportMetadataRepository metaRepo;
	
	
	public ReportMetadata findById(Long id) {
		ReportMetadata m = new ReportMetadata();
		
		return (ReportMetadata)metaRepo.findById(id);
	}
	
	public ReportMetadata findById(String reportId) {
		ReportMetadata m = new ReportMetadata();
		UUID reportUUID = UUID.fromString(reportId);
		
		return (ReportMetadata)metaRepo.findById(reportUUID);
	}
	
	
//	public ReportMetadata find(String reportId) {
//		ReportMetadata m = new ReportMetadata();
//		
//		UUID reportUUID = UUID.fromString(reportId);
//		
//		m.setReportId(reportUUID);
//		
//		return (ReportMetadata)metaRepo.find(m);
//	}
		
	
	public List<ReportMetadata> findAll() {
		
		List<ReportMetadata> mList = new ArrayList<ReportMetadata>();
		
		for (CtrsEntity e : metaRepo.findAll()) {
			mList.add((ReportMetadata) e);
		}
				
		return mList;
	}


	public List<ReportMetadata> findAll(String userId) {
		
		List<ReportMetadata> mList = new ArrayList<ReportMetadata>();
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.eq("userId", userId));
		
		for (CtrsEntity e : metaRepo.findAll(q)) {
			mList.add((ReportMetadata) e);
		}
				
		return mList;
	}
	
	public Long create(ReportMetadata m) {
		metaRepo.create(m);
		
		return m.getId() != null ? m.getId() : -1L;
	}
	
	public void cancel(ReportMetadata m) {
		m.setStatus(TaskStatus.CANCELED);
		metaRepo.update(m);
	}
	
	
	
//	public void update(Long id, Long clericalHours, Long mgmtHours, 
//			Long professionalHours, Long paraProfessionalHours, Long inventoryReceipts,
//			Long inventoryTransferIn, Long inventoryTransferOut, Long InventoryDisposals) {
//		
//		CtrsHourAndInventory h = (CtrsHourAndInventory) invRepo.findById(id);
//		
//		h.setClericalHours(clericalHours);
//		h.setManagementHours(mgmtHours);
//		h.setProfessionalHours(professionalHours);
//		h.setParaProfessionalHours(paraProfessionalHours);
//		h.setInventoryReceipts(inventoryReceipts);
//		h.setInventoryTransferIn(inventoryTransferIn);
//		h.setInventoryTransferOut(inventoryTransferOut);
//		h.setInventoryDisposals(InventoryDisposals);
//		
//		invRepo.update(h);
//	}
	
	
	
}
