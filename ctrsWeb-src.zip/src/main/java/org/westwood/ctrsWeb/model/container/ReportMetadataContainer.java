package org.westwood.ctrsWeb.model.container;

import java.util.ArrayList;
import java.util.List;

import org.westwood.ctrsWeb.model.ReportMetadata;

public class ReportMetadataContainer {
	private List<ReportMetadata> data = new ArrayList<ReportMetadata>();

	public List<ReportMetadata> getData() {
		return data;
	}

	public void setData(List<ReportMetadata> data) {
		this.data = data;
	}
}
