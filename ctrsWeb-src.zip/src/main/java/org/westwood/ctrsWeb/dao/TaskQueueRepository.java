package org.westwood.ctrsWeb.dao;

import java.util.List;
import java.util.UUID;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.TaskQueue;


@Repository
public class TaskQueueRepository implements CtrsCrudRepository{

	@Autowired
    private SessionFactory sessionFactory;
	
	
	public CtrsEntity find(CtrsEntity ent) {
		return null;
	}
	
	@Override
	public CtrsEntity findById(Long id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(TaskQueue.class).add(Restrictions.eq("id", id));
				
		return (TaskQueue)cr.uniqueResult();
	}
	
	public CtrsEntity findByTaskId(UUID id) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(TaskQueue.class).add(Restrictions.eq("taskId", id));
				
		return (TaskQueue)cr.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findByUserId(String userId) {
		
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(TaskQueue.class).add(Restrictions.eq("userId", userId));
				
		return (List<CtrsEntity>)cr.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll() {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(TaskQueue.class);
		
		return (List<CtrsEntity>)cr.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<CtrsEntity> findAll(List<Criterion> queryCriterion) {
		@SuppressWarnings("deprecation")
		Criteria cr = sessionFactory.getCurrentSession().createCriteria(TaskQueue.class);

		
		for (Criterion c : queryCriterion) {
			cr.add(c);
		}
		
		cr.addOrder(Order.asc("createdDate"));
		
		
		return (List<CtrsEntity>)cr.list();
	}
	
	public Long create(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().save(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
		
		return ent.getId() != null ? ent.getId() : -1L;
	}

	public void update(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().update(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}

	public void delete(CtrsEntity ent) {
		//sessionFactory.getCurrentSession().beginTransaction();
		sessionFactory.getCurrentSession().delete(ent);
		//sessionFactory.getCurrentSession().getTransaction().commit();
	}
	
}
 