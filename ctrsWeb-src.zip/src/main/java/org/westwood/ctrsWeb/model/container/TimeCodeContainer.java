package org.westwood.ctrsWeb.model.container;

import java.util.List;

import org.westwood.ctrsWeb.model.TimeCode;

public class TimeCodeContainer {

	private List<TimeCode> data;

	public List<TimeCode> getData() {
		return data;
	}

	public void setData(List<TimeCode> data) {
		this.data = data;
	}
	
	
	
}
