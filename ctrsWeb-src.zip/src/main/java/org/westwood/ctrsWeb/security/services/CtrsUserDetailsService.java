package org.westwood.ctrsWeb.security.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.westwood.ctrsWeb.dao.UserRepository;
import org.westwood.ctrsWeb.model.Role;
//import org.westwood.ctrs.web.dao.UserRepository;
import org.westwood.ctrsWeb.model.User;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.security.model.CtrsUserDetails;
import org.westwood.ctrsWeb.service.UserService; 

public class CtrsUserDetailsService implements UserDetailsService {
 
    //@Autowired
    //private UserRepository userRepo;
    
	@Autowired
	private UserService userService;
	
    
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    	//User user = (User) userRepo.findBySeid(username);
    	
    	UserContainer uc = userService.findUserContainerBySeid(username);
    	
    	if (uc == null) {
    		//System.out.println("user == null");
    		throw new UsernameNotFoundException("User not found");
    	}
    	
    	User user = uc.getUser();
    	
    	CtrsUserDetails c = new CtrsUserDetails(user);
    	
    	List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
    	
    	for (Role r : uc.getRoles()) {
    		authorities.add(new SimpleGrantedAuthority(r.getRoleName()));
    	}
    	
    	//authorities.add(new SimpleGrantedAuthority("WAS"));
    	//authorities.add(new SimpleGrantedAuthority("SUPER_CTRS_ANALYST"));
    	c.getAuthorities().addAll(authorities);
    	
    	return c;
    }
 
}