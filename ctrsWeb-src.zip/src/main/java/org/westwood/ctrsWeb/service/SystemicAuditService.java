package org.westwood.ctrsWeb.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.westwood.ctrsWeb.dao.OrgMapRepository;
import org.westwood.ctrsWeb.dao.SystemicAuditRepository;
import org.westwood.ctrsWeb.dao.SystemicAuditRepository;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.SystemicAudit;
import org.westwood.ctrsWeb.model.SystemicAuditActionType;

@Service
@Transactional
public class SystemicAuditService implements CtrsBusinessService {
	@Autowired
	private SystemicAuditRepository repo;
	

	public SystemicAudit findById(Long id) {
		return (SystemicAudit) repo.findById(id);
	}

	
	public List<SystemicAudit> findAllByCreationDate(Date creationDate) {
		
		List<SystemicAudit> sList = new ArrayList<SystemicAudit>();
		List<Criterion> q = new ArrayList<Criterion>();
		
		
		q.add(Restrictions.eq("createdDate", creationDate));
		
		for (CtrsEntity e : repo.findAll(q)) {
			sList.add((SystemicAudit) e);
		}
		
		return sList;
	}

	
	public List<SystemicAudit> findAllByCreationDateRange(Date beginDate, Date endDate) {
		
		List<SystemicAudit> sList = new ArrayList<SystemicAudit>();
		List<Criterion> q = new ArrayList<Criterion>();
		
		q.add(Restrictions.between("createdDate", beginDate, endDate));
		
		for (CtrsEntity e : repo.findAll(q)) {
			sList.add((SystemicAudit) e);
		}
		
		return sList;
	}

	
	public List<SystemicAudit> findAllByUser(String user) {
		
		List<SystemicAudit> sList = new ArrayList<SystemicAudit>();
		List<Criterion> q = new ArrayList<Criterion>();
		
		
		q.add(Restrictions.eq("userId", user));
		
		for (CtrsEntity e : repo.findAll(q)) {
			sList.add((SystemicAudit) e);
		}
		
		return sList;
	}
	
	
	public Long create(String user, SystemicAuditActionType actionType, String details) {
		SystemicAudit s = new SystemicAudit();
		
		s.setUserId(user);
		s.setDetails(details);
		s.setActionType(actionType);
		s.setCreatedDate(new Date());
		
		repo.create(s);
		
		return s.getId() != null ? s.getId() : -1L;
	}


}
