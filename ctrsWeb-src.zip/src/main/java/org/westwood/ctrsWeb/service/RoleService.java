package org.westwood.ctrsWeb.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.dao.RoleRepository;
import org.westwood.ctrsWeb.dao.UserRepository;
import org.westwood.ctrsWeb.model.CtrsEntity;

import org.westwood.ctrsWeb.model.Role;



@Service
@Transactional
public class RoleService implements CtrsBusinessService {

	@Autowired
	private RoleRepository repo;
	
	
	public Role findById(Long id) {
		return (Role) repo.findById(id);
	}
	
	
	public List<Role> findAll() {
		List<Role> roles = new ArrayList<Role>();
		// empty list
		List<Criterion> crit = new ArrayList<Criterion>();
		
		
		for (CtrsEntity e : repo.findAll(crit)) {
			roles.add((Role) e);
		}
				
		return roles;
	}
	
	
	public Long create(String roleName, String description) {
		Role r = new Role();
		r.setRoleName(roleName);
		r.setDescription(description);
		repo.create(r);
		
		return r.getId() != null ? r.getId() : -1L;
	}
	
	
	public void update(Long id, String newRoleName, String newDescription) {
		Role r = this.findById(id);
		r.setRoleName(newRoleName);
		r.setDescription(newDescription);
		repo.update(r);
	}

	
	public void delete(Long id) {
		Role r = this.findById(id);
		repo.delete(r);
	}
	
	
}

