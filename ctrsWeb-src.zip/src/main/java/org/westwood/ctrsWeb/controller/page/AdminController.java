package org.westwood.ctrsWeb.controller.page;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.westwood.ctrsWeb.model.json.RoleJson;
import org.westwood.ctrsWeb.model.json.AddUserJson;
import org.westwood.ctrsWeb.model.json.ManageRolesJson;
import org.westwood.ctrsWeb.model.json.OrgMapJson;
import org.westwood.ctrsWeb.service.LW__HourAndInventoryService;
import org.westwood.ctrsWeb.service.UserService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	
	@RequestMapping("")
	public ModelAndView manageUsers(HttpSession session) {
		ModelAndView theModel = new ModelAndView("admin-main", "admin-main", "");
		return theModel;
	}
	
	
	@RequestMapping("/card-test")
	public ModelAndView cardTest() {
		ModelAndView theModel = new ModelAndView("card-test", "card-test", "");
		return theModel;
	}
	
	@RequestMapping("/stepper-demo")
	public ModelAndView getStepper(HttpSession session) {
		ModelAndView theModel = new ModelAndView("stepper-demo", "stepper-demo", "");
		return theModel;
	}
	
	
	
	
	
	
	
	
	
}
