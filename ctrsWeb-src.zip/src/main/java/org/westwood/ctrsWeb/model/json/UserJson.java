package org.westwood.ctrsWeb.model.json;

import java.util.List;
import org.westwood.ctrsWeb.model.User;

public class UserJson {

	private List<User> data;
	
	public List<User> getData() {
		return data;
	}
	
	public void setData(List<User> data) {
		this.data = data;
	}
}
