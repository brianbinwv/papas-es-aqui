package org.westwood.ctrsWeb.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.annotations.Parent;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.westwood.ctrsWeb.dao.OrgMapRepository;
import org.westwood.ctrsWeb.dao.TimeCodeRepository;
import org.westwood.ctrsWeb.dao.DataQueueRepository;
//import org.westwood.ctrsWeb.helper.HrAndInvSearchContainer;
import org.westwood.ctrsWeb.model.CtrsEntity;
import org.westwood.ctrsWeb.model.HourAndInventory;
import org.westwood.ctrsWeb.model.OrgMap;
import org.westwood.ctrsWeb.model.TimeCode;
import org.westwood.ctrsWeb.model.DataQueue;
//import org.westwood.ctrsWeb.model.HourAndInventoryReportView;
//import org.westwood.ctrsWeb.dao.CtrsCrudRepository;
import org.westwood.ctrsWeb.dao.HourAndInventoryRepository;


@Service
@Transactional
public class HourAndInventoryService implements CtrsBusinessService {

	
	@Autowired
	private HourAndInventoryRepository invRepo;
	
	@Autowired
	private OrgMapRepository orgRepo;
	
	@Autowired
	private DataQueueRepository dqRepo;
	
	
	@Autowired
	private TimeCodeRepository timeCodeRepo;
	
	
	public HourAndInventory findById(Long id) {
		return (HourAndInventory) invRepo.findById(id);
	}
	
	
	public HourAndInventory find(Long functionId, Long areaId, Long territoryId,
			Long groupId, String timeCode, Long calendarMonth, Long calendarYear, Long fiscalYear) {
		HourAndInventory inv = new HourAndInventory();
		
		
		OrgMap function = new OrgMap();
		function = (OrgMap) orgRepo.findById(functionId);
		
		OrgMap area = new OrgMap();
		area = (OrgMap) orgRepo.findById(areaId);
		
		OrgMap territory = new OrgMap();
		territory = (OrgMap) orgRepo.findById(territoryId);
		
		OrgMap group = new OrgMap();
		group = (OrgMap) orgRepo.findById(groupId);

		TimeCode tc = new TimeCode();
		tc.setFunction(function);
		tc.setArea(function);
		tc.setTerritory(function);
		tc.setTimeCode(timeCode);
		tc.setFiscalYear(fiscalYear);
		tc = (TimeCode)timeCodeRepo.find(tc);
		
		if (tc == null) {
			// if the first search returned null, search for a local time code
			tc = new TimeCode();
			tc.setFunction(function);
			tc.setArea(area);
			tc.setTerritory(territory);
			tc.setTimeCode(timeCode);
			tc.setFiscalYear(fiscalYear);
			tc = (TimeCode)timeCodeRepo.find(tc);
		}
		
		inv.setFunction(function);
		inv.setArea(area);
		inv.setTerritory(territory);
		inv.setGroup(group);
		inv.setTimeCode(tc);
		inv.setFiscalYear(fiscalYear);
		inv.setMonth(calendarMonth);
		inv.setYear(calendarYear);
		
		return (HourAndInventory)invRepo.find(inv);
	}
		
	
	public List<HourAndInventory> findAll(Long functionId, Long areaId, Long territoryId,
			Long groupId, Long calendarMonth, Long calendarYear, Long fiscalYear) {
		
		List<HourAndInventory> hList = new ArrayList<HourAndInventory>();
		OrgMap function = new OrgMap();
		OrgMap area = null;
		OrgMap territory = null;
		OrgMap group = null;
		
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		if (functionId != -1) {
			function = (OrgMap) orgRepo.findById(functionId);
			q.add(Restrictions.eq("function", function));
		}
		
		if (areaId != -1L) {
			area = (OrgMap) orgRepo.findById(areaId);
			q.add(Restrictions.eq("area", area));
		}
		
		if (territoryId != -1L) {
			territory = (OrgMap) orgRepo.findById(territoryId); 
			q.add(Restrictions.eq("territory", territory));
		}
		
		if (groupId != -1L) {
			group = (OrgMap) orgRepo.findById(groupId);
			q.add(Restrictions.eq("group", group));
		}
				
		q.add(Restrictions.eq("month", calendarMonth));
		q.add(Restrictions.eq("year", calendarYear));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		
		
		for (CtrsEntity e : invRepo.findAll(q)) {
			hList.add((HourAndInventory) e);
		}
				
		return hList;
	}
	
	
//	public List<HourAndInventory> findAll(HrAndInvSearchContainer srch) {
//		List<HourAndInventory> hList = new ArrayList<HourAndInventory>();
//		List<Criterion> q = new ArrayList<Criterion>();
//
//		
//		if (srch.getFunction() != null) {
//			q.add(Restrictions.eq("function", srch.getFunction()));
//		}
//		
//		if (srch.getArea() != null) {
//			q.add(Restrictions.eq("area", srch.getArea()));
//		}
//		
//		if (srch.getTerritory() != null) {
//			q.add(Restrictions.eq("territory", srch.getTerritory()));
//		}
//		
//		if (srch.getGroup() != null) {
//			q.add(Restrictions.eq("group", srch.getGroup()));
//		}
//		
//		q.add(Restrictions.eq("month", srch.getCalendarMonth()));
//		
//		if (srch.getTimeCodes() != null) {
//			if (srch.getTimeCodes().size() > 0) {
//				// filter time codes
//				for (TimeCode t : srch.getTimeCodes()) {
//					q.add(Restrictions.or(Restrictions.eq("timeCode", t)));
//				}
//			}
//		}
//		
//		
//		for (CtrsEntity e : invRepo.findAll(q)) {
//			hList.add((HourAndInventory) e);
//		}
//				
//		return hList;
//	}
	
	
	
	
	public List<HourAndInventory> findAllGroupByFunction(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long calendarYear, Long fiscalYear) {
		List<HourAndInventory> hList = new ArrayList<HourAndInventory>();
		OrgMap function = new OrgMap();
		OrgMap area = null;
		OrgMap territory = null;
		
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		if (functionId != -1) {
			function = (OrgMap) orgRepo.findById(functionId);
			q.add(Restrictions.eq("function", function));
		}
		
		if (areaId != -1L) {
			area = (OrgMap) orgRepo.findById(areaId);
			q.add(Restrictions.eq("area", area));
		}
		
		if (territoryId != -1L) {
			territory = (OrgMap) orgRepo.findById(territoryId); 
			q.add(Restrictions.eq("territory", territory));
		}
		
		q.add(Restrictions.eq("month", calendarMonth));
		q.add(Restrictions.eq("year", calendarYear));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		
		
		for (CtrsEntity e : ((HourAndInventoryRepository)invRepo).findAllGroupByFunction(q)) {
			hList.add((HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<HourAndInventory> findAllGroupByFunction_Area(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long calendarYear, Long fiscalYear) {
		List<HourAndInventory> hList = new ArrayList<HourAndInventory>();
		OrgMap function = new OrgMap();
		OrgMap area = null;
		OrgMap territory = null;
		
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		if (functionId != -1) {
			function = (OrgMap) orgRepo.findById(functionId);
			q.add(Restrictions.eq("function", function));
		}
		
		if (areaId != -1L) {
			area = (OrgMap) orgRepo.findById(areaId);
			q.add(Restrictions.eq("area", area));
		}
		
		if (territoryId != -1L) {
			territory = (OrgMap) orgRepo.findById(territoryId); 
			q.add(Restrictions.eq("territory", territory));
		}
		
		q.add(Restrictions.eq("month", calendarMonth));
		q.add(Restrictions.eq("year", calendarYear));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		
		
		for (CtrsEntity e : ((HourAndInventoryRepository)invRepo).findAllGroupByFunction_Area(q)) {
			hList.add((HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<HourAndInventory> findAllGroupByFunction_Area_Territory(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long calendarYear, Long fiscalYear) {
		List<HourAndInventory> hList = new ArrayList<HourAndInventory>();
		OrgMap function = new OrgMap();
		OrgMap area = null;
		OrgMap territory = null;
		
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		if (functionId != -1) {
			function = (OrgMap) orgRepo.findById(functionId);
			q.add(Restrictions.eq("function", function));
		}
		
		if (areaId != -1L) {
			area = (OrgMap) orgRepo.findById(areaId);
			q.add(Restrictions.eq("area", area));
		}
		
		if (territoryId != -1L) {
			territory = (OrgMap) orgRepo.findById(territoryId); 
			q.add(Restrictions.eq("territory", territory));
		}
		
		q.add(Restrictions.eq("month", calendarMonth));
		q.add(Restrictions.eq("year", calendarYear));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		
		
		for (CtrsEntity e : ((HourAndInventoryRepository)invRepo).findAllGroupByFunction_Area_Territory(q)) {
			hList.add((HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public List<HourAndInventory> findAllGroupByFunction_Area_Territory(Long functionId, Long areaId, Long territoryId,
			Long calendarMonth, Long calendarYear, Long endCalendarMonth, Long endCalendarYear, Long fiscalYear) {
		List<HourAndInventory> hList = new ArrayList<HourAndInventory>();
		OrgMap function = new OrgMap();
		OrgMap area = null;
		OrgMap territory = null;
		Date beginDate = null;
		Date endDate = null;
		
		
		List<Criterion> q = new ArrayList<Criterion>();
		
		if (functionId != -1) {
			function = (OrgMap) orgRepo.findById(functionId);
			q.add(Restrictions.eq("function", function));
		}
		
		if (areaId != -1L) {
			area = (OrgMap) orgRepo.findById(areaId);
			q.add(Restrictions.eq("area", area));
		}
		
		if (territoryId != -1L) {
			territory = (OrgMap) orgRepo.findById(territoryId); 
			q.add(Restrictions.eq("territory", territory));
		}
		
		
		try {
			beginDate = new SimpleDateFormat("yyyy-MM-dd").parse(calendarYear.toString() + 
					"-" + calendarMonth.toString() + "-01");
				
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(endCalendarYear.toString() + 
					"-" + endCalendarMonth.toString() + "-01");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		q.add(Restrictions.between("yearAndMonth", beginDate, endDate));
		//q.add(Restrictions.eq("month", calendarMonth));
		//q.add(Restrictions.eq("year", calendarYear));
		q.add(Restrictions.eq("fiscalYear", fiscalYear));
		
		
		for (CtrsEntity e : ((HourAndInventoryRepository)invRepo).findAllGroupByFunction_Area_Territory(q)) {
			hList.add((HourAndInventory) e);
		}
				
		return hList;
	}
	
	
	public Long create(Long functionId, Long areaId, Long territoryId,
			Long groupId, String timeCode, Long calendarMonth, Long calendarYear, Long fiscalYear, Long local) {
		
		HourAndInventory inv = new HourAndInventory();
		
		OrgMap function = new OrgMap();
		function = (OrgMap) orgRepo.findById(functionId);
		
		OrgMap area = new OrgMap();
		area = (OrgMap) orgRepo.findById(areaId);
		
		OrgMap territory = new OrgMap();
		territory = (OrgMap) orgRepo.findById(territoryId);
		
		
		OrgMap group = new OrgMap();
		group = (OrgMap) orgRepo.findById(groupId);
		
		System.out.println("searching for data queue record");
		
		DataQueue dq = new DataQueue();
		dq.setFunction(function);
		dq.setArea(area);
		dq.setTerritory(territory);
		dq.setCalendarMonth(calendarMonth);
		dq.setFiscalYear(fiscalYear);
		dq = (DataQueue) dqRepo.find(dq);
				
		inv.setDataQueue(dq);
		
		
		inv.setFunction(function);
		inv.setArea(area);
		inv.setTerritory(territory);
		inv.setGroup(group);
		
		TimeCode tc = new TimeCode();
		tc.setFunction(function);
		
		if (local == 0L) {
			tc.setArea(function);
			tc.setTerritory(function);
			tc.setTimeCode(timeCode);
			tc.setFiscalYear(fiscalYear);
			tc = (TimeCode)timeCodeRepo.find(tc);
		}
		else {
			// local time code
			tc.setArea(area);
			tc.setTerritory(territory);
			tc.setTimeCode(timeCode);
			tc.setFiscalYear(fiscalYear);
			tc = (TimeCode)timeCodeRepo.find(tc);
		}
		
		
		inv.setTimeCode(tc);
		
		inv.setClericalHours(0L);
		inv.setManagementHours(0L);
		inv.setParaProfessionalHours(0L);
		inv.setProfessionalHours(0L);
		inv.setOpeningInventory(0L);
		inv.setInventoryReceipts(0L);
		inv.setInventoryTransferIn(0L);
		inv.setInventoryTransferOut(0L);
		inv.setInventoryDisposals(0L);
		
		
		
		
		try {
			inv.setYearAndMonth(
					new SimpleDateFormat("yyyy-MM-dd").parse(calendarYear.toString() + 
							"-" + calendarMonth.toString() + "-01")
			);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//inv.setMonth(calendarMonth);
		//inv.setYear(calendarYear);
		inv.setFiscalYear(fiscalYear);
		
		
		if (inv.getFunction() == null || inv.getArea() == null || 
				inv.getTerritory() == null || inv.getGroup() == null || 
				inv.getTimeCode() == null) {
			return -1L;
		}
		
		
		invRepo.create(inv);
		
		return inv.getId() != null ? inv.getId() : -1L;
	}
	

	public void update(CtrsEntity e) {
		invRepo.update(e);
	}
	
	
	public void update(Long id, Long clericalHours, Long mgmtHours, 
			Long professionalHours, Long paraProfessionalHours, Long inventoryReceipts,
			Long inventoryTransferIn, Long inventoryTransferOut, Long InventoryDisposals) {
		
		HourAndInventory h = (HourAndInventory) invRepo.findById(id);
		
		h.setClericalHours(clericalHours);
		h.setManagementHours(mgmtHours);
		h.setProfessionalHours(professionalHours);
		h.setParaProfessionalHours(paraProfessionalHours);
		h.setInventoryReceipts(inventoryReceipts);
		h.setInventoryTransferIn(inventoryTransferIn);
		h.setInventoryTransferOut(inventoryTransferOut);
		h.setInventoryDisposals(InventoryDisposals);
		
		invRepo.update(h);
	}
	
	
	
	
	
}

