package org.westwood.ctrsWeb.controller.api;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.westwood.ctrsWeb.model.DataQueue;
import org.westwood.ctrsWeb.model.HourAndInventory;
import org.westwood.ctrsWeb.model.HourAndInventoryMetadata;
import org.westwood.ctrsWeb.model.MissingHourAndInventoryRecord;
import org.westwood.ctrsWeb.model.SystemicAuditActionType;
import org.westwood.ctrsWeb.model.TaskQueue;
import org.westwood.ctrsWeb.model.TaskStatus;
import org.westwood.ctrsWeb.model.TaskType;
import org.westwood.ctrsWeb.model.container.LW__HourAndInventoryContainer;
import org.westwood.ctrsWeb.model.container.MissingHourAndInventoryContainer;
import org.westwood.ctrsWeb.model.container.SuperCTRSAnalystDataQueueContainer;
import org.westwood.ctrsWeb.model.container.UserContainer;
import org.westwood.ctrsWeb.model.container.VTSDataQueueContainer;
import org.westwood.ctrsWeb.model.container.WASDataQueueContainer;
import org.westwood.ctrsWeb.model.container.WASMGRDataQueueContainer;
import org.westwood.ctrsWeb.model.json.DataQueueJson;
import org.westwood.ctrsWeb.model.json.DataQueueUpdateJson;
import org.westwood.ctrsWeb.model.json.HoursJson;
import org.westwood.ctrsWeb.model.json.InventoryJson;
import org.westwood.ctrsWeb.model.json.ROCountJson;
import org.westwood.ctrsWeb.model.json.TaskQueueJson;
import org.westwood.ctrsWeb.model.lightweight.LW__HourAndInventory;
import org.westwood.ctrsWeb.security.PermissionValidator;
import org.westwood.ctrsWeb.service.DataQueueService;
import org.westwood.ctrsWeb.service.HourAndInventoryMetadataService;
import org.westwood.ctrsWeb.service.HourAndInventoryService;
import org.westwood.ctrsWeb.service.LW__HourAndInventoryService;
import org.westwood.ctrsWeb.service.OrgMapService;
import org.westwood.ctrsWeb.service.SystemicAuditService;
import org.westwood.ctrsWeb.service.TaskQueueService;
import org.westwood.ctrsWeb.service.TimeCodeService;
import org.westwood.ctrsWeb.service.UserService;

import com.google.gson.Gson;

@Controller
@RequestMapping("/hourandinventory/api")
public class HourAndInventoryApiController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private LW__HourAndInventoryService lwService;
	
	@Autowired
	private HourAndInventoryService invService;

	@Autowired
	private HourAndInventoryMetadataService metaDataService;
	
	@Autowired
	private TaskQueueService taskService;
	
	
	@Autowired
	private SystemicAuditService auditService;
	
	
	@Autowired
    private JmsTemplate producerTemplate;
	
	
	
	
	@RequestMapping(value = "/get-hours", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<LW__HourAndInventoryContainer> getHours(@RequestParam(name="functionId", required=true) Long functionId,
			@RequestParam(name="areaId", required=false, defaultValue="-1") Long areaId,
			@RequestParam(name="territoryId", required=false, defaultValue="-1") Long territoryId,
			@RequestParam(name="groupId", required=false, defaultValue="-1") Long groupId,
			@RequestParam(name="monthId", required=true) Long monthId,
			@RequestParam(name="fiscalYear", required=true) Long fiscalYear) {

		LW__HourAndInventoryContainer container = new LW__HourAndInventoryContainer();
		List<LW__HourAndInventory> invList = new ArrayList<LW__HourAndInventory>();
		invList = lwService.findHours(functionId, areaId, territoryId, groupId, monthId, fiscalYear);
		
		if (invList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		container.setData(invList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/get-inventory", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<LW__HourAndInventoryContainer> getInventory(@RequestParam(name="functionId", required=true) Long functionId,
			@RequestParam(name="areaId", required=false, defaultValue="-1") Long areaId,
			@RequestParam(name="territoryId", required=false, defaultValue="-1") Long territoryId,
			@RequestParam(name="groupId", required=false, defaultValue="-1") Long groupId,
			@RequestParam(name="monthId", required=true) Long monthId,
			@RequestParam(name="fiscalYear", required=true) Long fiscalYear) {

		LW__HourAndInventoryContainer container = new LW__HourAndInventoryContainer();
		List<LW__HourAndInventory> invList = new ArrayList<LW__HourAndInventory>();
		invList = lwService.findInventory(functionId, areaId, territoryId, groupId, monthId, fiscalYear);
		
		if (invList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		container.setData(invList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	
	
	@RequestMapping(value = "/get-hours-summary", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<LW__HourAndInventoryContainer> getHourSummary(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam(name="territoryId", required=false, defaultValue="-1") Long territoryId,
			@RequestParam("monthId") Long monthId,
			@RequestParam("fiscalYear") Long fiscalYear) {

		LW__HourAndInventoryContainer container = new LW__HourAndInventoryContainer();
		List<LW__HourAndInventory> invList = new ArrayList<LW__HourAndInventory>();
		invList = lwService.findHours__Summary(functionId, areaId, territoryId, monthId, fiscalYear);
		
		if (invList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		container.setData(invList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/get-inventory-summary", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<LW__HourAndInventoryContainer> getInventorySummary(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam(name="territoryId", required=false, defaultValue="-1") Long territoryId,
			@RequestParam("monthId") Long monthId,
			@RequestParam("fiscalYear") Long fiscalYear) {

		LW__HourAndInventoryContainer container = new LW__HourAndInventoryContainer();
		List<LW__HourAndInventory> invList = new ArrayList<LW__HourAndInventory>();
		invList = lwService.findInventory__Summary(functionId, areaId, territoryId, monthId, fiscalYear);
		
		if (invList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		container.setData(invList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/get-ro-counts", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<LW__HourAndInventoryContainer> getROCounts(@RequestParam(name="functionId", required=true) Long functionId,
			@RequestParam(name="areaId", required=false, defaultValue="-1") Long areaId,
			@RequestParam(name="territoryId", required=false, defaultValue="-1") Long territoryId,
			@RequestParam(name="groupId", required=false, defaultValue="-1") Long groupId,
			@RequestParam(name="monthId", required=true) Long monthId,
			@RequestParam(name="fiscalYear", required=true) Long fiscalYear) {

		LW__HourAndInventoryContainer container = new LW__HourAndInventoryContainer();
		List<LW__HourAndInventory> rocList = new ArrayList<LW__HourAndInventory>();
		rocList = lwService.findROCounts(functionId, areaId, territoryId, groupId, monthId, fiscalYear);
		
		if (rocList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		container.setData(rocList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/get-ro-counts-summary", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<LW__HourAndInventoryContainer> getROCountsSummary(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam(name="territoryId", required=false, defaultValue="-1") Long territoryId,
			@RequestParam("monthId") Long monthId,
			@RequestParam("fiscalYear") Long fiscalYear) {

		LW__HourAndInventoryContainer container = new LW__HourAndInventoryContainer();
		List<LW__HourAndInventory> rocList = new ArrayList<LW__HourAndInventory>();
		rocList = lwService.findROCounts__Summary(functionId, areaId, territoryId, monthId, fiscalYear);
		
		if (rocList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		container.setData(rocList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/get-other-actions", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<LW__HourAndInventoryContainer> getOtherActions(@RequestParam(name="functionId", required=true) Long functionId,
			@RequestParam(name="areaId", required=false, defaultValue="-1") Long areaId,
			@RequestParam(name="territoryId", required=false, defaultValue="-1") Long territoryId,
			@RequestParam(name="groupId", required=false, defaultValue="-1") Long groupId,
			@RequestParam(name="monthId", required=true) Long monthId,
			@RequestParam(name="fiscalYear", required=true) Long fiscalYear) {

		LW__HourAndInventoryContainer container = new LW__HourAndInventoryContainer();
		List<LW__HourAndInventory> rocList = new ArrayList<LW__HourAndInventory>();
		rocList = lwService.findOtherActions(functionId, areaId, territoryId, groupId, monthId, fiscalYear);
		
		if (rocList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		container.setData(rocList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@RequestMapping(value = "/get-other-actions-summary", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<LW__HourAndInventoryContainer> getOtherActionsSummary(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam(name="territoryId", required=false, defaultValue="-1") Long territoryId,
			@RequestParam("monthId") Long monthId,
			@RequestParam("fiscalYear") Long fiscalYear) {

		LW__HourAndInventoryContainer container = new LW__HourAndInventoryContainer();
		List<LW__HourAndInventory> rocList = new ArrayList<LW__HourAndInventory>();
		rocList = lwService.findOtherActions__Summary(functionId, areaId, territoryId, monthId, fiscalYear);
		
		if (rocList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		container.setData(rocList);
		
		return ResponseEntity.status(HttpStatus.OK).body(container);
	}
	
	
	@PostMapping("/update-hours")
	@ResponseBody
	public ResponseEntity<String> updateHours(@RequestBody HoursJson hoursObj) {
		
		
		
		
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		HourAndInventory h = invService.findById(hoursObj.getId());
		
		
		
		if (!hoursObj.isValid()) {
			System.out.println("hoursObj isValid = false");
			return ResponseEntity.status(HttpStatus.CONFLICT).body("invalid json");
		}
		
		
		if (h == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		// ****SECURITY CHECK****
		if (!PermissionValidator.canEdit(container, h)) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("insufficient privilege");
		}
		// ****END SECURITY CHECK****
		
				
		try {
			// request the update
			h.setClericalHours(hoursObj.getClericalHours());
			h.setParaProfessionalHours(hoursObj.getParaProfessionalHours());
			h.setProfessionalHours(hoursObj.getProfessionalHours());
			h.setManagementHours(hoursObj.getManagementHours());
			invService.update(h);


			// create the metadata
			metaDataService.create("cskcb", "UPDATE", hoursObj.getComments(), new Date(), hoursObj.getId());
			
			
			// audit
			auditService.create(container.getUser().getSeid(), SystemicAuditActionType.UPDATE_HOUR_AND_INVENTORY, "updated time code " + h.getTimeCode().getTimeCode());
			

			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			System.out.println(e.getMessage() + "\n" + e.getStackTrace());
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
	
	
	@PostMapping("/update-inventory")
	@ResponseBody
	public ResponseEntity<String> updateInventory(@RequestBody InventoryJson inventoryObj) {
		
		
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		HourAndInventory h = invService.findById(inventoryObj.getId());
		
		
		if (h == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		// ****SECURITY CHECK****
		if (!PermissionValidator.canEdit(container, h)) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("insufficient privilege");
		}
		// ****END SECURITY CHECK****
		
				
		try {
			// request the update
			h.setInventoryReceipts(inventoryObj.getReceipts());
			h.setInventoryTransferIn(inventoryObj.getXferIn());
			h.setInventoryTransferOut(inventoryObj.getXferOut());
			h.setInventoryDisposals(inventoryObj.getDisposals());
			invService.update(h);

			// audit
			auditService.create(container.getUser().getSeid(), SystemicAuditActionType.UPDATE_HOUR_AND_INVENTORY, "updated time code " + h.getTimeCode().getTimeCode());
			
			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
	
	
	@PostMapping("/update-ro-count")
	@ResponseBody
	public ResponseEntity<String> updateROCount(@RequestBody ROCountJson rocObj) {
		
		
		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		HourAndInventory h = invService.findById(rocObj.getId());
		
		
		if (h == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		
		// ****SECURITY CHECK****
		if (!PermissionValidator.canEdit(container, h)) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("insufficient privilege");
		}
		// ****END SECURITY CHECK****
		
				
		try {
			System.out.println("id: " + rocObj.getId());
			System.out.println("roCount: " + rocObj.getRoCount());
			System.out.println("tpInventory: " + rocObj.getTpInventory());
			
			// request the update
			h.setClericalHours(rocObj.getRoCount());
			h.setParaProfessionalHours(rocObj.getTpInventory());
			invService.update(h);


			// audit
			auditService.create(container.getUser().getSeid(), SystemicAuditActionType.UPDATE_HOUR_AND_INVENTORY, "updated time code " + h.getTimeCode());

			return ResponseEntity.status(HttpStatus.OK).body("Updated");
		
		}
		catch (Exception e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("Update failed");
		}
	}
	
	
	
	
	
	
	@RequestMapping(value = "/get-metadata", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<List<HourAndInventoryMetadata>> getMetadata(@RequestParam("timeCodeId") Long timeCodeId) {

		List<HourAndInventoryMetadata> metaDataList = new ArrayList<HourAndInventoryMetadata>();
		metaDataList = metaDataService.findByTimeCodeId(timeCodeId);
		
		if (metaDataList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(metaDataList);
	}
	
	
	@RequestMapping(value = "/get-missing-records", 
			method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	public ResponseEntity<MissingHourAndInventoryContainer> getMissingRecords(
			@RequestParam("functionId") Long functionId,
			@RequestParam("areaId") Long areaId,
			@RequestParam("calendarMonth") Long calendarMonth,
			@RequestParam("fiscalYear") Long fiscalYear) {
		MissingHourAndInventoryContainer c = new MissingHourAndInventoryContainer();
		List<MissingHourAndInventoryRecord> mrList = new ArrayList<MissingHourAndInventoryRecord>();
		mrList = lwService.findMissingRecords_2(functionId, areaId, fiscalYear, calendarMonth);
		
		if (mrList == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		c.setData(mrList);
		return ResponseEntity.status(HttpStatus.OK).body(c);
	}
	
	
	@PostMapping("/queue-create-missing-records-task")
	@ResponseBody
	public ResponseEntity<String> queueCreateMissingRecordsTask(@RequestBody TaskQueueJson taskObj) {
	
		

		// TODO: get roles from security context
		UserContainer container = userService.findUserContainerById(1L);
		
		TaskQueue t = new TaskQueue();
		
		Gson gson = new Gson();
		String json = gson.toJson(taskObj);

		
		t.setUserId(container.getUser().getSeid());
		t.setCreatedDate(new Date());
		t.setTaskId(UUID.randomUUID());
		t.setTaskType(TaskType.INIT_MISSING_RECORDS);
		t.setParameters(json);
		t.setStatus(TaskStatus.QUEUED);
		
		
		//System.out.println(m.toString());
		taskService.create(t);

		
		sendMessages("{ 'id':'" + t.getTaskId() + "', 'type','" + t.getTaskType().ordinal() + "'}" );
		
		
		return ResponseEntity.status(HttpStatus.OK).body("Task has been generated");
		
		
	}
	
	
	
	
	private void sendMessages(String msgText) {

        producerTemplate.send(new MessageCreator() {

        	public Message createMessage(Session session) throws JMSException {

        		TextMessage message = session.createTextMessage(msgText); 

        		message.setIntProperty("messageCount", 1);

        		return message;
            }
        });
    }

	
	
}
