package org.westwood.ctrsWeb.model.container;

import java.util.ArrayList;
import java.util.List;

import org.westwood.ctrsWeb.model.lightweight.LW__HourAndInventory;

public class LW__HourAndInventoryContainer {

	private List<LW__HourAndInventory> data = new ArrayList<LW__HourAndInventory>();

	public List<LW__HourAndInventory> getData() {
		return data;
	}

	public void setData(List<LW__HourAndInventory> data) {
		this.data = data;
	}
}
